-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-12-2014 a las 18:37:42
-- Versión del servidor: 5.6.16
-- Versión de PHP: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `uv9154_hotel`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accesos`
--

CREATE TABLE IF NOT EXISTS `accesos` (
  `id_acceso` int(11) NOT NULL AUTO_INCREMENT,
  `acceso` varchar(64) CHARACTER SET latin1 NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_acceso`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `accesos`
--

INSERT INTO `accesos` (`id_acceso`, `acceso`, `delete`) VALUES
(1, 'Normal', 0),
(2, 'a ver', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accion`
--

CREATE TABLE IF NOT EXISTS `accion` (
  `id_accion` int(11) NOT NULL AUTO_INCREMENT,
  `accion` varchar(64) NOT NULL,
  PRIMARY KEY (`id_accion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `accion`
--

INSERT INTO `accion` (`id_accion`, `accion`) VALUES
(1, '<span class="label label-success">nuevo</span>'),
(2, '<span class="label label-primary">modificar</span>'),
(3, '<span class="label label-danger">borrar</span>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aerolineas`
--

CREATE TABLE IF NOT EXISTS `aerolineas` (
  `id_aerolinea` int(11) NOT NULL AUTO_INCREMENT,
  `aerolinea` varchar(64) NOT NULL,
  `delete` int(11) NOT NULL,
  PRIMARY KEY (`id_aerolinea`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `aerolineas`
--

INSERT INTO `aerolineas` (`id_aerolinea`, `aerolinea`, `delete`) VALUES
(1, 'Aerolineas Argentinas', 0),
(2, 'LAN Chile', 0),
(3, 'Sol', 0),
(4, 'LAN Argentina', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulos`
--

CREATE TABLE IF NOT EXISTS `articulos` (
  `id_articulo` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) CHARACTER SET latin1 NOT NULL,
  `subtitulo` varchar(255) COLLATE latin1_spanish_ci NOT NULL,
  `articulo` text CHARACTER SET latin1 NOT NULL,
  `fecha_publicacion` date NOT NULL,
  `fecha_despublicacion` date NOT NULL,
  `archivo_url` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `pagina_principal` tinyint(4) NOT NULL,
  `orden` int(11) NOT NULL DEFAULT '1',
  `id_hotel` int(11) NOT NULL,
  `id_autor` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `id_estado_articulo` int(11) NOT NULL,
  `id_idioma` int(11) NOT NULL,
  `id_tarifa_temporal` int(11) NOT NULL,
  `id_tipo` int(11) NOT NULL DEFAULT '1',
  `delete` tinytext COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id_articulo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=25 ;

--
-- Volcado de datos para la tabla `articulos`
--

INSERT INTO `articulos` (`id_articulo`, `titulo`, `subtitulo`, `articulo`, `fecha_publicacion`, `fecha_despublicacion`, `archivo_url`, `pagina_principal`, `orden`, `id_hotel`, `id_autor`, `id_categoria`, `id_estado_articulo`, `id_idioma`, `id_tarifa_temporal`, `id_tipo`, `delete`) VALUES
(1, 'Transfer desde y hacia el Aeropuerto', '', '<p>\r\n	<span style="font-size:16px;">Nuestros Hoteles de Mendoza ofrecen el servicio de Transfer desde y hacia el Aeropuerto, incluido en la tarifa.&nbsp;</span></p>\r\n<p>\r\n	<span style="font-size:16px;">En coches privados y de primera categoria.</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n', '2014-11-03', '0000-00-00', '1f337-transfer.jpg.183x183_default.jpg', 1, 1, 1, 1, 12, 1, 2, 0, 1, ''),
(2, 'Transfer desde y hacia el Aeropuerto', 'Nuestros Hoteles de Mendoza ofrecen el servicio de Transfer desde y hacia el Aeropuerto, incluido en la tarifa. ', '<p>\r\n	<span style="font-size: 16px;">Nuestros Hoteles de Mendoza ofrecen el servicio de Transfer desde y hacia el Aeropuerto, incluido en la tarifa.&nbsp;</span></p>\r\n<p>\r\n	<span style="font-size: 16px;">En coches privados y de primera categoria.</span></p>\r\n', '2014-11-03', '0000-00-00', '4059e-6aac7-img_3767.jpg', 1, 1, 3, 0, 12, 1, 1, 0, 1, ''),
(3, 'Promo 4x3', '', '<p style="text-align: center;">\n	<u style="text-align: center;">PROMO 4X3!!</u></p>\n<p>\n	<span style="font-size:16px;">Te esperamos para que disfrutes de nuestros servicios alojandote 4 noches y abonando solo 3 noches!!!</span></p>\n<p>\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\n<p>\n	No incluye temporada alta ni fines de semana largo.&nbsp;</p>\n<p>\n	&nbsp;</p>\n', '2014-11-03', '0000-00-00', 'cff6c-79499-images.jpg', 0, 1, 1, 1, 3, 1, 1, 0, 1, ''),
(4, 'Servicios Hotel', '', '<p style="font-size: 11.8181819915771px;">\n	<strong><u>GRAN HOTEL PRINCESS GOLD</u></strong>, de categor&iacute;a 3 estrellas posee una excelente ubicaci&oacute;n c&eacute;ntrica, situado en el coraz&oacute;n de la provincia de Mendoza, a pasos de la actividad comercial, financiera y art&iacute;stica. Rodeado de los mejores Restaurants, Vinotecas y Tiendas. Brindamos un clima de calidez, un servicio impecable y una atenci&oacute;n personalizada.</p>\n<div style="font-size: 11.8181819915771px;">\n	Nuestro objetivo es lograr una experiencia &uacute;nica en cada visita a nuestro Hotel y junto con nuestro staff de colaboradores buscamos satifacerlo brindando un servicio acorde a sus necesidades.&nbsp;</div>\n<div style="font-size: 11.8181819915771px;">\n	&nbsp;</div>\n<div style="font-size: 11.8181819915771px;">\n	Se detallan a continuaci&oacute;n los servicios ofrecidos</div>\n<p>\n	<img height="60%" src="http://www.hotelcarollo.com/test//assets/uploads/articulos/sin.png" uploads="" /></p>\n', '2014-11-01', '0000-00-00', '', 0, 1, 3, 0, 6, 1, 0, 0, 1, ''),
(5, 'Servicios Hotel', '', '<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size:12px;"><span style="font-family:tahoma,geneva,sans-serif;"><strong><u>GRAN HOTEL SAN LUIS GOLD</u></strong>, de categor&iacute;a 3 estrellas posee una excelente ubicaci&oacute;n c&eacute;ntrica, situado en el coraz&oacute;n de la provincia de San Luis, a pasos de la actividad comercial, financiera y art&iacute;stica. Rodeado de los mejores Restaurants, Vinotecas y Tiendas. Brindamos un clima de calidez, un servicio impecable y una atenci&oacute;n personalizada.</span></span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size:12px;"><span style="font-family:tahoma,geneva,sans-serif;">Nuestro objetivo es lograr una experiencia &uacute;nica en cada visita a nuestro Hotel y junto con nuestro staff de colaboradores buscamos satifacerlo brindando un servicio acorde a sus necesidades.&nbsp;</span></span></p>\r\n<div style="font-size: 11.8181819915771px;">\r\n	&nbsp;</div>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size:12px;"><span style="font-family:tahoma,geneva,sans-serif;">Se detallan a continuaci&oacute;n los servicios ofrecidos</span></span></p>\r\n<div style="font-size: 11.8181819915771px;">\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<p>\r\n	<img height="60%" src="http://www.hotelcarollo.com/test//assets/uploads/articulos/sin.png" uploads="" /></p>\r\n', '2014-11-01', '0000-00-00', '', 0, 1, 2, 0, 6, 1, 0, 0, 1, ''),
(6, 'Servicios Hotel', '', '<p>\n	<strong><u>HOTEL CAROLLO GOLD</u></strong>, de categor&iacute;a 3 estrellas posee una excelente ubicaci&oacute;n c&eacute;ntrica, situado en el coraz&oacute;n de la actividad Hotelera de la provincia, rodeado de los mejores Restaurants, Vinotecas y Tiendas.</p>\n<div>\n	Actualmente se encuentra en la segunda etapa de renovaci&oacute;n de habitaciones, logrando una modernizaci&oacute;n de las mismas para brindar el servicio y confort que nuestros hu&eacute;spedes se merecen.</div>\n<div>\n	&nbsp;</div>\n<div>\n	Nuestro objetivo es lograr una experiencia &uacute;nica en cada visita a nuestro Hotel y junto con nuestro staff de colaboradores buscamos satifacerlo brindando un servicio acorde a sus necesidades.&nbsp;</div>\n<div>\n	&nbsp;</div>\n<div>\n	Se detallan a continuaci&oacute;n los servicios ofrecidos</div>\n<div>\n	&nbsp;</div>\n<p>\n	<img height="60%" src="http://www.hotelcarollo.com/test//assets/uploads/articulos/sin.png" uploads="" /></p>\n', '2014-11-01', '0000-00-00', '', 0, 1, 1, 0, 6, 1, 0, 0, 1, ''),
(7, 'Servicios Hotel', '', '<p style="font-size: 11.8181819915771px;">\n	<strong><u>HOTEL CRISTAL GOLD</u></strong>, de categor&iacute;a 3 estrellas posee una excelente ubicaci&oacute;n c&eacute;ntrica, situado en el coraz&oacute;n de la provincia de Mendoza, a pasos de la actividad comercial, financiera y art&iacute;stica. Rodeado de los mejores Restaurants, Vinotecas y Tiendas. Brindamos un clima de calidez, un servicio impecable y una atenci&oacute;n personalizada.</p>\n<div style="font-size: 11.8181819915771px;">\n	Nuestro objetivo es lograr una experiencia &uacute;nica en cada visita a nuestro Hotel y junto con nuestro staff de colaboradores buscamos satifacerlo brindando un servicio acorde a sus necesidades.&nbsp;</div>\n<div style="font-size: 11.8181819915771px;">\n	&nbsp;</div>\n<div style="font-size: 11.8181819915771px;">\n	Se detallan a continuaci&oacute;n los servicios ofrecidos</div>\n<div>\n	&nbsp;</div>\n<p>\n	<img height="60%" src="http://www.hotelcarollo.com/test//assets/uploads/articulos/sin.png" uploads="" /></p>\n', '2014-11-01', '0000-00-00', '', 0, 1, 5, 0, 6, 1, 0, 0, 1, ''),
(8, 'Servicios Hotel', '', '<p>\n	<img height="60%" src="http://www.hotelcarollo.com/test//assets/uploads/articulos/sin.png" uploads="" /></p>', '2014-11-01', '0000-00-00', '', 0, 1, 4, 0, 6, 1, 0, 0, 1, ''),
(9, 'PROMO 4 X 3', 'Te esperamos para que disfrutes de nuestros servicios alojandote 4 noches y abonando sólo 3 noches!!!', '<p style="font-size: 11.8181819915771px; text-align: center;">\r\n	<u>PROMO 4X3!!</u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size: 16px;">Te esperamos para que disfrutes de nuestros servicios alojandote 4 noches y abonando s&oacute;lo 3 noches!!!</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	No incluye temporada alta ni fines de semana largo.&nbsp;</p>\r\n<div>\r\n	&nbsp;</div>\r\n', '2014-11-05', '0000-00-00', '15531-34ce6-img_3766.jpg', 1, 1, 3, 1, 3, 1, 1, 0, 1, ''),
(10, 'PROMO 4X3', 'Te esperamos para que disfrutes de nuestros servicios alojandote 4 noches y abonando sólo 3 noches!!!', '<p style="font-size: 11.8181819915771px; text-align: center;">\r\n	<u>PROMO 4X3!!</u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size: 16px;">Te esperamos para que disfrutes de nuestros servicios alojandote 4 noches y abonando s&oacute;lo 3 noches!!!</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	No incluye temporada alta ni fines de semana largo.&nbsp;</p>\r\n<div>\r\n	&nbsp;</div>\r\n', '2014-11-05', '0000-00-00', 'd16a4-images-(3).jpg', 1, 1, 2, 1, 3, 1, 1, 0, 1, ''),
(11, 'PROMO 4X3', '', '<p style="font-size: 11.8181819915771px; text-align: center;">\n	<u>PROMO 4X3!!</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">Te esperamos para que disfrutes de nuestros servicios alojandote 4 noches y abonando s&oacute;lo 3 noches!!!</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\n<p style="font-size: 11.8181819915771px;">\n	No incluye temporada alta ni fines de semana largo.&nbsp;</p>\n<div>\n	&nbsp;</div>\n', '2014-11-05', '0000-00-00', '81eb4-images-(4).jpg', 1, 1, 5, 1, 3, 1, 1, 0, 1, ''),
(12, 'PROMO 7X6', '', '<p style="font-size: 11.8181819915771px; text-align: center;">\n	<u>PROMO 7X6!!</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">Te esperamos para que disfrutes de nuestros servicios alojandote 7 noches y abonando solo 6 noches!!!</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\n<p style="font-size: 11.8181819915771px;">\n	&nbsp;</p>\n<div>\n	&nbsp;</div>\n', '2014-11-05', '0000-00-00', 'c431f-descarga.jpg', 0, 1, 1, 1, 3, 1, 1, 0, 1, ''),
(13, 'PROMO 7X6', 'Te esperamos para que disfrutes de nuestros servicios alojandote 7 noches y abonando solo 6 noches!!!', '<p style="font-size: 11.8181819915771px; text-align: center;">\r\n	<u>PROMO 7X6!!</u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size: 16px;">Te esperamos para que disfrutes de nuestros servicios alojandote 7 noches y abonando solo 6 noches!!!</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\r\n', '2014-11-05', '0000-00-00', 'c12b5-94615-img_3820.jpg', 1, 1, 3, 1, 3, 1, 1, 0, 1, ''),
(14, 'PROMO 7X6', '', '<p style="font-size: 11.8181819915771px; text-align: center;">\n	<u>PROMO 7X6!!</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">Te esperamos para que disfrutes de nuestros servicios alojandote 7 noches y abonando solo 6 noches!!!</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\n', '2014-11-05', '0000-00-00', '452f3-2.jpg', 0, 1, 2, 1, 3, 1, 1, 0, 1, ''),
(15, 'PROMO 7X6', '', '<p style="font-size: 11.8181819915771px; text-align: center;">\n	<u>PROMO 7X6!!</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">Te esperamos para que disfrutes de nuestros servicios alojandote 7 noches y abonando solo 6 noches!!!</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\n', '2014-11-05', '0000-00-00', '47fae-images-(6).jpg', 0, 1, 5, 1, 3, 1, 1, 0, 1, ''),
(16, 'PROMO OTOÑO ESPECIAL', '', '<p style="font-size: 11.8181819915771px; text-align: center;">\n	<u>OTO&Ntilde;O ESPECIAL!!</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">En Oto&ntilde;o veni a disfrutar Mendoza con un 30% de descuento si tu estadia es mayor de 3 d&iacute;as!! Para los meses Abril, Mayo y Junio.</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\n<p>\n	<span style="font-size:12px;">No aplicable en Semana Santa y fines de Semana Largo, ni acumulable con otras promociones.</span></p>\n', '2014-11-05', '0000-00-00', '28f91-otono1.jpg', 0, 1, 1, 1, 3, 1, 1, 0, 1, ''),
(17, 'PROMO OTOÑO ESPECIAL', '', '<p style="font-size: 11.8181819915771px; text-align: center;">\n	<u>OTO&Ntilde;O ESPECIAL!!</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">En Oto&ntilde;o veni a disfrutar Mendoza con un 30% de descuento si tu estadia es mayor de 3 d&iacute;as!! Para los meses Abril, Mayo y Junio.</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">No aplicable en Semana Santa y fines de Semana Largo, ni acumulable con otras promociones.</span></p>\n', '2014-11-05', '0000-00-00', 'e837b-otono2.jpg', 0, 1, 3, 1, 3, 1, 1, 0, 1, ''),
(18, 'PROMO OTOÑO ESPECIAL', '', '<p style="font-size: 11.8181819915771px; text-align: center;">\n	<u>OTO&Ntilde;O ESPECIAL!!</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">En Oto&ntilde;o veni a disfrutar San Luis con un 30% de descuento si tu estadia es mayor de 3 d&iacute;as!! Para los meses Abril, Mayo y Junio.</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">No aplicable en Semana Santa y fines de Semana Largo, ni acumulable con otras promociones.</span></p>\n', '2014-11-05', '0000-00-00', 'ab660-otono3.jpg', 0, 1, 2, 1, 3, 1, 1, 0, 1, ''),
(19, 'PROMO OTOÑO ESPECIAL', '', '<p style="font-size: 11.8181819915771px; text-align: center;">\n	<u>OTO&Ntilde;O ESPECIAL!!</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">En Oto&ntilde;o veni a disfrutar C&oacute;doba con un 30% de descuento si tu estadia es mayor de 3 d&iacute;as!! Para los meses Abril, Mayo y Junio.</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<font size="3">Para reservar enviarnos una consulta y se la contestaremos a la brevedad.</font></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">No aplicable en Semana Santa y fines de Semana Largo, ni acumulable con otras promociones.</span></p>\n', '2014-11-05', '0000-00-00', '3f14e-otono-4.jpg', 0, 1, 5, 1, 3, 1, 1, 0, 1, ''),
(20, 'PROMO 2X1', '', '<p style="font-size: 11.8181819915771px; text-align: center;">\n	<u>PROMO 2X1!</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;"><span style="font-family: Arial;">Ingresando s&oacute;lo los domingos y lunes se aloja 2 noches y abona &nbsp;1 &nbsp;noche!&nbsp;</span></span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;"><span style="font-family: Arial;">Sujeto a disponibilidad, todo el a&ntilde;o.</span></span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;"><span style="font-family: Arial;">Para reservar envianos una consulta y contestaremos a la brevedad.</span></span></p>\n', '2014-11-05', '0000-00-00', '13aca-sl1.jpg', 0, 1, 5, 1, 3, 1, 1, 0, 1, ''),
(21, 'Tarifas Corporativas', '', '<p>\n	<span style="font-size:16px;">Nuestra cadena de Hoteles Gold Argentina ofrece para su cartera de clientes corporativos, <u><em>Tarifas Especiales.</em></u></span></p>\n<p>\n	<span style="font-size:16px;">Hacemos su viaje de Negocio mas placentero, con servicios especiales para usted y su empresa.</span></p>\n<ul>\n	<li>\n		<span style="font-size:16px;">Sal&oacute;n Vip para 15 personas.</span></li>\n	<li>\n		<span style="font-size:16px;">Sal&oacute;n Garden para 150 personas.</span></li>\n	<li>\n		<span style="font-size:16px;">Wi Fi</span></li>\n	<li>\n		<span style="font-size:16px;">Retroproyector y Coffe Break</span></li>\n</ul>\n<p>\n	<span style="font-size:16px;"><u>TARIFAS</u></span></p>\n<p>\n	<span style="font-size:16px;">Habitaci&oacute;n Single $</span></p>\n<p>\n	<span style="font-size:16px;">Habitaci&oacute;n Doble $</span></p>\n<p>\n	<span style="font-size:16px;">Habitaci&oacute;n Triple $</span></p>\n<p>\n	<span style="font-size:16px;">Para reservar enviarnos una consulta que a la brevedad la responderemos.</span></p>\n', '2014-11-18', '0000-00-00', '89593-negocio}.jpg', 1, 1, 1, 1, 13, 1, 1, 0, 1, ''),
(22, 'Tarifas Corporativas', 'Nuestra cadena de Hoteles Gold Argentina ofrece para su cartera de clientes corporativos, Tarifas Especiales.', '<p>\r\n	<span style="font-size:16px;">Nuestra cadena de Hoteles Gold Argentina ofrece para su cartera de clientes corporativos,&nbsp;<u><em>Tarifas Especiales.</em></u></span></p>\r\n<p>\r\n	<span style="font-size:16px;">Hacemos su viaje de Negocio mas placentero, con servicios especiales para usted y su empresa.</span></p>\r\n<ul>\r\n	<li>\r\n		<span style="font-size:16px;">Sal&oacute;n Vip para 15 personas.</span></li>\r\n	<li>\r\n		<span style="font-size:16px;">Sal&oacute;n Garden para 150 personas.</span></li>\r\n	<li>\r\n		<span style="font-size:16px;">Wi Fi</span></li>\r\n	<li>\r\n		<span style="font-size:16px;">Retroproyector y Coffe Break</span></li>\r\n</ul>\r\n<p>\r\n	<span style="font-size:16px;"><u>TARIFAS</u></span></p>\r\n<p>\r\n	<span style="font-size:16px;">Habitaci&oacute;n Single $</span></p>\r\n<p>\r\n	<span style="font-size:16px;">Habitaci&oacute;n Doble $</span></p>\r\n<p>\r\n	<span style="font-size:16px;">Habitaci&oacute;n Triple $</span></p>\r\n<p>\r\n	<font size="3">Habitaci&oacute;n Cu&aacute;druple $</font></p>\r\n<p>\r\n	<font size="3">Habitaci&oacute;n Suite $</font></p>\r\n<p>\r\n	<span style="font-size:16px;">Para reservar enviarnos una consulta que a la brevedad la responderemos.</span></p>\r\n', '2014-11-18', '0000-00-00', 'e4455-ef91e-img_3929.jpg', 0, 1, 3, 1, 13, 1, 1, 0, 1, ''),
(23, 'Tarifas Corporativas', 'Nuestra cadena de Hoteles Gold Argentina ofrece para su cartera de clientes corporativos, Tarifas Especiales.', '<p>\r\n	<span style="font-size: 16px;">Nuestra cadena de Hoteles Gold Argentina ofrece para su cartera de clientes corporativos,&nbsp;<u><em>Tarifas Especiales.</em></u></span></p>\r\n<p>\r\n	<span style="font-size: 16px;">Hacemos su viaje de Negocio mas placentero, con servicios especiales para usted y su empresa.</span></p>\r\n<ul>\r\n	<li>\r\n		<span style="font-size: 16px;">Sal&oacute;n</span><span style="font-size: 16px;">&nbsp;Vip para 15 personas</span></li>\r\n	<li>\r\n		<span style="font-size: 16px;">Sal&oacute;n los Cedros para 150 personas.</span></li>\r\n	<li>\r\n		<span style="font-size: 16px;">Wi Fi</span></li>\r\n	<li>\r\n		<span style="font-size: 16px;">Retroproyector y Coffe Break</span></li>\r\n</ul>\r\n<p>\r\n	<span style="font-size: 16px;"><u>TARIFAS</u></span></p>\r\n<p>\r\n	<span style="font-size: 16px;">Habitaci&oacute;n Single $</span></p>\r\n<p>\r\n	<span style="font-size: 16px;">Habitaci&oacute;n Doble $</span></p>\r\n<p>\r\n	<span style="font-size: 16px;">Habitaci&oacute;n Triple $</span></p>\r\n<p>\r\n	<span style="font-size: medium;">Habitaci&oacute;n Cu&aacute;druple $</span></p>\r\n<p>\r\n	<font size="3">Habitaci&oacute;n Suite $</font></p>\r\n<p>\r\n	<span style="font-size: 16px;">Para reservar enviarnos una consulta que a la brevedad la responderemos.</span></p>\r\n', '2014-11-18', '0000-00-00', 'bb241-negocio}.jpg', 1, 1, 2, 1, 13, 1, 1, 0, 1, ''),
(24, 'Tarifas Corporativas', '', '<p>\n	<span style="font-size: 16px;">Nuestra cadena de Hoteles Gold Argentina ofrece para su cartera de clientes corporativos,&nbsp;<u><em>Tarifas Especiales.</em></u></span></p>\n<p>\n	<span style="font-size: 16px;">Hacemos su viaje de Negocio mas placentero, con servicios especiales para usted y su empresa.</span></p>\n<ul>\n	<li>\n		<span style="font-size: 16px;">Sal&oacute;n Vip para 25 &nbsp;personas.</span></li>\n	<li>\n		<span style="font-size: 16px;">Sal&oacute;n &nbsp;para 100 personas.</span></li>\n	<li>\n		<span style="font-size: 16px;">Wi Fi</span></li>\n	<li>\n		<span style="font-size: 16px;">Retroproyector y Coffe Break</span></li>\n</ul>\n<p>\n	<span style="font-size: 16px;"><u>TARIFAS</u></span></p>\n<p>\n	<span style="font-size: 16px;">Habitaci&oacute;n Single $</span></p>\n<p>\n	<span style="font-size: 16px;">Habitaci&oacute;n Doble $</span></p>\n<p>\n	<span style="font-size: 16px;">Habitaci&oacute;n Triple $</span></p>\n<p>\n	<span style="font-size: 16px;">Habitaci&oacute;n Cu&aacute;druple $</span></p>\n<p>\n	<span style="font-size: 16px;">Habitaci&oacute;n Qu&iacute;ntuple $</span></p>\n<p>\n	<span style="font-size: 16px;">Para reservar enviarnos una consulta que a la brevedad la responderemos.</span></p>\n', '2014-11-18', '0000-00-00', '29281-negocio}.jpg', 1, 1, 5, 1, 13, 1, 1, 0, 1, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ayudas`
--

CREATE TABLE IF NOT EXISTS `ayudas` (
  `id_ayuda` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(128) NOT NULL,
  `ayuda` text NOT NULL,
  `id_idioma` int(11) NOT NULL,
  `sector` varchar(32) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_ayuda`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(64) CHARACTER SET latin1 NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=14 ;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `categoria`, `delete`) VALUES
(1, 'Ofertas', 1),
(2, 'Paquetes', 1),
(3, 'Promociones', 0),
(4, 'Eventos', 1),
(5, 'Actividades', 0),
(6, 'Servicios', 0),
(7, 'Comidas', 1),
(8, 'Tragos', 1),
(9, 'Noticias', 1),
(10, 'Turismo', 1),
(11, '123', 1),
(12, 'Transfer', 0),
(13, 'Empresas e Instituciones', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('b4df6943003c7259f8aed44ecd50ba7f', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2224.3 Safari/537.36', 1417800738, 'a:2:{s:9:"user_data";s:0:"";s:9:"logged_in";a:2:{s:10:"id_usuario";s:1:"1";s:7:"usuario";s:5:"admin";}}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `id_config` int(11) NOT NULL AUTO_INCREMENT,
  `id_hotel` int(11) NOT NULL,
  `css` varchar(128) CHARACTER SET latin1 NOT NULL,
  `mostrar_tarifa` tinyint(4) NOT NULL,
  `max_adultos` int(11) NOT NULL,
  `max_menores` int(11) NOT NULL,
  `limite_menores` int(11) NOT NULL,
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `config`
--

INSERT INTO `config` (`id_config`, `id_hotel`, `css`, `mostrar_tarifa`, `max_adultos`, `max_menores`, `limite_menores`) VALUES
(1, 2, 'CSS', 10, 5, 5, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_articulos`
--

CREATE TABLE IF NOT EXISTS `config_articulos` (
  `id_config_articulos` int(11) NOT NULL AUTO_INCREMENT,
  `usar_limite` tinyint(4) NOT NULL,
  `max_con_foto` int(11) NOT NULL,
  `max_sin_foto` int(11) NOT NULL,
  PRIMARY KEY (`id_config_articulos`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `config_articulos`
--

INSERT INTO `config_articulos` (`id_config_articulos`, `usar_limite`, `max_con_foto`, `max_sin_foto`) VALUES
(1, 1, 200, 90);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_correo`
--

CREATE TABLE IF NOT EXISTS `config_correo` (
  `id_config_correo` int(11) NOT NULL AUTO_INCREMENT,
  `gestor_correo` enum('PHP Mail','Send Mail','SMTP') NOT NULL,
  `correo` int(11) NOT NULL,
  `seguridad_smtp` enum('Ninguna','SSL','TSL') NOT NULL,
  `puerto_smtp` int(11) NOT NULL,
  `usuario_smtp` int(11) NOT NULL,
  `pass_smtp` int(11) NOT NULL,
  `hospedaje_smtp` int(11) NOT NULL,
  `autenticacion_smtp` tinyint(4) NOT NULL,
  `remitente` int(11) NOT NULL,
  PRIMARY KEY (`id_config_correo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `config_correo`
--

INSERT INTO `config_correo` (`id_config_correo`, `gestor_correo`, `correo`, `seguridad_smtp`, `puerto_smtp`, `usuario_smtp`, `pass_smtp`, `hospedaje_smtp`, `autenticacion_smtp`, `remitente`) VALUES
(1, 'SMTP', 1, 'Ninguna', 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_email_habitacion`
--

CREATE TABLE IF NOT EXISTS `config_email_habitacion` (
  `id_config_email_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_correo` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `correo` text NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_config_email_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `config_email_habitacion`
--

INSERT INTO `config_email_habitacion` (`id_config_email_habitacion`, `id_tipo_correo`, `id_hotel`, `correo`, `delete`) VALUES
(1, 1, 1, '', 0),
(2, 2, 1, '<p>\n	<em style="font-size: 11.8181819915771px;"><u>HOTEL CAROLLO GOLD&nbsp;</u></em></p>\n<p>\n	<span style="font-size: 12px;">Le informa que el Sr/a&nbsp;</span><span style="font-size: 11.8181819915771px;">#emisor_nombre#&nbsp;</span><span style="font-size: 11.8181819915771px;">#emisor_apellido#&nbsp;</span><span style="font-size: 12px;">le ha compartido una habitaci&oacute;n&nbsp;</span><span style="font-size: 12px;">que podr&aacute; acceder con el siguiente link:</span></p>\n<p>\n	<span style="font-size: 12px;">#habitacion#</span></p>\n<p>\n	<span style="font-size: 11.8181819915771px;">#mensaje#</span></p>\n<p>\n	<span style="font-size: 12px;">Saludos muy atte&nbsp;</span></p>\n<p>\n	<strong><span style="font-size: 12px;">HOTELES GOLD ARGENTINA</span></strong></p>\n<p>\n	&nbsp;</p>\n<p>\n	&nbsp;</p>\n', 0),
(3, 1, 2, '', 0),
(4, 2, 2, '<p style="font-size: 11.8181819915771px;">\n	<u style="font-size: 12px;">GRAN&nbsp;</u><em style="font-size: 12px;"><u><u>HOTE</u>L SAN LUIS GOLD&nbsp;</u></em></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">Le informa que el Sr/a&nbsp;</span><span style="font-size: 11.8181819915771px;">#emisor_nombre#&nbsp;</span><span style="font-size: 11.8181819915771px;">#emisor_apellido#&nbsp;</span><span style="font-size: 12px;">le ha compartido una habitaci&oacute;n&nbsp;</span><span style="font-size: 12px;">que podr&aacute; acceder con el siguiente link:</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">#habitacion#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#mensaje#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">Saludos muy atte&nbsp;</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong><span style="font-size: 12px;">HOTELES GOLD ARGENTINA</span></strong></p>\n', 0),
(5, 1, 3, '', 0),
(6, 2, 3, '<p style="font-size: 11.8181819915771px;">\n	<u style="font-size: 12px;">GRAN&nbsp;</u><em style="font-size: 12px;"><u><u>HOTE</u>L PRINCESS GOLD</u></em></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">Le informa que el Sr/a&nbsp;</span><span style="font-size: 11.8181819915771px;">#emisor_nombre#&nbsp;</span><span style="font-size: 11.8181819915771px;">#emisor_apellido#&nbsp;</span><span style="font-size: 12px;">le ha compartido una habitaci&oacute;n&nbsp;</span><span style="font-size: 12px;">que podr&aacute; acceder con el siguiente link:</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">#habitacion#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#mensaje#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">Saludos muy atte&nbsp;</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong><span style="font-size: 12px;">HOTELES GOLD ARGENTINA</span></strong></p>\n<p style="font-size: 11.8181819915771px;">\n	&nbsp;</p>\n', 0),
(7, 1, 4, '', 0),
(8, 2, 4, '', 0),
(9, 1, 5, '', 0),
(10, 2, 5, '<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">&nbsp;</span><em style="font-size: 12px;"><u>HOTEL CRISTAL GOLD&nbsp;</u></em></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">Le informa que el Sr/a&nbsp;</span><span style="font-size: 11.8181819915771px;">#emisor_nombre#&nbsp;</span><span style="font-size: 11.8181819915771px;">#emisor_apellido#&nbsp;</span><span style="font-size: 12px;">le ha compartido una habitaci&oacute;n&nbsp;</span><span style="font-size: 12px;">que podr&aacute; acceder con el siguiente link:</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">#habitacion#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#mensaje#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">Saludos muy atte&nbsp;</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong><span style="font-size: 12px;">HOTELES GOLD ARGENTINA</span></strong></p>\n', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_email_mensaje`
--

CREATE TABLE IF NOT EXISTS `config_email_mensaje` (
  `id_config_email_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_correo` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `correo` text NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_config_email_mensaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `config_email_mensaje`
--

INSERT INTO `config_email_mensaje` (`id_config_email_mensaje`, `id_tipo_correo`, `id_hotel`, `correo`, `delete`) VALUES
(1, 1, 1, '<p style="font-size: 11.8181819915771px;">\n	SE HA RECIBIDO UNA CONSULTA DE<strong><u>&nbsp;WWW.HOTELCAROLLO.COM.AR&nbsp;</u></strong></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>POR FAVOR CONTESTAR A LA BREVEDAD</strong></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#hotel#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>CLIENTE</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;"><strong>Nombre:</strong> #emisor_nombre# <strong>Apellido:&nbsp;</strong></span><span style="font-size: 11.8181819915771px;">#emisor_apellido#&nbsp;</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;"><strong>Tel&eacute;fono:</strong> #emisor_telefono#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>EMAIL</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#emisor_email#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>MENSAJE</u></p>\n<p style="font-size: 11.8181819915771px;">\n	#mensaje#</p>\n', 0),
(2, 2, 1, '<p>\n	<span style="font-size: 12px;">Estimado Cliente</span></p>\n<p>\n	Hemos recibido su consulta</p>\n<p>\n	A la brevedad le contestaremos.</p>\n<p>\n	saludos atte&nbsp;</p>\n<p>\n	HOTEL CAROLLO GOLD</p>\n<p>\n	&nbsp;</p>\n', 0),
(3, 1, 2, '<p style="font-size: 11.8181819915771px;">\n	SE HA RECIBIDO UNA CONSULTA DE<strong><u>&nbsp;WWW.HOTELSANLUIS.COM.AR&nbsp;</u></strong></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>POR FAVOR CONTESTAR A LA BREVEDAD&nbsp;</strong></p>\n<p style="font-size: 11.8181819915771px;">\n	HOTEL</p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#hotel#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>CLIENTE</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;"><strong>Nombre:</strong>&nbsp;#emisor_nombre#&nbsp;<strong>Apellido:&nbsp;</strong></span><span style="font-size: 11.8181819915771px;">#emisor_apellido#&nbsp;</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;"><strong>Tel&eacute;fono:</strong>&nbsp;#emisor_telefono#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>EMAIL</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#emisor_email#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>MENSAJE</u></p>\n<p style="font-size: 11.8181819915771px;">\n	#mensaje#</p>\n', 0),
(4, 2, 2, '<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">Estimado Cliente</span></p>\n<p style="font-size: 11.8181819915771px;">\n	Hemos recibido su consulta</p>\n<p style="font-size: 11.8181819915771px;">\n	A la brevedad le contestaremos.</p>\n<p style="font-size: 11.8181819915771px;">\n	saludos atte&nbsp;</p>\n<p style="font-size: 11.8181819915771px;">\n	GRAN HOTEL SAN LUIS GOLD</p>\n', 0),
(5, 1, 3, '<p style="font-size: 11.8181819915771px;">\n	SE HA RECIBIDO UNA CONSULTA DE<strong><u>&nbsp;WWW.HOTELPRINCESS.COM.AR&nbsp;</u></strong></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>POR FAVOR CONTESTAR A LA BREVEDAD&nbsp;</strong></p>\n<p style="font-size: 11.8181819915771px;">\n	HOTEL</p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#hotel#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>CLIENTE</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;"><strong>Nombre:</strong>&nbsp;#emisor_nombre#&nbsp;<strong>Apellido:&nbsp;</strong></span><span style="font-size: 11.8181819915771px;">#emisor_apellido#&nbsp;</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;"><strong>Tel&eacute;fono:</strong>&nbsp;#emisor_telefono#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>EMAIL</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#emisor_email#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>MENSAJE</u></p>\n<p style="font-size: 11.8181819915771px;">\n	#mensaje#</p>\n', 0),
(6, 2, 3, '<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">Estimado Cliente</span></p>\n<p style="font-size: 11.8181819915771px;">\n	Hemos recibido su consulta</p>\n<p style="font-size: 11.8181819915771px;">\n	A la brevedad le contestaremos.</p>\n<p style="font-size: 11.8181819915771px;">\n	saludos atte&nbsp;</p>\n<p style="font-size: 11.8181819915771px;">\n	GRAN HOTEL PRINCESS GOLD</p>\n', 0),
(7, 1, 4, '', 0),
(8, 2, 4, '', 0),
(9, 1, 5, '<p style="font-size: 11.8181819915771px;">\n	SE HA RECIBIDO UNA CONSULTA DE<strong><u>&nbsp;WWW.HOTELCRISTAL.COM.AR&nbsp;</u></strong></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>POR FAVOR CONTESTAR A LA BREVEDAD&nbsp;</strong></p>\n<p style="font-size: 11.8181819915771px;">\n	HOTEL</p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#hotel#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>CLIENTE</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;"><strong>Nombre:</strong>&nbsp;#emisor_nombre#&nbsp;<strong>Apellido:&nbsp;</strong></span><span style="font-size: 11.8181819915771px;">#emisor_apellido#&nbsp;</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;"><strong>Tel&eacute;fono:</strong>&nbsp;#emisor_telefono#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>EMAIL</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#emisor_email#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>MENSAJE</u></p>\n<p style="font-size: 11.8181819915771px;">\n	#mensaje#</p>\n', 0),
(10, 2, 5, '<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">Estimado Cliente</span></p>\n<p style="font-size: 11.8181819915771px;">\n	Hemos recibido su consulta</p>\n<p style="font-size: 11.8181819915771px;">\n	A la brevedad le contestaremos.</p>\n<p style="font-size: 11.8181819915771px;">\n	saludos atte&nbsp;</p>\n<p style="font-size: 11.8181819915771px;">\n	HOTEL CRISTAL GOLD</p>\n', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_email_reserva`
--

CREATE TABLE IF NOT EXISTS `config_email_reserva` (
  `id_config_email_reserva` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_correo` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `correo` text NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_config_email_reserva`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `config_email_reserva`
--

INSERT INTO `config_email_reserva` (`id_config_email_reserva`, `id_tipo_correo`, `id_hotel`, `correo`, `delete`) VALUES
(1, 1, 1, '<p>\r\n	<u><strong>NUEVA RESERVA CONFIRMADA DESDE WWW.HOTELCAROLLO.COM.AR PARA &nbsp;</strong></u></p>\r\n<p>\r\n	#hotel# RESERVA N&deg;&nbsp;<span style="font-size: 11.8181819915771px;">#reserva_numero#</span></p>\r\n<p>\r\n	<u>PASAJERO</u></p>\r\n<p>\r\n	<strong>Nombre:</strong> #huesped_nombre# &nbsp; <strong>Apellido:</strong> #huesped_apellido#</p>\r\n<p>\r\n	<span style="font-size: 12px;"><strong>Email: </strong>#huesped_email#</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<strong>Tel&eacute;fono:</strong> #huesped_telefono#</p>\r\n<p>\r\n	<u>ESTADIA</u></p>\r\n<p>\r\n	<strong>Ingreso:</strong> #entrada# &nbsp;<strong>Egreso:</strong> #salida#</p>\r\n<p>\r\n	<u>TIPO DE HABITACION</u></p>\r\n<p>\r\n	<span style="font-size: 11.8181819915771px;">#cant_habitacion#</span></p>\r\n<p>\r\n	<span style="font-size: 12px;"><strong>Adultos:</strong> #adultos# <strong>Menores:</strong>&nbsp;</span><span style="font-size: 12px;">#menores#</span></p>\r\n<p>\r\n	<u>TARIFA&nbsp;</u></p>\r\n<p>\r\n	<span style="font-size: 11.8181819915771px;">$#reserva_precio# por noche</span></p>\r\n<p>\r\n	<u><span style="font-size: 12px;">DATOS DE TARJETA DE CONFIRMACION</span></u></p>\r\n<p>\r\n	<strong>Tipo:</strong> #huesped_id_tipo_tarjeta#</p>\r\n<p>\r\n	<strong>N&uacute;mero:</strong> #tarjeta_numero#</p>\r\n<p>\r\n	<strong>Pin:</strong> #tarjeta_pin#</p>\r\n<p>\r\n	<strong>Vencimiento:</strong> #tarjeta_vencimiento#</p>\r\n<p>\r\n	<u style="font-size: 11.8181819915771px;">COMENTARIOS</u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	#nota#</p>\r\n<p>\r\n	<u>TRANSFER</u></p>\r\n<p>\r\n	<strong>Aerolinea:&nbsp;</strong><span style="font-size: 11.8181819915771px;">#</span><span style="font-size: 12px;">vuelo_aerolinea#</span></p>\r\n<p>\r\n	<strong>N&uacute;mero:&nbsp;</strong><span style="font-size: 12px;">#vuelo_numero#&nbsp;</span></p>\r\n<p>\r\n	<strong><span style="font-size: 12px;">Horario de llegada:&nbsp;</span></strong><span style="font-size: 12px;">#vuelo_horario</span><span style="font-size: 11.8181819915771px;">#</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n', 0),
(2, 2, 1, '<p style="font-size: 11.8181819915771px;">\r\n	<u><strong>Sr/a&nbsp;<span style="font-size: 11.8181819915771px;">#huesped_nombre# &nbsp;#huesped_apellido#</span></strong></u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size: 11.8181819915771px;">se ha confirmado su reserva n&uacute;mero&nbsp;</span><span style="font-size: 11.8181819915771px;">#reserva_numero#</span><span style="font-size: 11.8181819915771px;">&nbsp;en&nbsp;</span><strong style="font-size: 11.8181819915771px;">WWW.HOTELCAROLLO.COM.AR </strong><span style="font-size: 11.8181819915771px;">para</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	#hotel#</p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<u>SU ESTADIA ES PARA</u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<strong>Ingreso: </strong>#entrada# <strong>&nbsp;Egreso: </strong>#salida#</p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<u>SU TIPO DE HABITACION ES</u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size: 11.8181819915771px;">#cant_habitacion#</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size: 12px;"><strong>Adultos:</strong> #adultos# <strong>Menores:&nbsp;</strong></span><span style="font-size: 12px;">#menores#</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<u>LA TARIFA RESERVADA ES&nbsp;</u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size: 11.8181819915771px;">$#reserva_precio# por noche.</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<em><span style="font-size: 12px;">LA &nbsp;CONFIRMACION DE LA RESERVA ES MEDIANTE SU TARJETA DE CREDITO, LA CUAL SE USA SOLO COMO GARANTIA. NO SE GENARAN GASTOS DE LA MISMA.&nbsp;</span></em></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<u>TRANSFER</u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size: 11.8181819915771px;"><strong>Aerolinea: </strong>#vuelo_aerolinea#</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<strong><span style="font-size: 11.8181819915771px;">N&uacute;mero:&nbsp;</span></strong><span style="font-size: 12px;">#vuelo_numero#&nbsp;</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<strong><span style="font-size: 12px;">Horario de llegada:&nbsp;</span></strong><span style="font-size: 12px;">#vuelo_horario_llegada#</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<u><span style="font-size: 12px;">TERMINOS Y CONDICIONES DE SU RESERVA</span></u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size: 12px;">#terminos#</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<strong><span style="font-size: 12px;">LO ESTAREMOS ESPERANDO</span></strong></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size:16px;"><strong>HOTEL CAROLLO GOLD</strong></span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size:16px;">25 de Mayo 1184, Mendoza</span></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	<span style="font-size:16px;">tel&eacute;fono: 0261 4235666</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', 0),
(3, 1, 2, '<p style="font-size: 11.8181819915771px;">\n	<u><strong>NUEVA RESERVA CONFIRMADA DESDE WWW.HOTELSANLUISCOM.AR PARA &nbsp;</strong></u></p>\n<p style="font-size: 11.8181819915771px;">\n	#hotel# RESERVA N&deg;&nbsp;<span style="font-size: 11.8181819915771px;">#reserva_numero#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>PASAJERO</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Nombre:</strong>&nbsp;#huesped_nombre# &nbsp;&nbsp;<strong>Apellido:</strong>&nbsp;#huesped_apellido#</p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;"><strong>Email:&nbsp;</strong>#huesped_email#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Tel&eacute;fono:</strong>&nbsp;#huesped_telefono#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>ESTADIA</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Ingreso:</strong>&nbsp;#entrada# &nbsp;<strong>Egreso:</strong>&nbsp;#salida#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>TIPO DE HABITACION</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#cant_habitacion#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;"><strong>Adultos:</strong>&nbsp;#adultos#&nbsp;<strong>Menores:</strong>&nbsp;</span><span style="font-size: 12px;">#menores#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>TARIFA&nbsp;</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">$#reserva_precio# por noche</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u><span style="font-size: 12px;">DATOS DE TARJETA DE CONFIRMACION</span></u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Tipo:</strong>&nbsp;#huesped_id_tipo_tarjeta#</p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>N&uacute;mero:</strong>&nbsp;#tarjeta_numero#</p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Pin:</strong>&nbsp;#tarjeta_pin#</p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Vencimiento:</strong>&nbsp;#tarjeta_vencimiento#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u style="font-size: 11.8181819915771px;">COMENTARIOS</u></p>\n<p style="font-size: 11.8181819915771px;">\n	#nota#</p>\n<p style="font-size: 11.8181819915771px;">\n	&nbsp;</p>\n', 0),
(4, 2, 2, '<p style="font-size: 11.8181819915771px;">\n	<u><strong>Sr/a&nbsp;<span style="font-size: 11.8181819915771px;">#huesped_nombre# &nbsp;#huesped_apellido#</span></strong></u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">se ha confirmado su reserva&nbsp;</span><span style="font-size: 11.8181819915771px;">&nbsp;n&uacute;mero&nbsp;</span><span style="font-size: 11.8181819915771px;">#reserva_numero#</span><span style="font-size: 11.8181819915771px;">&nbsp;</span><span style="font-size: 11.8181819915771px;">en&nbsp;</span><strong style="font-size: 11.8181819915771px;">WWW.HOTELSANLUIS.COM.AR&nbsp;</strong><span style="font-size: 11.8181819915771px;">para</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#hotel#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>SU ESTADIA ES PARA</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Ingreso:&nbsp;</strong>#entrada#&nbsp;<strong>&nbsp;Egreso:&nbsp;</strong>#salida#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>SU TIPO DE HABITACION ES</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#cant_habitacion#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;"><strong>Adultos:</strong>&nbsp;#adultos#&nbsp;<strong>Menores:&nbsp;</strong></span><span style="font-size: 12px;">#menores#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>LA TARIFA RESERVADA ES&nbsp;</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">$#reserva_precio# por noche.</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<em><span style="font-size: 12px;">LA &nbsp;CONFIRMACION DE LA RESERVA ES MEDIANTE SU TARJETA DE CREDITO, LA CUAL SE USA SOLO COMO GARANTIA. NO SE GENARAN GASTOS DE LA MISMA.&nbsp;</span></em></p>\n<p style="font-size: 11.8181819915771px;">\n	&nbsp;</p>\n<p style="font-size: 11.8181819915771px;">\n	<u><span style="font-size: 12px;">TERMINOS Y CONDICIONES DE SU RESERVA</span></u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">#terminos#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong><span style="font-size: 12px;">LO ESTAREMOS ESPERANDO</span></strong></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;"><strong>GRAN HOTEL SAN LUIS GOLD</strong></span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">Presidente Illia 470, San Luis</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">tel&eacute;fono: 02664 425049</span></p>\n<p>\n	&nbsp;</p>\n', 0),
(5, 1, 3, '<p style="font-size: 11.8181819915771px;">\n	<u><strong>NUEVA RESERVA CONFIRMADA DESDE WWW.HOTELPRINCESS.COM.AR PARA &nbsp;</strong></u></p>\n<p style="font-size: 11.8181819915771px;">\n	#hotel# RESERVA N&deg;&nbsp;<span style="font-size: 11.8181819915771px;">#reserva_numero#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>PASAJERO</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Nombre:</strong>&nbsp;#huesped_nombre# &nbsp;&nbsp;<strong>Apellido:</strong>&nbsp;#huesped_apellido#</p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;"><strong>Email:&nbsp;</strong>#huesped_email#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Tel&eacute;fono:</strong>&nbsp;#huesped_telefono#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>ESTADIA</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Ingreso:</strong>&nbsp;#entrada# &nbsp;<strong>Egreso:</strong>&nbsp;#salida#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>TIPO DE HABITACION</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#cant_habitacion#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;"><strong>Adultos:</strong>&nbsp;#adultos#&nbsp;<strong>Menores:</strong>&nbsp;</span><span style="font-size: 12px;">#menores#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>TARIFA&nbsp;</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">$#reserva_precio# por noche</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u><span style="font-size: 12px;">DATOS DE TARJETA DE CONFIRMACION</span></u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Tipo:</strong>&nbsp;#huesped_id_tipo_tarjeta#</p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>N&uacute;mero:</strong>&nbsp;#tarjeta_numero#</p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Pin:</strong>&nbsp;#tarjeta_pin#</p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Vencimiento:</strong>&nbsp;#tarjeta_vencimiento#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u style="font-size: 11.8181819915771px;">COMENTARIOS</u></p>\n<p style="font-size: 11.8181819915771px;">\n	#nota#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>TRANSFER</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Aerolinea:&nbsp;</strong><span style="font-size: 11.8181819915771px;">#</span><span style="font-size: 12px;">vuelo_aerolinea#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>N&uacute;mero:&nbsp;</strong><span style="font-size: 12px;">#vuelo_numero#&nbsp;</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong><span style="font-size: 12px;">Horario de llegada:&nbsp;</span></strong><span style="font-size: 12px;">#vuelo_horario</span><span style="font-size: 11.8181819915771px;">#</span></p>\n', 0),
(6, 2, 3, '<p style="font-size: 11.8181819915771px;">\n	<u><strong>Sr/a&nbsp;<span style="font-size: 11.8181819915771px;">#huesped_nombre# &nbsp;#huesped_apellido#</span></strong></u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">se ha confirmado su reserva&nbsp;</span><span style="font-size: 11.8181819915771px;">&nbsp;n&uacute;mero&nbsp;</span><span style="font-size: 11.8181819915771px;">#reserva_numero#</span><span style="font-size: 11.8181819915771px;">&nbsp;</span><span style="font-size: 11.8181819915771px;">en&nbsp;</span><strong style="font-size: 11.8181819915771px;">WWW.HOTELPRINCESS.COM.AR&nbsp;</strong><span style="font-size: 11.8181819915771px;">para</span></p>\n<p style="font-size: 11.8181819915771px;">\n	#hotel#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>SU ESTADIA ES PARA</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Ingreso:&nbsp;</strong>#entrada#&nbsp;<strong>&nbsp;Egreso:&nbsp;</strong>#salida#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>SU TIPO DE HABITACION ES</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#cant_habitacion#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;"><strong>Adultos:</strong>&nbsp;#adultos#&nbsp;<strong>Menores:&nbsp;</strong></span><span style="font-size: 12px;">#menores#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>LA TARIFA RESERVADA ES&nbsp;</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">$#reserva_precio# por noche.</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<em><span style="font-size: 12px;">LA &nbsp;CONFIRMACION DE LA RESERVA ES MEDIANTE SU TARJETA DE CREDITO, LA CUAL SE USA SOLO COMO GARANTIA. NO SE GENARAN GASTOS DE LA MISMA.&nbsp;</span></em></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>TRANSFER</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;"><strong>Aerolinea:&nbsp;</strong>#vuelo_aerolinea#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>N&uacute;mero:&nbsp;</strong><span style="font-size: 12px;">#vuelo_numero#&nbsp;</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong><span style="font-size: 12px;">Horario de llegada:&nbsp;</span></strong><span style="font-size: 12px;">#vuelo_horario_llegada#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u><span style="font-size: 12px;">TERMINOS Y CONDICIONES DE SU RESERVA</span></u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">#terminos#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong><span style="font-size: 12px;">LO ESTAREMOS ESPERANDO</span></strong></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;"><strong>GRAN HOTEL PRINCESS GOLD</strong></span></p>\n<div>\n	<p style="font-size: 11.8181819915771px;">\n		<span style="font-size: 16px;">25 de Mayo 1168, Mendoza</span></p>\n	<p style="font-size: 11.8181819915771px;">\n		<span style="font-size: 16px;">Tel&eacute;fono: 0261 4235669</span></p>\n</div>\n<p>\n	&nbsp;</p>\n', 0),
(7, 1, 4, '', 0),
(8, 2, 4, '', 0),
(9, 1, 5, '<p style="font-size: 11.8181819915771px;">\n	<u><strong>NUEVA RESERVA CONFIRMADA DESDE WWW.HOTELCRISTALCOM.AR PARA &nbsp;</strong></u></p>\n<p style="font-size: 11.8181819915771px;">\n	#hotel# RESERVA N&deg;&nbsp;<span style="font-size: 11.8181819915771px;">#reserva_numero#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>PASAJERO</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Nombre:</strong>&nbsp;#huesped_nombre# &nbsp;&nbsp;<strong>Apellido:</strong>&nbsp;#huesped_apellido#</p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;"><strong>Email:&nbsp;</strong>#huesped_email#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Tel&eacute;fono:</strong>&nbsp;#huesped_telefono#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>ESTADIA</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Ingreso:</strong>&nbsp;#entrada# &nbsp;<strong>Egreso:</strong>&nbsp;#salida#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>TIPO DE HABITACION</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#cant_habitacion#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;"><strong>Adultos:</strong>&nbsp;#adultos#&nbsp;<strong>Menores:</strong>&nbsp;</span><span style="font-size: 12px;">#menores#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>TARIFA&nbsp;</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">$#reserva_precio# por noche</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u><span style="font-size: 12px;">DATOS DE TARJETA DE CONFIRMACION</span></u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Tipo:</strong>&nbsp;#huesped_id_tipo_tarjeta#</p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>N&uacute;mero:</strong>&nbsp;#tarjeta_numero#</p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Pin:</strong>&nbsp;#tarjeta_pin#</p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Vencimiento:</strong>&nbsp;#tarjeta_vencimiento#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u style="font-size: 11.8181819915771px;">COMENTARIOS</u></p>\n<p style="font-size: 11.8181819915771px;">\n	#nota#</p>\n<p style="font-size: 11.8181819915771px;">\n	&nbsp;</p>\n', 0),
(10, 2, 5, '<p style="font-size: 11.8181819915771px;">\n	<u><strong>Sr/a&nbsp;<span style="font-size: 11.8181819915771px;">#huesped_nombre# &nbsp;#huesped_apellido#</span></strong></u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">se ha confirmado su reserva</span><span style="font-size: 11.8181819915771px;">&nbsp;n&uacute;mero&nbsp;</span><span style="font-size: 11.8181819915771px;">#reserva_numero#</span><span style="font-size: 11.8181819915771px;">&nbsp;</span><span style="font-size: 11.8181819915771px;">en&nbsp;</span><strong style="font-size: 11.8181819915771px;">WWW.HOTELCRISTAL.COM.AR&nbsp;</strong><span style="font-size: 11.8181819915771px;">para</span></p>\n<p style="font-size: 11.8181819915771px;">\n	#hotel#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>SU ESTADIA ES PARA</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong>Ingreso:&nbsp;</strong>#entrada#&nbsp;<strong>&nbsp;Egreso:&nbsp;</strong>#salida#</p>\n<p style="font-size: 11.8181819915771px;">\n	<u>SU TIPO DE HABITACION ES</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">#cant_habitacion#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;"><strong>Adultos:</strong>&nbsp;#adultos#&nbsp;<strong>Menores:&nbsp;</strong></span><span style="font-size: 12px;">#menores#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<u>LA TARIFA RESERVADA ES&nbsp;</u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 11.8181819915771px;">$#reserva_precio# por noche.</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<em><span style="font-size: 12px;">LA &nbsp;CONFIRMACION DE LA RESERVA ES MEDIANTE SU TARJETA DE CREDITO, LA CUAL SE USA SOLO COMO GARANTIA. NO SE GENARAN GASTOS DE LA MISMA.&nbsp;</span></em></p>\n<p style="font-size: 11.8181819915771px;">\n	<u><span style="font-size: 12px;">TERMINOS Y CONDICIONES DE SU RESERVA</span></u></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 12px;">#terminos#</span></p>\n<p style="font-size: 11.8181819915771px;">\n	<strong><span style="font-size: 12px;">LO ESTAREMOS ESPERANDO</span></strong></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;"><strong>HOTEL CRISTAL GOLD</strong></span></p>\n<p style="font-size: 11.8181819915771px;">\n	<span style="font-size: 16px;">Entre R&iacute;os 58, C&oacute;rdoba</span></p>\n<p>\n	<font size="3">Tel&eacute;fono: 0351 4245000</font></p>\n<p style="font-size: 11.8181819915771px;">\n	&nbsp;</p>\n<div>\n	&nbsp;</div>\n', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamentos`
--

CREATE TABLE IF NOT EXISTS `departamentos` (
  `id_departamento` int(5) NOT NULL AUTO_INCREMENT,
  `id_provincia` int(2) NOT NULL,
  `departamento` varchar(128) NOT NULL,
  PRIMARY KEY (`id_departamento`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=575 ;

--
-- Volcado de datos para la tabla `departamentos`
--

INSERT INTO `departamentos` (`id_departamento`, `id_provincia`, `departamento`) VALUES
(1, 1, 'Azul'),
(2, 1, 'Puan'),
(3, 1, 'La Matanza'),
(4, 1, 'Tigre'),
(5, 1, '25 De Mayo'),
(6, 1, 'Trenque Lauquen'),
(7, 1, '9 De Julio'),
(8, 1, 'Lanus'),
(9, 1, 'La Plata'),
(10, 1, 'Monte'),
(11, 1, 'Pehuajo'),
(12, 1, 'San Isidro'),
(13, 1, 'Pergamino'),
(14, 1, 'Alberti'),
(15, 1, 'Chascomus'),
(16, 1, 'Esteban Echeverria'),
(17, 1, 'Mercedes'),
(18, 1, 'Bahia Blanca'),
(19, 1, 'Merlo'),
(20, 1, 'Junin'),
(21, 1, 'Guamini'),
(22, 1, 'Lujan'),
(23, 1, 'Leandro N.alem'),
(24, 1, 'Matanza'),
(25, 1, 'General Paz'),
(26, 1, 'San Vicente'),
(27, 1, 'Cañuelas'),
(28, 1, 'Almirante Brown'),
(29, 1, 'Cnl.de Marina  L.rosales'),
(30, 1, 'Baradero'),
(31, 1, 'Saavedra'),
(32, 1, 'Brandsen'),
(33, 1, 'General Sarmiento'),
(34, 1, 'Tapalque'),
(35, 1, 'Saladillo'),
(36, 1, 'Magdalena'),
(37, 1, 'Gonzales Chaves'),
(38, 1, 'General Pinto'),
(39, 1, 'Navarro'),
(40, 1, 'Daireaux'),
(41, 1, 'Lobos'),
(42, 1, 'Coronel Dorrego'),
(43, 1, 'Adolfo Alsina'),
(44, 1, 'Colon'),
(45, 1, 'General Arenales'),
(46, 1, 'Lincoln'),
(47, 1, 'Villarino'),
(48, 1, 'Vicente Lopez'),
(49, 1, 'Bartolome Mitre'),
(50, 1, 'Exaltacion De La Cruz'),
(51, 1, 'Salto'),
(52, 1, 'Bragado'),
(53, 1, 'Zarate'),
(54, 1, 'Avellaneda'),
(55, 1, 'Ayacucho'),
(56, 1, 'San Andres De Giles'),
(57, 1, 'Tandil'),
(58, 1, 'Rivadavia'),
(59, 1, 'Patagones'),
(60, 1, 'Grl.viamonte'),
(61, 1, 'Cnl.de Marina Leonardo Rosales'),
(62, 1, 'Balcarce'),
(63, 1, 'Tres Arroyos'),
(64, 1, 'General Villegas'),
(65, 1, 'Lomas De Zamora'),
(66, 1, 'Berisso'),
(67, 1, 'Juarez'),
(68, 1, 'Grl.pueyrredon'),
(69, 1, 'Coronel Suarez'),
(70, 1, 'Escobar'),
(71, 1, 'Carlos Casares'),
(72, 1, 'Chivilcoy'),
(73, 1, 'Berazategui'),
(74, 1, 'Quilmes'),
(75, 1, 'Torquinst'),
(76, 1, '3 De Febrero'),
(77, 1, 'Olavarria'),
(78, 1, 'Pellegrini'),
(79, 1, 'General Belgano'),
(80, 1, 'Florencio Varela'),
(81, 1, 'Salliquelo'),
(82, 1, 'Cnl.de Marina L.rosales'),
(83, 1, 'Mar Chiquita'),
(84, 1, 'General Pueyrredon'),
(85, 1, 'Campana'),
(86, 1, 'Grl.sarmiento'),
(87, 1, 'Rojas'),
(88, 1, 'Sarmiento'),
(89, 1, 'Carmen De Areco'),
(90, 1, 'Pila'),
(91, 1, 'Tres De Febrero'),
(92, 1, 'Moron'),
(93, 1, 'Castelli'),
(94, 1, 'Chacabuco'),
(95, 1, 'General Viamonte'),
(96, 1, 'Rauch'),
(97, 1, 'General Belgrano'),
(98, 1, 'Tornquist'),
(99, 1, 'Necochea'),
(100, 1, 'Marcos Paz'),
(101, 1, 'Carlos Tejedor'),
(102, 1, 'San Pedro'),
(103, 1, 'General Alvarado'),
(104, 1, 'San Nicolas'),
(105, 1, 'Hipolito Yrigoyen'),
(106, 1, 'Las Flores'),
(107, 1, 'Coronel Pringles'),
(108, 1, 'General San Martin'),
(109, 1, 'Benito Juarez'),
(110, 1, 'San Cayetano'),
(111, 1, 'Adolfo Gonzales Chaves'),
(112, 1, 'Dolores'),
(113, 1, 'San Antonio'),
(114, 1, 'Loberia'),
(115, 1, 'Ramallo'),
(116, 1, 'General Alvear'),
(117, 1, 'Ensenada'),
(118, 1, 'Tordillo'),
(119, 1, 'General Guido'),
(120, 1, 'General Las Heras'),
(121, 1, 'General Juan Madariaga'),
(122, 1, 'General La Madrid'),
(123, 1, 'General Lavalle'),
(124, 1, 'General Rodriguez'),
(125, 1, 'General Vllegas'),
(126, 1, 'Adolfo Gonzalez Chaves'),
(127, 1, 'Coronel De Marina L.rosales'),
(128, 1, 'Bolivar'),
(129, 1, 'San Fernando'),
(130, 1, 'Capitan Sarmiento'),
(131, 1, 'Roque Perez'),
(132, 1, 'Moreno'),
(133, 1, 'Laprida'),
(134, 1, 'Maipu'),
(135, 1, 'Echeverria'),
(136, 1, 'Pilar'),
(137, 1, 'Coronel De Marina L. Rosales'),
(138, 1, 'Suipacha'),
(139, 1, 'San Antonio De Areco'),
(140, 1, 'Barazategui'),
(141, 1, 'Alsina'),
(142, 1, 'Leandro N. Elem'),
(143, 1, 'Grl.san Martin'),
(144, 1, 'Coronel'),
(145, 2, 'Capayan'),
(146, 2, 'Andalgala'),
(147, 2, 'El Alto'),
(148, 2, 'Santa Rosa'),
(149, 2, 'Ancasti'),
(150, 2, 'Paclin'),
(151, 2, 'Santa Maria'),
(152, 2, 'Tinogasta'),
(153, 2, 'La Paz'),
(154, 2, 'Valle Viejo'),
(155, 2, 'Antofagasta De La Sierra'),
(156, 2, 'Belen'),
(157, 2, 'Capital'),
(158, 2, 'Fray Mamerto Esquiu'),
(159, 2, 'Poman'),
(160, 2, 'Ambato'),
(161, 3, 'Independencia'),
(162, 3, 'San Fernando'),
(163, 3, 'Primero De Mayo'),
(164, 3, 'Fray Justo Santa Maria De Oro'),
(165, 3, 'Sargento Cabral'),
(166, 3, 'General Guemes'),
(167, 3, 'Tapenaga'),
(168, 3, 'Chacabuco'),
(169, 3, 'Libertador Grl.san Martin'),
(170, 3, '25 De Mayo'),
(171, 3, '12 De Octubre'),
(172, 3, 'Comandante Fernandez'),
(173, 3, 'Quitilipi'),
(174, 3, 'Mayor Luis J.fontana'),
(175, 3, 'Libertad'),
(176, 3, 'Bermejo'),
(177, 3, 'Almirante Brown'),
(178, 3, 'Meyor Luis J.fontana'),
(179, 3, 'General Belgrano'),
(180, 3, 'Libertador Grl. San Martin'),
(181, 3, 'General Donovan'),
(182, 3, 'San Lorenzo'),
(183, 3, 'Lebertador Grl.san Martin'),
(184, 3, 'Maipu'),
(185, 3, 'O''higgins'),
(186, 3, '9 De Julio'),
(187, 3, 'Libertador San Martin'),
(188, 4, 'Rio Senguerr'),
(189, 4, 'Martires'),
(190, 4, 'Escalante'),
(191, 4, 'Gaiman'),
(192, 4, 'Sarmiento'),
(193, 4, 'Cushamen'),
(194, 4, 'Florentino Ameghino'),
(195, 4, 'Paso De Indios'),
(196, 4, 'Telsen'),
(197, 4, 'Languiñeo'),
(198, 4, 'Gastre'),
(199, 4, 'Futaleufu'),
(200, 4, 'Tehuelches'),
(201, 4, 'Rawson'),
(202, 4, 'Biedma'),
(203, 5, 'Rio Cuarto'),
(204, 5, 'Totoral'),
(205, 5, 'Colon'),
(206, 5, 'Minas'),
(207, 5, 'Punilla'),
(208, 5, 'Juarez Celman'),
(209, 5, 'Marcos Juarez'),
(210, 5, 'San Justo'),
(211, 5, 'Tercero Arriba'),
(212, 5, 'Rio Seco'),
(213, 5, 'Capital'),
(214, 5, 'Santa Maria'),
(215, 5, 'San Alberto'),
(216, 5, 'Union'),
(217, 5, 'Pocho'),
(218, 5, 'Calamuchita'),
(219, 5, 'Ischilin'),
(220, 5, 'General San Martin'),
(221, 5, 'Rio Primero'),
(222, 5, 'Cruz Del Eje'),
(223, 5, 'Grl.roca'),
(224, 5, 'General Roca'),
(225, 5, 'Sobremonte'),
(226, 5, 'Rio Segundo'),
(227, 5, 'Tulumba'),
(228, 5, 'San Javier'),
(229, 5, 'Presidente Roque Saez Peña'),
(230, 5, 'Presidente Roque Saenz Peña'),
(232, 5, 'Cruz De Eje'),
(233, 5, 'Coronel Pringles'),
(234, 5, 'Rio Tercero'),
(235, 5, 'Cvalamuchita'),
(236, 6, 'San Roque'),
(237, 6, 'Monte Caseros'),
(238, 6, 'General Alvear'),
(239, 6, 'Curuzu Cuatia'),
(240, 6, 'San Martin'),
(241, 6, 'Mercedes'),
(242, 6, 'Saladas'),
(243, 6, 'Ituzaingo'),
(244, 6, 'Beron De Astrada'),
(245, 6, 'Bella Vista'),
(246, 6, 'San Luis Del Palmar'),
(247, 6, 'Capital'),
(248, 6, 'Lavalle'),
(249, 6, 'Paso De Los Libres'),
(250, 6, 'Goya'),
(251, 6, 'Empedrado'),
(252, 6, 'Sauce'),
(253, 6, 'General Paz'),
(254, 6, 'Santo Tome'),
(255, 6, 'San Miguel'),
(256, 6, 'Concepcion'),
(257, 6, 'Esquina'),
(258, 6, 'San Cosme'),
(259, 6, 'Itati'),
(260, 6, 'Mburucuya'),
(261, 7, 'Uruguay'),
(262, 7, 'Nogoya'),
(263, 7, 'Tala'),
(264, 7, 'Gualeguay'),
(265, 7, 'Diamante'),
(266, 7, 'Parana'),
(267, 7, 'Gualeguaychu'),
(268, 7, 'Colon'),
(269, 7, 'Victoria'),
(270, 7, 'Villaguay'),
(271, 7, 'Feliciano'),
(272, 7, 'Concordia'),
(273, 7, 'La Paz'),
(274, 7, 'Federacion'),
(275, 7, 'Federal'),
(276, 7, 'Castellanos'),
(277, 8, 'Pilagas'),
(278, 8, 'Patiño'),
(279, 8, 'Pilcomayo'),
(280, 8, 'Bermejo'),
(281, 8, 'Pirane'),
(282, 8, 'Formosa'),
(283, 8, 'Matacos'),
(284, 8, 'Ramon Lista'),
(285, 8, 'Pillagas'),
(286, 8, 'Laishi'),
(287, 9, 'Ledesma'),
(288, 9, 'Cochinoca'),
(289, 9, 'El Carmen'),
(290, 9, 'Tumbaya'),
(291, 9, 'Capital'),
(292, 9, 'Yavi'),
(293, 9, 'Humahuaca'),
(294, 9, 'Rinconada'),
(295, 9, 'Valle Grande'),
(296, 9, 'Susques'),
(297, 9, 'Santa Catalina'),
(298, 9, 'San Antonio'),
(299, 9, 'Santa Barbara'),
(300, 9, 'San Pedro'),
(301, 9, 'Tilcara'),
(302, 9, 'Ladesma'),
(303, 10, 'Hucal'),
(304, 10, 'Realico'),
(305, 10, 'Mara Co'),
(306, 10, 'Quemuquemu'),
(307, 10, 'Chical Co'),
(308, 10, 'Guatrache'),
(309, 10, 'Capital'),
(310, 10, 'Caleucaleu'),
(311, 10, 'Trenel'),
(312, 10, 'Utracan'),
(313, 10, 'Atreuco'),
(314, 10, 'Toay'),
(315, 10, 'Chapadleufu'),
(316, 10, 'Conelo'),
(317, 10, 'Puelen'),
(318, 10, 'Rancul'),
(319, 10, 'Quemu Quemu'),
(320, 10, 'Loventue'),
(321, 10, 'Conhelo'),
(322, 10, 'Catrilo'),
(323, 10, 'Chapaleufu'),
(324, 10, 'Ultracan'),
(325, 10, 'Chalileo'),
(326, 10, 'Lihuel Calel'),
(327, 10, 'Maraco'),
(328, 10, 'Caleu Caleu'),
(329, 10, 'Curaco'),
(330, 10, 'Limay Mahuida'),
(331, 11, 'Castro Barros'),
(332, 11, 'General San Martin'),
(333, 11, 'General Lavalle'),
(334, 11, 'Arauco'),
(335, 11, 'Gral.angel V.peñaloza'),
(336, 11, 'San Blas De Los Sauces'),
(337, 11, 'Independencia'),
(338, 11, 'General Ocampo'),
(339, 11, 'Chilecito'),
(340, 11, 'Famatina'),
(341, 11, 'Grl.juan Facundo Quiroga'),
(342, 11, 'Grl.angel V. Peñaloza'),
(343, 11, 'General Belgrano'),
(344, 11, 'General Sarmiento'),
(345, 11, 'Capital'),
(346, 11, 'Gdor. Gordillo'),
(347, 11, 'General Angel Vicente Peñaloza'),
(348, 11, 'Gobernador Gordillo'),
(349, 11, 'Rosario Vera Peñaloza'),
(350, 11, 'Grl.san Martin'),
(351, 11, 'General La Madrid'),
(352, 11, 'General Juan Facundo Quiroga'),
(353, 11, 'Generalocampo'),
(354, 11, 'Sanagasta'),
(355, 12, 'San Rafael'),
(356, 12, 'Lujan'),
(357, 12, 'Malargue'),
(358, 12, 'Guaymallen'),
(359, 12, 'Lavalle'),
(360, 12, 'Junin'),
(361, 12, 'Tupungato'),
(362, 12, 'Rivadavia'),
(363, 12, 'Maipu'),
(364, 12, 'Godoy Cruz'),
(365, 12, 'General Alvear'),
(366, 12, 'La Paz'),
(367, 12, 'Tunuyan'),
(368, 12, 'San Carlos'),
(369, 12, 'Las Heras'),
(370, 12, 'Lujan De Cuyo'),
(371, 12, 'San Martin'),
(372, 12, 'Santa Rosa'),
(373, 12, 'Capital'),
(374, 13, '25 De Mayo'),
(375, 13, 'Iguazu'),
(376, 13, 'El Dorado'),
(377, 13, 'Leandro N. Alem'),
(378, 13, 'Apostoles'),
(379, 13, 'Cainguas'),
(380, 13, 'Leandro N.alem'),
(381, 13, 'Concepcion'),
(382, 13, 'San Pedro'),
(383, 13, 'Candelaria'),
(384, 13, 'Grl.manuel Belgrano'),
(385, 13, 'Obera'),
(386, 13, 'Libertador Grl.san Martin'),
(387, 13, 'San Ignacio'),
(388, 13, 'Montecarlo'),
(389, 13, 'General Manuel Belgrano'),
(390, 13, 'Lebertador Grl.san Martin'),
(391, 13, 'El Guarani'),
(392, 13, 'Eldorado'),
(393, 13, 'Capital'),
(394, 13, 'Guarani'),
(395, 13, 'San Javier'),
(396, 13, 'Libertador Grl. San Martin'),
(397, 14, 'Collon Cura'),
(398, 14, 'Alumine'),
(399, 14, 'Minas'),
(400, 14, 'Añelo'),
(401, 14, 'Confluencia'),
(402, 14, 'Chos Malal'),
(403, 14, 'Picunches'),
(404, 14, 'Norquin'),
(405, 14, 'Pehuenches'),
(406, 14, 'Loncopue'),
(407, 14, 'Huiliches'),
(408, 14, 'Zapala'),
(409, 14, 'Catan Lil'),
(410, 14, 'Ñorquin'),
(411, 14, 'Los Lagos'),
(412, 14, 'Picun Leufu'),
(413, 14, 'Lacar'),
(414, 14, 'Ñoequin'),
(415, 15, 'Valcheta'),
(416, 15, '25 De Mayo'),
(417, 15, 'El Cuy'),
(418, 15, 'Ñorquinco'),
(419, 15, 'General Roca'),
(420, 15, 'Avellaneda'),
(421, 15, 'Conesa'),
(422, 15, 'Pichi Mahuida'),
(423, 15, 'San Antonio'),
(424, 15, 'Pilcaniyeu'),
(425, 15, '9 De Julio'),
(426, 15, 'Adolfo Alsina'),
(427, 15, 'Bariloche'),
(428, 15, 'Pihi Mahuida'),
(429, 16, 'La Viña'),
(430, 16, 'San Martin'),
(431, 16, 'Oran'),
(432, 16, 'Anta'),
(433, 16, 'Gral.jose De San Martin'),
(434, 16, 'Guachipas'),
(435, 16, 'Rosario De La Frontera'),
(436, 16, 'Rivadavia'),
(437, 16, 'Metan'),
(438, 16, 'San Carlos'),
(439, 16, 'Grl.guemes'),
(440, 16, 'Cachi'),
(441, 16, 'Rosario De Lerma'),
(442, 16, 'Cafayate'),
(443, 16, 'Los Andes'),
(444, 16, 'Grl.jose De San Martin'),
(445, 16, 'Capital'),
(446, 16, 'Grl.san Martin'),
(447, 16, 'General Guemes'),
(448, 16, 'Cerrillos'),
(449, 16, 'Chicoana'),
(450, 16, 'La Poma'),
(451, 16, 'La Capital'),
(452, 16, 'Candelaria'),
(453, 16, 'Rosario'),
(454, 16, 'Iruya'),
(455, 16, 'La Caldera'),
(456, 16, 'Loa Andes'),
(457, 16, 'Molinos'),
(458, 16, 'Santa Victoria'),
(459, 17, '9 De Julio'),
(460, 17, 'Jachal'),
(461, 17, 'Albardon'),
(462, 17, '25 De Mayo'),
(463, 17, 'Santa Lucia'),
(464, 17, 'Angaco'),
(465, 17, 'Iglesia'),
(466, 17, 'Valle Fertil'),
(467, 17, 'Calingasta'),
(468, 17, 'Rivadavia'),
(469, 17, 'Caucete'),
(470, 17, 'Sarmiento'),
(471, 17, 'Pocito'),
(472, 17, 'San Martin'),
(473, 17, 'Chimbas'),
(474, 17, 'Iglesias'),
(475, 17, 'Ullun'),
(476, 17, 'Rawson'),
(477, 17, 'Capital'),
(478, 17, 'Zonda'),
(479, 18, 'Belgrano'),
(480, 18, 'Chacabuco'),
(481, 18, 'La Capital'),
(482, 18, 'Gobernador Dupuy'),
(483, 18, 'Grl.pedernera'),
(484, 18, 'Ayacucho'),
(485, 18, 'Junin'),
(486, 18, 'Gonernador Dupuy'),
(487, 18, 'Coronel Pringles'),
(488, 18, 'General Pedernera'),
(489, 18, 'Gobernador Duval'),
(490, 18, 'Iglesia'),
(491, 18, 'Libertador Grl. San Martin'),
(492, 18, 'Libertador Grl.san Martin'),
(493, 18, 'Libertador Gr.san Martin'),
(494, 18, 'Caucete'),
(495, 19, 'Guer Aike'),
(496, 19, 'Deseado'),
(497, 19, 'Rio Chico'),
(498, 19, 'Magallanes'),
(499, 19, 'Lago Argentino'),
(500, 19, 'Corpen Aike'),
(501, 19, 'Lago Buenos Aires'),
(502, 20, 'General Lopez'),
(503, 20, 'Rosario'),
(504, 20, 'General Obligado'),
(505, 20, 'Constitucion'),
(506, 20, 'San Lorenzo'),
(507, 20, 'San Javier'),
(508, 20, 'La Capital'),
(509, 20, 'San Cristobal'),
(510, 20, 'Iriondo'),
(511, 20, 'Castellanos'),
(512, 20, 'Nueve De Julio'),
(513, 20, 'Caseros'),
(514, 20, 'San Jeronimo'),
(515, 20, 'Belgrano'),
(516, 20, 'Capital'),
(517, 20, 'San Justo'),
(518, 20, 'Grl.obligado'),
(519, 20, 'La Caputal'),
(520, 20, 'Grl.lopez'),
(521, 20, 'Vera'),
(522, 20, '9 De Julio'),
(523, 20, 'San Martin'),
(524, 20, 'Las Colonias'),
(525, 20, 'Garay'),
(526, 20, 'Castelanos'),
(527, 20, 'Las Colinas'),
(528, 21, 'Banda'),
(529, 21, 'Moreno'),
(530, 21, 'Alberdi'),
(531, 21, 'Pellegrini'),
(532, 21, 'Ojo De Agua'),
(533, 21, 'Rio Hondo'),
(534, 21, 'General Taboada'),
(535, 21, 'Choya'),
(536, 21, 'Capital'),
(537, 21, 'Aguirre'),
(538, 21, 'Silipica'),
(539, 21, 'Belgrano'),
(540, 21, 'Figueroa'),
(541, 21, 'Salavina'),
(542, 21, 'Quebrachos'),
(543, 21, 'Robles'),
(544, 21, 'Avellaneda'),
(545, 21, 'Jimenez'),
(546, 21, 'Atamisqui'),
(547, 21, 'San Martin'),
(548, 21, 'Matara'),
(549, 21, 'Salayina'),
(550, 21, 'Guasayan'),
(551, 21, 'Copo'),
(552, 21, 'Brigadier Juan Felipe Ibarra'),
(553, 21, 'Dobles'),
(554, 21, 'Sarmiento'),
(555, 21, 'Loreto'),
(556, 21, 'Mitre'),
(557, 21, 'Rivadavia'),
(558, 22, 'Ushuaia'),
(559, 22, 'Islas Del Atlantico Sur'),
(560, 22, 'Sector Antartico Argentino'),
(561, 22, 'Rio Grande'),
(562, 22, 'Is.del Atlantico Sur E Is.malvinas'),
(563, 22, 'Antartida Argentina'),
(564, 23, 'Burruyacu'),
(565, 23, 'Trancas'),
(566, 23, 'Monteros'),
(567, 23, 'Leales'),
(568, 23, 'Cruz Alta'),
(569, 23, 'Rio Chico'),
(570, 23, 'Chicligasta'),
(571, 23, 'Tafi'),
(572, 23, 'Graneros'),
(573, 23, 'Famailla'),
(574, 23, 'Capital');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_acceso`
--

CREATE TABLE IF NOT EXISTS `detalles_acceso` (
  `id_acceso_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `id_acceso` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `crear` tinyint(4) NOT NULL DEFAULT '1',
  `escribir` tinyint(4) NOT NULL DEFAULT '1',
  `modificar` tinyint(4) NOT NULL DEFAULT '1',
  `borrar` tinyint(4) NOT NULL DEFAULT '1',
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_acceso_detalle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_config`
--

CREATE TABLE IF NOT EXISTS `detalles_config` (
  `id_detalle_config` int(11) NOT NULL AUTO_INCREMENT,
  `id_config` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `usar` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_detalle_config`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direcciones_hotel`
--

CREATE TABLE IF NOT EXISTS `direcciones_hotel` (
  `id_direccion` int(11) NOT NULL AUTO_INCREMENT,
  `id_hotel` int(11) NOT NULL,
  `calle` varchar(64) CHARACTER SET latin1 NOT NULL,
  `id_departamento` int(11) NOT NULL,
  `id_provincia` int(11) NOT NULL,
  `id_pais` int(11) NOT NULL,
  PRIMARY KEY (`id_direccion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=10 ;

--
-- Volcado de datos para la tabla `direcciones_hotel`
--

INSERT INTO `direcciones_hotel` (`id_direccion`, `id_hotel`, `calle`, `id_departamento`, `id_provincia`, `id_pais`) VALUES
(4, 3, '25 de Mayo 1168, 5500', 291, 12, 32),
(6, 2, 'Presidente Illia 470, 5700', 373, 18, 32),
(7, 1, '25 de mayo 1184, 5500', 157, 12, 32),
(8, 5, 'Entre Ríos 58,  5000', 213, 5, 32),
(9, 4, '25 de Mayo 767, 5500', 477, 12, 32);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direcciones_huesped`
--

CREATE TABLE IF NOT EXISTS `direcciones_huesped` (
  `id_direccion` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `calle` varchar(64) CHARACTER SET latin1 NOT NULL,
  `nro` int(11) NOT NULL,
  `piso` int(11) NOT NULL DEFAULT '0',
  `id_departamento` int(11) NOT NULL,
  `id_provincia` int(11) NOT NULL,
  `id_pais` int(11) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  `coordenadas` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_direccion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direcciones_usuario`
--

CREATE TABLE IF NOT EXISTS `direcciones_usuario` (
  `id_direccion` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `calle` varchar(64) CHARACTER SET latin1 NOT NULL,
  `nro` int(11) NOT NULL,
  `piso` int(11) NOT NULL DEFAULT '0',
  `id_departamento` int(11) NOT NULL,
  `id_provincia` int(11) NOT NULL,
  `id_pais` int(11) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  `coordenadas` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_direccion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `disponibilidades`
--

CREATE TABLE IF NOT EXISTS `disponibilidades` (
  `id_disponibilidad` int(11) NOT NULL AUTO_INCREMENT,
  `disponibilidad` varchar(128) NOT NULL,
  `entrada` date NOT NULL,
  `salida` date NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_disponibilidad`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `disponibilidades`
--

INSERT INTO `disponibilidades` (`id_disponibilidad`, `disponibilidad`, `entrada`, `salida`, `delete`) VALUES
(1, 'Test', '2014-11-21', '2014-11-27', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `disponibilidad_habitacion`
--

CREATE TABLE IF NOT EXISTS `disponibilidad_habitacion` (
  `id_disponibilidad_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_disponibilidad` int(11) NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_disponibilidad_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `disponibilidad_habitacion`
--

INSERT INTO `disponibilidad_habitacion` (`id_disponibilidad_habitacion`, `id_disponibilidad`, `id_habitacion`, `prioridad`) VALUES
(1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `emails_hotel`
--

CREATE TABLE IF NOT EXISTS `emails_hotel` (
  `id_email` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) CHARACTER SET latin1 NOT NULL,
  `mostrar` tinyint(4) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  PRIMARY KEY (`id_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `emails_hotel`
--

INSERT INTO `emails_hotel` (`id_email`, `email`, `mostrar`, `id_tipo`) VALUES
(1, 'reservas@hotelcarollo.com.ar', 1, 0),
(2, 'reservas@hotelprincess.com.ar', 1, 0),
(3, 'reservas@hotelsanluis.com.ar', 1, 0),
(4, 'reserva@hotelcristal.com.ar', 1, 0),
(5, 'hotelesgoldargentina@gmail.com', 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `emails_huesped`
--

CREATE TABLE IF NOT EXISTS `emails_huesped` (
  `id_email` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `email` varchar(128) CHARACTER SET latin1 NOT NULL,
  `id_tipo` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `emails_huesped`
--

INSERT INTO `emails_huesped` (`id_email`, `id_huesped`, `email`, `id_tipo`) VALUES
(1, 1, 'VANINAMURATTI@GMAIL.COM', 1),
(2, 2, 'diego_nieto_1@hotmail.com', 1),
(3, 3, 'goliva@gencosa.com', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `emails_usuario`
--

CREATE TABLE IF NOT EXISTS `emails_usuario` (
  `id_email` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `email` varchar(128) CHARACTER SET latin1 NOT NULL,
  `id_tipo` int(11) NOT NULL,
  PRIMARY KEY (`id_email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas`
--

CREATE TABLE IF NOT EXISTS `empresas` (
  `id_empresa` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` varchar(64) NOT NULL,
  `slogan` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  PRIMARY KEY (`id_empresa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `empresas`
--

INSERT INTO `empresas` (`id_empresa`, `empresa`, `slogan`, `email`) VALUES
(1, 'Hoteles Gold', 'Mensaje de la empresa', 'consulta@hoteles.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_articulo`
--

CREATE TABLE IF NOT EXISTS `estados_articulo` (
  `id_estado_articulo` int(11) NOT NULL AUTO_INCREMENT,
  `estado_articulo` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_estado_articulo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `estados_articulo`
--

INSERT INTO `estados_articulo` (`id_estado_articulo`, `estado_articulo`) VALUES
(1, '<span class="label label-success">Publicado</span>'),
(2, '<span class="label label-danger">Sin Publicar</span>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_habitacion`
--

CREATE TABLE IF NOT EXISTS `estados_habitacion` (
  `id_estado_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `estado_habitacion` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_estado_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `estados_habitacion`
--

INSERT INTO `estados_habitacion` (`id_estado_habitacion`, `estado_habitacion`) VALUES
(1, '<span class="label label-danger">No disponible</label>'),
(2, '<span class="label label-success">Disponible</label>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_huesped`
--

CREATE TABLE IF NOT EXISTS `estados_huesped` (
  `id_estado_huesped` int(11) NOT NULL AUTO_INCREMENT,
  `estado_huesped` varchar(128) NOT NULL,
  PRIMARY KEY (`id_estado_huesped`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `estados_huesped`
--

INSERT INTO `estados_huesped` (`id_estado_huesped`, `estado_huesped`) VALUES
(1, '<span class="label label-primary">Alta</span>'),
(2, '<span class="label label-danger">Baja</span>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_mensaje`
--

CREATE TABLE IF NOT EXISTS `estados_mensaje` (
  `id_estado_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `estado_mensaje` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_estado_mensaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `estados_mensaje`
--

INSERT INTO `estados_mensaje` (`id_estado_mensaje`, `estado_mensaje`) VALUES
(1, '<span class="label label-success">Nuevo</span>'),
(2, '<span class="label label-default">Leído</span>'),
(3, '<span class="label label-info">Enviado</span>\r\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_reserva`
--

CREATE TABLE IF NOT EXISTS `estados_reserva` (
  `id_estado_reserva` int(11) NOT NULL AUTO_INCREMENT,
  `estado_reserva` varchar(128) CHARACTER SET latin1 NOT NULL,
  `reserva_lugar` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_estado_reserva`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `estados_reserva`
--

INSERT INTO `estados_reserva` (`id_estado_reserva`, `estado_reserva`, `reserva_lugar`) VALUES
(1, '<span class="label label-success">Nueva</span>', 0),
(2, '<span class="label label-warning">Falta de pago</span>', 0),
(3, '<span class="label label-primary">Aceptada</span>', 1),
(4, '<span class="label label-danger">Rechazada</span>', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_traduccion`
--

CREATE TABLE IF NOT EXISTS `estados_traduccion` (
  `id_estado_traduccion` int(11) NOT NULL AUTO_INCREMENT,
  `estado_traduccion` varchar(32) NOT NULL,
  `label` varchar(128) NOT NULL,
  PRIMARY KEY (`id_estado_traduccion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `estados_traduccion`
--

INSERT INTO `estados_traduccion` (`id_estado_traduccion`, `estado_traduccion`, `label`) VALUES
(1, 'Sin traducción', '<span class="label label-danger" title="Sin traducción"><i class="fa fa-exclamation-triangle"></i></span>'),
(2, 'En proceso', '<span class="label label-primary" title="en proceso"><i class="fa fa-file-o"></i></span>'),
(3, 'Finalizada', '<span class="label label-success" title="Finalizada"><i class="fa fa-check"></i></span>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_usuario`
--

CREATE TABLE IF NOT EXISTS `estados_usuario` (
  `id_estado_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `estado_usuario` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_estado_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `estados_usuario`
--

INSERT INTO `estados_usuario` (`id_estado_usuario`, `estado_usuario`) VALUES
(1, '<span class="label label-primary">Alta</span>'),
(2, '<span class="label label-danger">Baja</span>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `habitaciones`
--

CREATE TABLE IF NOT EXISTS `habitaciones` (
  `id_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `habitacion` varchar(32) CHARACTER SET latin1 NOT NULL,
  `descripcion` text COLLATE latin1_spanish_ci NOT NULL,
  `adultos` int(11) NOT NULL,
  `menores` int(11) NOT NULL,
  `entrada` time NOT NULL,
  `salida` time NOT NULL,
  `cantidad` int(11) NOT NULL,
  `orden` int(11) NOT NULL DEFAULT '1',
  `id_tipo_habitacion` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `id_tarifa` int(11) NOT NULL,
  `id_estado_habitacion` int(11) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=27 ;

--
-- Volcado de datos para la tabla `habitaciones`
--

INSERT INTO `habitaciones` (`id_habitacion`, `habitacion`, `descripcion`, `adultos`, `menores`, `entrada`, `salida`, `cantidad`, `orden`, `id_tipo_habitacion`, `id_hotel`, `id_tarifa`, `id_estado_habitacion`, `delete`) VALUES
(1, 'Habitación Single ', '<p>\n	<font><font>Nuestras Habitaciones Singles tienen capacidad para una persona en cama matrimonial o twin (segun DISPONIBILIDAD).&nbsp;</font></font><span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia cuenta con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 1, 0, '08:00:00', '18:00:00', 20, 1, 1, 1, 1, 2, 0),
(2, 'Habitación Single', '<p style="font-size: 11.8181819915771px;">\n	Nuestras Habitaciones Singles tienen capacidad para una persona en cama matrimonial o twin (segun DISPONIBILIDAD).&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia cuenta con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 1, 0, '08:00:00', '18:00:00', 20, 1, 1, 3, 4, 2, 0),
(3, 'Habitación Single', '<p style="font-size: 11.8181819915771px;">\n	Nuestras Habitaciones Singles tienen capacidad para una persona en cama matrimonial o twin (segun DISPONIBILIDAD).&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia cuenta con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 1, 0, '08:00:00', '18:00:00', 20, 1, 1, 2, 9, 2, 0),
(4, 'Habitación Single', '<p style="font-size: 11.8181819915771px;">\n	Nuestras Habitaciones Singles tienen capacidad para una persona en cama matrimonial o twin (segun DISPONIBILIDAD).&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia cuenta con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 1, 0, '08:00:00', '18:00:00', 20, 1, 1, 5, 14, 2, 0),
(5, 'Habitación Doble', '<p style="font-size: 11.8181819915771px;">\n	Nuestras Habitaciones Dobles tienen capacidad para dos personas en cama matrimonial o dos camas twin (segun DISPONIBILIDAD).&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia cuenta con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 2, 1, '08:00:00', '18:00:00', 30, 1, 2, 1, 2, 2, 0),
(6, 'Habitación Doble', '<p style="font-size: 12px;">\n	<font><font>Nuestras Habitaciones Dobles Tiene Capacidad Para Dos persona en cama matrimonial o dos camas gemelas. </font><font>Estan Totalmente equipadas con:</font></font></p>\n<ul style="font-size: 12px;">\n	<li>\n		<font><font>Televisi&oacute;n por cable estafa</font></font></li>\n	<li>\n		<font><font>Cofre de Seguridad</font></font></li>\n	<li>\n		<font><font>Ba&ntilde;o Privado</font></font></li>\n	<li>\n		<font><font>Secador de pelo</font></font></li>\n	<li>\n		<font><font>Comodidades</font></font></li>\n</ul>\n', 2, 1, '07:00:00', '18:00:00', 30, 1, 2, 1, 2, 2, 1),
(7, 'Habitación Doble', '<p style="font-size: 12px;">\n	<font><font>Nuestras Habitaciones Dobles Tiene Capacidad Para Dos persona en cama matrimonial o dos camas gemelas.&nbsp;</font></font><span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV Led&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 2, 2, '07:00:00', '18:00:00', 30, 1, 2, 1, 2, 2, 1),
(8, 'Habitación Doble', '<p style="font-size: 12px;">\n	<font><font>Nuestras Habitaciones Dobles Tiene Capacidad Para Dos persona en cama matrimonial o dos camas gemelas. </font><font>Estan Totalmente equipadas con:</font></font></p>\n<ul style="font-size: 12px;">\n	<li>\n		<font><font>Televisi&oacute;n por cable estafa</font></font></li>\n	<li>\n		<font><font>Cofre de Seguridad</font></font></li>\n	<li>\n		<font><font>Ba&ntilde;o Privado</font></font></li>\n	<li>\n		<font><font>Secador de pelo</font></font></li>\n	<li>\n		<font><font>Comodidades</font></font></li>\n</ul>\n', 2, 1, '07:00:00', '18:00:00', 30, 1, 2, 1, 2, 2, 1),
(9, 'Habitación Doble', '<p style="font-size: 12px;">\n	<font><font>Nuestras Habitaciones Dobles Tiene Capacidad Para Dos persona en cama matrimonial o dos camas gemelas. </font><font>Estan Totalmente equipadas con:</font></font></p>\n<ul style="font-size: 12px;">\n	<li>\n		<font><font>Televisi&oacute;n por cable estafa</font></font></li>\n	<li>\n		<font><font>Cofre de Seguridad</font></font></li>\n	<li>\n		<font><font>Ba&ntilde;o Privado</font></font></li>\n	<li>\n		<font><font>Secador de pelo</font></font></li>\n	<li>\n		<font><font>Comodidades</font></font></li>\n</ul>\n', 2, 1, '07:00:00', '18:00:00', 30, 1, 2, 1, 2, 2, 1),
(10, 'Habitación Doble', '<p style="font-size: 12px;">\n	<font><font>Nuestras Habitaciones Dobles Tiene Capacidad Para dos personas en cama matrimonial o dos camas twin. </font><font>Estan Totalmente equipadas con:</font></font></p>\n<ul style="font-size: 12px;">\n	<li>\n		<font><font>Televisi&oacute;n por cable</font></font></li>\n	<li>\n		<font><font>Cofre de Seguridad</font></font></li>\n	<li>\n		<font><font>Ba&ntilde;o Privado</font></font></li>\n	<li>\n		<font><font>Secador de pelo</font></font></li>\n	<li>\n		Amenities</li>\n</ul>\n', 2, 1, '07:00:00', '18:00:00', 30, 1, 2, 1, 2, 2, 1),
(11, 'Habitación Doble', '<p style="font-size: 12px;">\n	<font><font>Nuestras Habitaciones Dobles Tiene Capacidad Para dos personas en cama matrimonial o dos camas twin. </font><font>Estan Totalmente equipadas con:</font></font></p>\n<ul style="font-size: 12px;">\n	<li>\n		<font><font>Televisi&oacute;n por cable</font></font></li>\n	<li>\n		<font><font>Cofre de Seguridad</font></font></li>\n	<li>\n		<font><font>Ba&ntilde;o Privado</font></font></li>\n	<li>\n		<font><font>Secador de pelo</font></font></li>\n	<li>\n		Amenities</li>\n</ul>\n', 2, 1, '07:00:00', '18:00:00', 30, 1, 2, 1, 2, 2, 1),
(12, 'Habitación Doble', '<p style="font-size: 12px;">\n	<font><font>Nuestras Habitaciones Dobles Tiene Capacidad Para dos personas en cama matrimonial o dos camas twin. </font><font>Estan Totalmente equipadas con:</font></font></p>\n<ul style="font-size: 12px;">\n	<li>\n		<font><font>Televisi&oacute;n por cable</font></font></li>\n	<li>\n		<font><font>Cofre de Seguridad</font></font></li>\n	<li>\n		<font><font>Ba&ntilde;o Privado</font></font></li>\n	<li>\n		<font><font>Secador de pelo</font></font></li>\n	<li>\n		Amenities</li>\n</ul>\n', 2, 1, '07:00:00', '18:00:00', 30, 1, 2, 1, 2, 2, 1),
(13, 'Habitación Doble', '<p>\n	Nuestras Habitaciones Dobles tienen capacidad para dos personas en cama matrimonial o dos camas twin.&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 2, 2, '08:00:00', '18:00:00', 50, 1, 2, 3, 5, 2, 0),
(14, 'Habitación Doble', '<p style="font-size: 11.8181819915771px;">\n	Nuestras Habitaciones Dobles tienen capacidad para dos personas en cama matrimonial o dos camas twin.&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 2, 2, '08:00:00', '18:00:00', 50, 1, 2, 2, 10, 2, 0),
(15, 'Habitación Doble', '<p style="font-size: 11.8181819915771px;">\n	Nuestras Habitaciones Dobles tienen capacidad para dos personas en cama matrimonial o dos camas twin.&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 2, 2, '08:00:00', '18:00:00', 50, 1, 2, 5, 15, 2, 0),
(16, 'Habitación Triple', '<p>\n	Nuestras Habitaciones Triples tienen capacidad para tres personas en cama matrimonial mas cama individual o tres camas twin.<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 3, 3, '08:00:00', '18:00:00', 50, 1, 3, 1, 3, 2, 0),
(17, 'Hanitación Triple', '<p style="font-size: 11.8181819915771px;">\n	Nuestras Habitaciones Triples tienen capacidad para tres personas en cama matrimonial mas cama individual o tres camas twin.&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 3, 3, '08:00:00', '18:00:00', 50, 1, 3, 3, 6, 2, 0),
(18, 'Habitación Triple ', '<p>\n	Nuestras Habitaciones Triples tienen capacidad para tres personas en cama matrimonial mas cama individual o tres camas twin.<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 3, 3, '08:00:00', '18:00:00', 50, 1, 3, 2, 11, 2, 0),
(19, 'Habitación Triple', '<p>\n	Nuestras Habitaciones Triples tienen capacidad para tres personas en cama matrimonial mas cama individual o tres camas twin.&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 3, 3, '08:00:00', '18:00:00', 50, 1, 3, 5, 16, 2, 0),
(20, 'Habitación Cuádruple', '<p>\n	Nuestras Habitaciones Cu&aacute;druples&nbsp; tienen capacidad para cuatro personas en cama matrimonial mas dos camas individuales o cuatro camas twin.&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 4, 4, '08:00:00', '18:00:00', 50, 1, 6, 3, 7, 2, 0),
(21, 'Habitación Cuádruple', '<p style="font-size: 11.8181819915771px;">\n	Nuestras Habitaciones Cu&aacute;druples&nbsp; tienen capacidad para cuatro personas en cama matrimonial mas dos camas individuales o cuatro camas twin.&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 4, 4, '08:00:00', '18:00:00', 50, 1, 6, 2, 12, 2, 0),
(22, 'Habitación Cuádruple', '<p style="font-size: 11.8181819915771px;">\n	Nuestras Habitaciones Cu&aacute;druples&nbsp; tienen capacidad para cuatro personas en cama matrimonial mas dos camas individuales o cuatro camas twin.&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 4, 4, '08:00:00', '18:00:00', 50, 1, 6, 5, 17, 2, 0),
(23, 'Habitación Quíntuple', '<p>\n	<span style="font-size: 12px;">Nuestras Habitaciones Qu&iacute;ntuples&nbsp; tienen capacidad para cinco personas en cama matrimonial m&aacute;s tres camas individuales o cinco camas twin.</span><span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</span></p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 5, 5, '08:00:00', '18:00:00', 50, 1, 7, 5, 18, 2, 0),
(24, 'Habitación Suite', '<p>\n	Nuestras Habitaciones Suite &nbsp;tienen capacidad para dos personas en cama matrimonial tama&ntilde;o king. Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</p>\n<ul>\n	<li>\n		TV Led&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 2, 1, '08:00:00', '18:00:00', 50, 1, 8, 3, 8, 2, 0),
(25, 'Habitación Suite', '<p style="font-size: 11.8181819915771px;">\n	Nuestras Habitaciones Suite &nbsp;tienen capacidad para dos personas en cama matrimonial tama&ntilde;o king. Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</p>\n<ul style="font-size: 11.8181819915771px;">\n	<li>\n		TV Led&nbsp;</li>\n	<li>\n		Cofre de Seguridad</li>\n	<li>\n		Ba&ntilde;o Privado</li>\n	<li>\n		Secador de pelo</li>\n	<li>\n		Amenities</li>\n	<li>\n		Tel&eacute;fono</li>\n	<li>\n		Calefacci&oacute;n</li>\n	<li>\n		Refrigeraci&oacute;n</li>\n</ul>\n', 2, 1, '08:00:00', '18:00:00', 50, 1, 8, 2, 13, 2, 0),
(26, 'Habitación Doble', '<p style="font-size: 11.8181819915771px;">\r\n	Nuestras Habitaciones Dobles tienen capacidad para dos personas en cama matrimonial o dos camas twin.&nbsp;<span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia con:</span></p>\r\n<ul style="font-size: 11.8181819915771px;">\r\n	<li>\r\n		TV Led&nbsp;</li>\r\n	<li>\r\n		Cofre de Seguridad</li>\r\n	<li>\r\n		Ba&ntilde;o Privado</li>\r\n	<li>\r\n		Secador de pelo</li>\r\n	<li>\r\n		Amenities</li>\r\n	<li>\r\n		Tel&eacute;fono</li>\r\n	<li>\r\n		Calefacci&oacute;n</li>\r\n	<li>\r\n		Refrigeraci&oacute;n</li>\r\n</ul>\r\n', 2, 2, '08:00:00', '18:00:00', 50, 1, 2, 1, 2, 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `habitacion_servicio`
--

CREATE TABLE IF NOT EXISTS `habitacion_servicio` (
  `id_habitacion_servicio` int(11) NOT NULL AUTO_INCREMENT,
  `id_servicio` int(11) NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_habitacion_servicio`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=199 ;

--
-- Volcado de datos para la tabla `habitacion_servicio`
--

INSERT INTO `habitacion_servicio` (`id_habitacion_servicio`, `id_servicio`, `id_habitacion`, `prioridad`) VALUES
(2, 16, 1, 2),
(3, 2, 1, 0),
(7, 7, 1, 3),
(9, 13, 1, 1),
(10, 16, 2, 0),
(11, 2, 2, 1),
(15, 7, 2, 2),
(17, 13, 2, 3),
(18, 16, 3, 0),
(19, 2, 3, 1),
(23, 7, 3, 2),
(24, 13, 3, 3),
(25, 16, 4, 0),
(26, 2, 4, 1),
(30, 13, 4, 2),
(31, 16, 5, 0),
(32, 2, 5, 1),
(36, 7, 5, 2),
(38, 13, 5, 3),
(39, 16, 6, 0),
(40, 2, 6, 1),
(41, 15, 6, 2),
(42, 14, 6, 3),
(43, 5, 6, 4),
(44, 7, 6, 5),
(45, 11, 6, 6),
(46, 13, 6, 7),
(47, 16, 7, 0),
(48, 2, 7, 1),
(49, 15, 7, 2),
(50, 14, 7, 3),
(51, 5, 7, 4),
(52, 7, 7, 5),
(53, 11, 7, 6),
(54, 13, 7, 7),
(55, 16, 8, 0),
(56, 2, 8, 1),
(57, 15, 8, 2),
(58, 14, 8, 3),
(59, 5, 8, 4),
(60, 7, 8, 5),
(61, 11, 8, 6),
(62, 13, 8, 7),
(63, 16, 9, 0),
(64, 2, 9, 1),
(65, 15, 9, 2),
(66, 14, 9, 3),
(67, 5, 9, 4),
(68, 7, 9, 5),
(69, 11, 9, 6),
(70, 13, 9, 7),
(71, 16, 10, 0),
(72, 2, 10, 1),
(73, 15, 10, 2),
(74, 14, 10, 3),
(75, 5, 10, 4),
(76, 7, 10, 5),
(77, 11, 10, 6),
(78, 13, 10, 7),
(79, 16, 11, 0),
(80, 2, 11, 1),
(81, 15, 11, 2),
(82, 14, 11, 3),
(83, 5, 11, 4),
(84, 7, 11, 5),
(85, 11, 11, 6),
(86, 13, 11, 7),
(87, 16, 12, 0),
(88, 2, 12, 1),
(89, 15, 12, 2),
(90, 14, 12, 3),
(91, 5, 12, 4),
(92, 7, 12, 5),
(93, 11, 12, 6),
(94, 13, 12, 7),
(95, 16, 13, 0),
(96, 2, 13, 1),
(100, 7, 13, 2),
(102, 13, 13, 3),
(103, 16, 14, 1),
(104, 2, 14, 2),
(108, 13, 14, 3),
(109, 16, 15, 0),
(110, 2, 15, 1),
(114, 7, 15, 2),
(115, 13, 15, 3),
(116, 16, 16, 0),
(117, 2, 16, 1),
(121, 7, 16, 2),
(123, 13, 16, 3),
(124, 16, 17, 0),
(125, 2, 17, 1),
(129, 7, 17, 2),
(131, 13, 17, 3),
(132, 16, 18, 0),
(133, 2, 18, 1),
(137, 7, 18, 2),
(138, 13, 18, 3),
(139, 16, 19, 0),
(140, 2, 19, 1),
(144, 7, 19, 2),
(145, 13, 19, 3),
(146, 16, 20, 0),
(147, 2, 20, 1),
(151, 7, 20, 2),
(153, 13, 20, 3),
(154, 16, 21, 0),
(155, 2, 21, 1),
(159, 7, 21, 2),
(160, 13, 21, 3),
(161, 16, 22, 0),
(162, 2, 22, 1),
(166, 7, 22, 2),
(167, 13, 22, 3),
(168, 16, 23, 0),
(169, 2, 23, 1),
(173, 7, 23, 2),
(174, 13, 23, 3),
(175, 16, 24, 0),
(176, 2, 24, 1),
(180, 7, 24, 2),
(182, 13, 24, 3),
(183, 16, 25, 0),
(184, 2, 25, 1),
(188, 7, 25, 2),
(189, 13, 25, 3),
(190, 16, 26, 0),
(191, 2, 26, 1),
(192, 15, 26, 2),
(193, 14, 26, 3),
(194, 5, 26, 4),
(195, 7, 26, 5),
(196, 11, 26, 6),
(197, 13, 26, 7),
(198, 7, 14, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoteles`
--

CREATE TABLE IF NOT EXISTS `hoteles` (
  `id_hotel` int(11) NOT NULL AUTO_INCREMENT,
  `hotel` varchar(64) CHARACTER SET latin1 NOT NULL,
  `descripcion` varchar(128) CHARACTER SET latin1 NOT NULL,
  `logo_url` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `fondo_intro` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `url` varchar(128) CHARACTER SET latin1 NOT NULL,
  `latitud` varchar(32) COLLATE latin1_spanish_ci NOT NULL,
  `longitud` varchar(32) COLLATE latin1_spanish_ci NOT NULL,
  `monedas` tinyint(4) NOT NULL DEFAULT '1',
  `usar_codigo` tinyint(4) NOT NULL,
  `codigo_afip` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_hotel`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `hoteles`
--

INSERT INTO `hoteles` (`id_hotel`, `hotel`, `descripcion`, `logo_url`, `fondo_intro`, `url`, `latitud`, `longitud`, `monedas`, `usar_codigo`, `codigo_afip`, `delete`) VALUES
(1, 'Hotel Carollo Gold', '-', '21cae-carollo-(1).png', '8570a-mapa-mendoza.jpg', 'www.hotelcarollo.com.ar', '-32.8884109', '-68.8470751', 0, 1, 'http://qr.afip.gob.ar/?qr=aXW5N-5ujTdPxyx1HP4DFw,,', 0),
(2, 'Gran Hotel San Luis Gold', '-', '86ef1-san-luis.png', '794a7-mapa-san-luis.jpg', 'www.hotelsanluis.com.ar', '-33.3000259', '-66.3455385', 0, 0, '', 0),
(3, 'Gran Hotel Princess Gold', '-', '58611-princess.png', 'ae78d-mapa-mendoza.jpg', 'www.hotelprincess.com.ar', '-32.8884109', '-68.8470751', 0, 0, '', 0),
(4, 'Hotel Royal Princess Gold', '-', '08240-royal.png', '', 'www.hotelesgold.com.ar', '-32.8930908', '-68.8480434', 0, 0, '', 0),
(5, 'Hotel Cristal Gold', '-', 'd0430-cristal.png', '281c3-mapa-cordoba.jpg', 'www.hotelcristal.com.ar', '-31.418598', '-64.1838923', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hotel_email_habitacion`
--

CREATE TABLE IF NOT EXISTS `hotel_email_habitacion` (
  `id_hotel_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_email` int(11) NOT NULL,
  `id_config` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_hotel_habitacion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hotel_email_mensaje`
--

CREATE TABLE IF NOT EXISTS `hotel_email_mensaje` (
  `id_hotel_email` int(11) NOT NULL AUTO_INCREMENT,
  `id_email` int(11) NOT NULL,
  `id_config` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_hotel_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `hotel_email_mensaje`
--

INSERT INTO `hotel_email_mensaje` (`id_hotel_email`, `id_email`, `id_config`, `prioridad`) VALUES
(3, 3, 3, 0),
(4, 2, 5, 0),
(5, 4, 9, 0),
(6, 5, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hotel_email_reserva`
--

CREATE TABLE IF NOT EXISTS `hotel_email_reserva` (
  `id_hotel_email` int(11) NOT NULL AUTO_INCREMENT,
  `id_email` int(11) NOT NULL,
  `id_config` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_hotel_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `hotel_email_reserva`
--

INSERT INTO `hotel_email_reserva` (`id_hotel_email`, `id_email`, `id_config`, `prioridad`) VALUES
(1, 3, 3, 0),
(3, 2, 5, 0),
(4, 4, 9, 0),
(5, 5, 1, 1),
(6, 1, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `huespedes`
--

CREATE TABLE IF NOT EXISTS `huespedes` (
  `id_huesped` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(128) CHARACTER SET latin1 NOT NULL,
  `apellido` varchar(64) CHARACTER SET latin1 NOT NULL,
  `dni` int(11) NOT NULL,
  `pass` varchar(64) CHARACTER SET latin1 NOT NULL,
  `id_tipo_huesped` int(11) NOT NULL,
  `id_estado_huesped` int(11) NOT NULL DEFAULT '1',
  `fecha_alta` datetime NOT NULL,
  `fecha_modificacion` datetime NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_huesped`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `huespedes`
--

INSERT INTO `huespedes` (`id_huesped`, `nombre`, `apellido`, `dni`, `pass`, `id_tipo_huesped`, `id_estado_huesped`, `fecha_alta`, `fecha_modificacion`, `delete`) VALUES
(1, 'vanina', 'MURATTI', 0, '3274', 1, 1, '2014-11-04 11:13:00', '2014-11-04 11:13:00', 0),
(2, 'Diego', 'Nieto', 0, '7261', 1, 1, '2014-11-19 09:43:10', '2014-11-19 09:43:10', 0),
(3, 'dnieto', 'Nieto', 0, '5718', 1, 1, '2014-11-20 15:25:25', '2014-11-20 15:25:25', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `idiomas`
--

CREATE TABLE IF NOT EXISTS `idiomas` (
  `id_idioma` int(11) NOT NULL AUTO_INCREMENT,
  `idioma` varchar(64) NOT NULL,
  `imagen` varchar(128) NOT NULL,
  `archivo` varchar(64) NOT NULL,
  `url` varchar(2) NOT NULL,
  `delete` int(11) NOT NULL,
  PRIMARY KEY (`id_idioma`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `idiomas`
--

INSERT INTO `idiomas` (`id_idioma`, `idioma`, `imagen`, `archivo`, `url`, `delete`) VALUES
(0, 'Todos', '', 'spanish.php', 'es', 0),
(1, 'Español', '27b11-9d48a-argentina-icono-8268-48.png', 'spanish.php', 'es', 0),
(2, 'Inglés', '5277f-09c26-bandera-icono-5097-48.png', 'english.php', 'en', 0),
(3, 'Francés', '7bc3e-francia-icono-7845-48.png', 'french.php', 'fr', 0),
(4, 'Portugués', 'dfeab-4319e-brasil-icono-8028-48.png', 'portuguese.php', 'po', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes_articulo`
--

CREATE TABLE IF NOT EXISTS `imagenes_articulo` (
  `id_imagen` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(128) CHARACTER SET latin1 NOT NULL,
  `tipo` varchar(32) CHARACTER SET latin1 NOT NULL,
  `size` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `descripcion` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_imagen`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes_carrusel`
--

CREATE TABLE IF NOT EXISTS `imagenes_carrusel` (
  `id_imagen` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(128) CHARACTER SET latin1 NOT NULL,
  `tipo` varchar(32) CHARACTER SET latin1 NOT NULL,
  `size` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `titulo` text CHARACTER SET latin1 NOT NULL,
  `descripcion` text CHARACTER SET latin1 NOT NULL,
  `id_hotel` int(11) NOT NULL,
  PRIMARY KEY (`id_imagen`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=71 ;

--
-- Volcado de datos para la tabla `imagenes_carrusel`
--

INSERT INTO `imagenes_carrusel` (`id_imagen`, `imagen`, `tipo`, `size`, `orden`, `titulo`, `descripcion`, `id_hotel`) VALUES
(25, 'a13e6-4.jpg', '', 0, 1, '', '', 1),
(26, '6bc6f-5.jpg', '', 0, 2, '', '', 1),
(27, 'daef8-3.jpg', '', 0, 4, '', '', 1),
(38, '3d95a-3.jpg', '', 0, 1, '', '', 3),
(39, '5f133-5.jpg', '', 0, 2, '', '', 3),
(42, '6d71d-6.jpg', '', 0, 4, '', '', 3),
(43, '371d3-4.jpg', '', 0, 5, '', '', 3),
(46, 'ac5a1-5.jpg', '', 0, 1, '', '', 2),
(48, '011eb-6.jpg', '', 0, 3, '', '', 2),
(51, 'f0be6-8.jpg', '', 0, 4, '', '', 2),
(53, 'a871c-6--1-.jpg', '', 0, 2, '', '', 2),
(59, '59afe-166-1024x680.jpg', '', 0, 0, '', '', 5),
(60, 'e8e66-uuu-121.jpg', '', 0, 0, '', '', 5),
(61, '4f5fe-sssss.jpg', '', 0, 0, '', '', 5),
(64, '27d55-provincia-cordoba.jpg', '', 0, 0, '', '', 5),
(65, '56d6c-san-luis-plaza.jpg', '', 0, 0, '', '', 2),
(66, 'aa556-9-1024x675.jpg', '', 0, 0, '', '', 1),
(67, '83ef2-foto_7.jpg', '', 0, 0, '', '', 1),
(70, '8936e-viedos-de-mendoza-7cc5a79c-8a12-42c2-a06e-3f55c83e30a8.jpg', '', 0, 0, '', '', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes_habitacion`
--

CREATE TABLE IF NOT EXISTS `imagenes_habitacion` (
  `id_imagen` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(128) CHARACTER SET latin1 NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `tipo` varchar(32) CHARACTER SET latin1 NOT NULL,
  `size` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `titulo` text CHARACTER SET latin1 NOT NULL,
  `descripcion` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_imagen`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=40 ;

--
-- Volcado de datos para la tabla `imagenes_habitacion`
--

INSERT INTO `imagenes_habitacion` (`id_imagen`, `imagen`, `id_habitacion`, `tipo`, `size`, `orden`, `titulo`, `descripcion`) VALUES
(2, '41266-IMG_2967.jpg', 1, '', 0, 0, '', ''),
(3, '6166a-Princess-10-07-139.jpg', 2, '', 0, 0, '', ''),
(4, '18449-Princess-10-07-138.jpg', 2, '', 0, 0, '', ''),
(5, 'ce26b-DSC02396.JPG', 2, '', 0, 0, '', ''),
(6, 'cce25-IMG_2919.jpg', 1, '', 0, 0, '', ''),
(7, '8adeb-IMG_4253.jpg', 3, '', 0, 0, '', ''),
(8, 'f3a3e-IMG_4238.jpg', 3, '', 0, 0, '', ''),
(9, '182bd-IMG_4038.jpg', 14, '', 0, 0, '', ''),
(10, '7979b-DSC_0237.JPG', 14, '', 0, 0, '', ''),
(11, '5cade-IMG_4250.jpg', 18, '', 0, 0, '', ''),
(12, '5039a-IMG_4274.jpg', 18, '', 0, 0, '', ''),
(13, '19337-IMG_4030.jpg', 21, '', 0, 0, '', ''),
(14, 'a5be3-IMG_4042.jpg', 21, '', 0, 0, '', ''),
(15, '292e0-IMG_4083.jpg', 25, '', 0, 0, '', ''),
(16, '4226b-IMG_4056.jpg', 25, '', 0, 0, '', ''),
(17, 'e98a0-IMG_2965.jpg', 5, '', 0, 0, '', ''),
(18, '4e50f-IMG_2921.jpg', 5, '', 0, 0, '', ''),
(20, '30c88-DSC_1463.JPG', 16, '', 0, 0, '', ''),
(21, '5d555-301.jpg', 16, '', 0, 0, '', ''),
(22, 'ca8e6-Princess-10-07-139.jpg', 13, '', 0, 0, '', ''),
(23, '77abd-DSC02372.JPG', 13, '', 0, 0, '', ''),
(24, '370b6-DSC02392.JPG', 17, '', 0, 0, '', ''),
(25, 'b13b5-dsc_0038.jpg', 17, '', 0, 0, '', ''),
(26, '6aeda-Princess-10-07-149.jpg', 20, '', 0, 0, '', ''),
(27, '36b8b-DSC02383.JPG', 20, '', 0, 0, '', ''),
(28, 'c29c4-Princess-10-07-070.jpg', 24, '', 0, 2, '', ''),
(29, '9db0e-DSC02371.JPG', 24, '', 0, 1, '', ''),
(30, '40735-IMG_3756.jpg', 4, '', 0, 0, '', ''),
(31, '7d945-IMG_3767.jpg', 4, '', 0, 0, '', ''),
(32, 'bc1fd-IMG_3943.jpg', 15, '', 0, 0, '', ''),
(33, '56923-IMG_3924.jpg', 15, '', 0, 0, '', ''),
(34, '809d1-IMG_3932.jpg', 19, '', 0, 0, '', ''),
(35, '9a465-IMG_3764.jpg', 19, '', 0, 0, '', ''),
(36, '0380e-IMG_3930.jpg', 22, '', 0, 2, '', ''),
(37, '69382-IMG_3756.jpg', 22, '', 0, 1, '', ''),
(38, '65d9f-IMG_3766.jpg', 23, '', 0, 0, '', ''),
(39, '7a5a2-IMG_3943.jpg', 23, '', 0, 0, '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes_hoteles`
--

CREATE TABLE IF NOT EXISTS `imagenes_hoteles` (
  `id_imagen` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(128) CHARACTER SET latin1 NOT NULL,
  `tipo` varchar(32) CHARACTER SET latin1 NOT NULL,
  `size` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `titulo` text CHARACTER SET latin1 NOT NULL,
  `descripcion` text CHARACTER SET latin1 NOT NULL,
  `id_hotel` int(11) NOT NULL,
  PRIMARY KEY (`id_imagen`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=123 ;

--
-- Volcado de datos para la tabla `imagenes_hoteles`
--

INSERT INTO `imagenes_hoteles` (`id_imagen`, `imagen`, `tipo`, `size`, `orden`, `titulo`, `descripcion`, `id_hotel`) VALUES
(1, '34ce6-IMG_3766.jpg', '', 0, 10, '', '', 5),
(2, '50b9f-IMG_3672.jpg', '', 0, 2, '', '', 5),
(3, '6aac7-IMG_3767.jpg', '', 0, 13, '', '', 5),
(5, '94615-IMG_3820.jpg', '', 0, 4, '', '', 5),
(7, 'ae1a8-IMG_3848.jpg', '', 0, 7, '', '', 5),
(8, '65398-IMG_3880.jpg', '', 0, 8, '', '', 5),
(9, 'ac664-IMG_3900.jpg', '', 0, 1, '', '', 5),
(10, 'ea3c0-IMG_3885.jpg', '', 0, 9, '', '', 5),
(11, '671bd-IMG_3911.jpg', '', 0, 18, '', '', 5),
(12, '8e691-IMG_3922.jpg', '', 0, 11, '', '', 5),
(13, 'eb7a7-IMG_3924.jpg', '', 0, 12, '', '', 5),
(14, 'ef91e-IMG_3929.jpg', '', 0, 14, '', '', 5),
(15, '251a9-IMG_3943.jpg', '', 0, 15, '', '', 5),
(16, 'c146b-IMG_3932.jpg', '', 0, 16, '', '', 5),
(17, '190e0-IMG_3960.jpg', '', 0, 3, '', '', 5),
(18, 'acd68-IMG_3949.jpg', '', 0, 17, '', '', 5),
(19, 'd0779-IMG_3967.jpg', '', 0, 20, '', '', 5),
(20, '53e25-IMG_4163.jpg', '', 0, 21, '', '', 5),
(21, '19ee7-IMG_4159.jpg', '', 0, 19, '', '', 5),
(22, '689c6-100_0633.JPG', '', 0, 1, '', '', 2),
(23, '3c828-Frente.jpg', '', 0, 2, '', '', 2),
(24, '09ea9-IMG_4010.jpg', '', 0, 12, '', '', 2),
(25, 'c86a9-IMG_4030.jpg', '', 0, 13, '', '', 2),
(26, 'edaf0-IMG_4038.jpg', '', 0, 14, '', '', 2),
(28, '7e0c1-IMG_4056.jpg', '', 0, 16, '', '', 2),
(29, '99655-IMG_4042.jpg', '', 0, 17, '', '', 2),
(30, '287d4-IMG_4083.jpg', '', 0, 18, '', '', 2),
(31, 'd979b-IMG_4131.jpg', '', 0, 9, '', '', 2),
(32, '79cba-IMG_4135.jpg', '', 0, 10, '', '', 2),
(33, 'ab5f0-IMG_4177.jpg', '', 0, 29, '', '', 2),
(35, 'c90b5-IMG_4157.jpg', '', 0, 30, '', '', 2),
(36, '4ff2c-IMG_4212.jpg', '', 0, 19, '', '', 2),
(37, '57176-IMG_4216.jpg', '', 0, 20, '', '', 2),
(38, 'a834c-IMG_4238.jpg', '', 0, 21, '', '', 2),
(39, '07195-IMG_4250.jpg', '', 0, 22, '', '', 2),
(40, '38e5c-IMG_4253.jpg', '', 0, 23, '', '', 2),
(41, '514fe-IMG_4262.jpg', '', 0, 24, '', '', 2),
(42, '9ffcb-IMG_4274.jpg', '', 0, 25, '', '', 2),
(43, '17224-IMG_4262---copia.jpg', '', 0, 26, '', '', 2),
(44, 'd07c8-IMG_4315.jpg', '', 0, 8, '', '', 2),
(45, 'd60cc-IMG_4303.jpg', '', 0, 6, '', '', 2),
(46, 'e6f6a-IMG_4325.jpg', '', 0, 3, '', '', 2),
(47, '920ee-IMG_4361.jpg', '', 0, 4, '', '', 2),
(48, 'e99a3-IMG_4338.jpg', '', 0, 5, '', '', 2),
(49, '28dc2-IMG_4399.jpg', '', 0, 27, '', '', 2),
(50, 'd01d8-unnamed.jpg', '', 0, 28, '', '', 2),
(51, 'aca13-IMG_4451.jpg', '', 0, 7, '', '', 2),
(53, 'e914e-DSC_1490.JPG', '', 0, 5, '', '', 1),
(54, 'c441b-DSC_1463.JPG', '', 0, 9, '', '', 1),
(55, '9a72e-IMG_2903.jpg', '', 0, 10, '', '', 1),
(56, 'd8291-IMG_2919.jpg', '', 0, 11, '', '', 1),
(58, 'e1bda-IMG_3119.jpg', '', 0, 7, '', '', 1),
(59, '55a8f-IMG_3132.jpg', '', 0, 8, '', '', 1),
(61, '316e7-IMG_2965.jpg', '', 0, 12, '', '', 1),
(62, '1e2c3-IMG_3042.jpg', '', 0, 2, '', '', 1),
(63, '2a74b-IMG_2967.jpg', '', 0, 13, '', '', 1),
(64, '2dbc2-IMG_2921.jpg', '', 0, 14, '', '', 1),
(67, 'a1dc7-IMG_3032.jpg', '', 0, 1, '', '', 1),
(68, '582d1-276.jpg', '', 0, 4, '', '', 1),
(69, 'c6dbb-273.jpg', '', 0, 6, '', '', 1),
(70, 'e91be-DSC_1460.JPG', '', 0, 16, '', '', 1),
(71, '30590-292.jpg', '', 0, 17, '', '', 1),
(72, '654f3-IMG_2970.jpg', '', 0, 18, '', '', 1),
(73, '04bb8-280.jpg', '', 0, 19, '', '', 1),
(75, '6f5e6-IMG_2975.jpg', '', 0, 21, '', '', 1),
(76, '4e776-IMG_2965.jpg', '', 0, 22, '', '', 1),
(77, 'e0982-2921.jpg', '', 0, 23, '', '', 1),
(79, '6ace6-304.jpg', '', 0, 15, '', '', 1),
(80, 'c2fac-420.jpg', '', 0, 25, '', '', 1),
(81, '7165b-dsc_0013.jpg', '', 0, 26, '', '', 1),
(82, '8fe5e-dsc_0002.jpg', '', 0, 27, '', '', 1),
(83, '90401-Princess-10-07-136.jpg', '', 0, 28, '', '', 1),
(84, '3a917-IMG_3036.jpg', '', 0, 3, '', '', 1),
(85, 'b69d8-dsc_0040.jpg', '', 0, 29, '', '', 1),
(87, 'ae6ed-IMG_3036.jpg', '', 0, 7, '', '', 3),
(88, '57975-IMG_3042.jpg', '', 0, 8, '', '', 3),
(89, 'e4a29-DSC02272.JPG', '', 0, 3, '', '', 3),
(90, '43f6a-IMG_3119.jpg', '', 0, 12, '', '', 3),
(92, 'a5ee6-DSC02278.JPG', '', 0, 4, '', '', 3),
(94, 'e1a1a-286.jpg', '', 0, 13, '', '', 3),
(98, '81f80-dsc_0038.jpg', '', 0, 14, '', '', 3),
(100, 'b1265-dsc_0011.jpg', '', 0, 26, '', '', 3),
(101, 'e902c-420.jpg', '', 0, 27, '', '', 3),
(102, '51033-dsc_0002.jpg', '', 0, 28, '', '', 3),
(103, '14b3a-DSC02371.JPG', '', 0, 15, '', '', 3),
(104, '205ca-IMG_3112.jpg', '', 0, 2, '', '', 3),
(105, '439da-DSC02282.JPG', '', 0, 1, '', '', 3),
(106, '9c88a-IMG_3105.jpg', '', 0, 6, '', '', 3),
(107, '4b89b-DSC02396.JPG', '', 0, 22, '', '', 3),
(108, '0b506-DSC02392.JPG', '', 0, 17, '', '', 3),
(109, '5c301-Princess-10-07-018.jpg', '', 0, 18, '', '', 3),
(110, '802e0-273.jpg', '', 0, 9, '', '', 3),
(111, 'caad5-276.jpg', '', 0, 11, '', '', 3),
(112, 'b5448-Princess-10-07-047.jpg', '', 0, 23, '', '', 3),
(113, '68644-Princess-10-07-136.jpg', '', 0, 29, '', '', 3),
(114, '11afb-Princess-10-07-139.jpg', '', 0, 20, '', '', 3),
(115, '48531-dsc_0013.jpg', '', 0, 30, '', '', 3),
(116, '1799f-Princess-10-07-138.jpg', '', 0, 19, '', '', 3),
(118, 'e31ef-dsc_0040.jpg', '', 0, 31, '', '', 3),
(119, 'eddfc-Princess-10-07-121.jpg', '', 0, 24, '', '', 3),
(120, '8293c-Princess-10-07-145.jpg', '', 0, 16, '', '', 3),
(121, '04b36-Princess-10-07-123.jpg', '', 0, 25, '', '', 3),
(122, 'd36a6-DSC_1490.JPG', '', 0, 10, '', '', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_articulos`
--

CREATE TABLE IF NOT EXISTS `logs_articulos` (
  `id_log_articulo` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_articulo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=120 ;

--
-- Volcado de datos para la tabla `logs_articulos`
--

INSERT INTO `logs_articulos` (`id_log_articulo`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'articulos', 1, 1, '2014-11-03 11:23:36', 1),
(2, 'articulos', 2, 1, '2014-11-03 11:24:51', 1),
(3, 'articulos', 2, 2, '2014-11-03 11:25:13', 1),
(4, 'articulos', 1, 2, '2014-11-03 11:28:20', 1),
(5, 'articulos', 1, 2, '2014-11-03 11:28:46', 1),
(6, 'articulos', 3, 1, '2014-11-03 11:36:29', 1),
(7, 'articulos', 1, 2, '2014-11-03 11:39:42', 1),
(8, 'articulos', 1, 2, '2014-11-03 11:42:15', 1),
(9, 'articulos', 2, 2, '2014-11-03 12:06:23', 1),
(10, 'articulos', 2, 2, '2014-11-03 12:07:47', 1),
(11, 'articulos', 3, 2, '2014-11-03 12:08:35', 1),
(12, 'categorias', 12, 1, '2014-11-03 12:39:10', 1),
(13, 'articulos', 1, 2, '2014-11-03 12:39:39', 1),
(14, 'articulos', 2, 2, '2014-11-03 12:39:59', 1),
(15, 'articulos', 4, 1, '2014-11-03 13:00:52', 1),
(16, 'articulos', 5, 1, '2014-11-03 13:02:22', 1),
(17, 'articulos', 6, 1, '2014-11-03 13:03:01', 1),
(18, 'articulos', 7, 1, '2014-11-03 13:03:32', 1),
(19, 'articulos', 8, 1, '2014-11-03 13:04:10', 1),
(20, 'articulos', 9, 1, '2014-11-05 10:39:31', 1),
(21, 'articulos', 10, 1, '2014-11-05 10:41:03', 1),
(22, 'articulos', 11, 1, '2014-11-05 10:42:06', 1),
(23, 'articulos', 12, 1, '2014-11-05 10:44:11', 1),
(24, 'articulos', 13, 1, '2014-11-05 10:45:18', 1),
(25, 'articulos', 14, 1, '2014-11-05 10:46:08', 1),
(26, 'articulos', 15, 1, '2014-11-05 10:46:56', 1),
(27, 'articulos', 16, 1, '2014-11-05 10:53:39', 1),
(28, 'articulos', 17, 1, '2014-11-05 10:54:28', 1),
(29, 'articulos', 18, 1, '2014-11-05 10:55:29', 1),
(30, 'articulos', 19, 1, '2014-11-05 10:56:28', 1),
(31, 'articulos', 16, 2, '2014-11-05 10:56:53', 1),
(32, 'categorias', 7, 3, '2014-11-05 10:59:29', 1),
(33, 'categorias', 8, 3, '2014-11-05 10:59:37', 1),
(34, 'categorias', 9, 3, '2014-11-05 10:59:43', 1),
(35, 'categorias', 10, 3, '2014-11-05 10:59:50', 1),
(36, 'categorias', 1, 3, '2014-11-05 10:59:57', 1),
(37, 'categorias', 2, 3, '2014-11-05 11:00:03', 1),
(38, 'categorias', 4, 3, '2014-11-05 11:00:11', 1),
(39, 'articulos', 16, 2, '2014-11-05 11:04:18', 1),
(40, 'articulos', 17, 2, '2014-11-05 11:05:30', 1),
(41, 'articulos', 18, 2, '2014-11-05 11:05:53', 1),
(42, 'articulos', 19, 2, '2014-11-05 11:06:14', 1),
(43, 'articulos', 10, 2, '2014-11-05 11:07:14', 1),
(44, 'articulos', 15, 2, '2014-11-05 11:08:19', 1),
(45, 'articulos', 20, 1, '2014-11-05 11:13:06', 1),
(46, 'articulos', 20, 2, '2014-11-05 11:13:57', 1),
(47, 'articulos', 20, 2, '2014-11-05 11:15:02', 1),
(48, 'articulos', 14, 2, '2014-11-06 12:54:18', 1),
(49, 'articulos', 14, 2, '2014-11-06 13:01:07', 1),
(50, 'articulos', 14, 2, '2014-11-06 13:51:02', 1),
(51, 'articulos', 3, 2, '2014-11-07 08:51:34', 1),
(52, 'articulos', 3, 2, '2014-11-07 09:20:44', 1),
(53, 'articulos', 3, 2, '2014-11-07 09:21:24', 1),
(54, 'articulos', 3, 2, '2014-11-07 09:21:38', 1),
(55, 'articulos', 6, 2, '2014-11-18 16:29:57', 1),
(56, 'articulos', 6, 2, '2014-11-18 16:33:31', 1),
(57, 'articulos', 6, 2, '2014-11-18 16:34:19', 1),
(58, 'articulos', 4, 2, '2014-11-18 16:39:36', 1),
(59, 'articulos', 5, 2, '2014-11-18 16:44:10', 1),
(60, 'articulos', 5, 2, '2014-11-18 16:45:39', 1),
(61, 'articulos', 7, 2, '2014-11-18 16:47:05', 1),
(62, 'categorias', 13, 1, '2014-11-18 16:48:55', 1),
(63, 'categorias', 13, 2, '2014-11-18 16:49:08', 1),
(64, 'articulos', 21, 1, '2014-11-18 16:58:45', 1),
(65, 'articulos', 3, 2, '2014-11-18 17:00:18', 1),
(66, 'articulos', 21, 2, '2014-11-18 17:03:12', 1),
(67, 'articulos', 21, 2, '2014-11-18 17:05:46', 1),
(68, 'articulos', 21, 2, '2014-11-18 17:08:53', 1),
(69, 'articulos', 22, 1, '2014-11-18 17:11:36', 1),
(70, 'articulos', 9, 2, '2014-11-18 17:12:11', 1),
(71, 'articulos', 21, 2, '2014-11-18 17:13:12', 1),
(72, 'articulos', 21, 2, '2014-11-18 17:13:39', 1),
(73, 'articulos', 23, 1, '2014-11-18 17:17:19', 1),
(74, 'articulos', 24, 1, '2014-11-18 17:20:17', 1),
(75, 'articulos', 22, 2, '2014-11-18 17:21:14', 1),
(76, 'articulos', 23, 2, '2014-11-18 17:23:15', 1),
(77, 'articulos', 14, 2, '2014-11-18 17:23:53', 1),
(78, 'articulos', 20, 2, '2014-11-18 17:25:03', 1),
(79, 'articulos', 14, 2, '2014-11-18 17:26:53', 1),
(80, 'config_correo', 1, 2, '2014-11-19 09:50:10', 1),
(81, 'config_correo', 1, 2, '2014-11-19 09:50:33', 1),
(82, 'config_correo', 1, 2, '2014-11-19 09:50:44', 1),
(83, 'config_correo', 1, 2, '2014-11-19 09:50:55', 1),
(84, 'config_correo', 1, 2, '2014-11-19 09:51:14', 1),
(85, 'config_correo', 1, 2, '2014-11-19 09:52:09', 1),
(86, 'config_correo', 1, 2, '2014-11-19 09:52:25', 1),
(87, 'config_correo', 1, 2, '2014-11-19 09:52:32', 1),
(88, 'config_correo', 1, 2, '2014-11-19 09:53:00', 1),
(89, 'config_correo', 1, 2, '2014-11-19 09:56:58', 1),
(90, 'config_correo', 1, 2, '2014-11-19 09:57:12', 1),
(91, 'articulos', 2, 2, '2014-11-20 10:18:54', 1),
(92, 'articulos', 2, 2, '2014-11-20 10:19:04', 1),
(93, 'articulos', 2, 2, '2014-11-20 10:19:12', 1),
(94, 'articulos', 2, 2, '2014-11-20 10:58:01', 1),
(95, 'articulos', 2, 2, '2014-11-21 08:46:31', 1),
(96, 'articulos', 22, 2, '2014-11-21 08:48:06', 1),
(97, 'articulos', 9, 2, '2014-11-21 09:01:08', 1),
(98, 'articulos', 9, 2, '2014-11-21 09:04:36', 1),
(99, 'articulos', 2, 2, '2014-11-21 09:05:21', 1),
(100, 'articulos', 22, 2, '2014-11-21 09:05:41', 1),
(101, 'articulos', 9, 2, '2014-11-21 09:20:01', 1),
(102, 'articulos', 22, 2, '2014-11-21 09:40:07', 1),
(103, 'articulos', 9, 2, '2014-11-21 09:44:58', 1),
(104, 'articulos', 13, 2, '2014-11-21 10:07:14', 1),
(105, 'articulos', 13, 2, '2014-11-21 10:07:36', 1),
(106, 'articulos', 10, 2, '2014-11-25 10:08:04', 1),
(107, 'articulos', 23, 2, '2014-11-25 10:08:31', 1),
(108, 'articulos', 23, 2, '2014-11-25 10:15:47', 1),
(109, 'articulos', 23, 2, '2014-11-25 10:16:14', 1),
(110, 'articulos', 23, 2, '2014-11-25 10:16:24', 1),
(111, 'articulos', 5, 2, '2014-11-26 08:54:37', 1),
(112, 'articulos', 5, 2, '2014-11-26 08:55:50', 1),
(113, 'articulos', 5, 2, '2014-11-26 08:56:22', 1),
(114, 'articulos', 5, 2, '2014-11-26 08:56:37', 1),
(115, 'articulos', 5, 2, '2014-11-26 08:57:12', 1),
(116, 'articulos', 5, 2, '2014-11-26 08:57:36', 1),
(117, 'articulos', 1, 2, '2014-11-26 11:29:04', 1),
(118, 'articulos', 1, 2, '2014-11-26 11:29:28', 1),
(119, 'articulos', 1, 2, '2014-12-01 15:43:16', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_habitaciones`
--

CREATE TABLE IF NOT EXISTS `logs_habitaciones` (
  `id_log_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=111 ;

--
-- Volcado de datos para la tabla `logs_habitaciones`
--

INSERT INTO `logs_habitaciones` (`id_log_habitacion`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'servicios', 2, 2, '2014-10-31 11:13:51', 1),
(2, 'servicios', 5, 2, '2014-10-31 11:14:16', 1),
(3, 'servicios', 11, 2, '2014-10-31 11:15:03', 1),
(4, 'servicios', 13, 2, '2014-10-31 11:15:30', 1),
(5, 'tipos_habitacion', 6, 1, '2014-10-31 11:57:08', 1),
(6, 'tipos_habitacion', 7, 1, '2014-10-31 11:57:38', 1),
(7, 'tipos_habitacion', 8, 1, '2014-10-31 11:58:09', 1),
(8, 'tipos_habitacion', 8, 2, '2014-10-31 11:58:56', 1),
(9, 'tarifas', 1, 1, '2014-11-03 10:53:07', 1),
(10, 'tarifas', 2, 1, '2014-11-03 10:53:42', 1),
(11, 'tarifas', 3, 1, '2014-11-03 10:54:07', 1),
(12, 'tarifas', 4, 1, '2014-11-03 10:54:33', 1),
(13, 'tarifas', 5, 1, '2014-11-03 10:54:54', 1),
(14, 'tarifas', 6, 1, '2014-11-03 10:55:21', 1),
(15, 'tarifas', 7, 1, '2014-11-03 10:55:49', 1),
(16, 'tarifas', 8, 1, '2014-11-03 10:56:13', 1),
(17, 'tarifas', 9, 1, '2014-11-03 10:56:48', 1),
(18, 'tarifas', 10, 1, '2014-11-03 10:57:14', 1),
(19, 'tarifas', 11, 1, '2014-11-03 10:57:37', 1),
(20, 'tarifas', 12, 1, '2014-11-03 10:58:09', 1),
(21, 'tarifas', 13, 1, '2014-11-03 10:58:29', 1),
(22, 'tarifas', 14, 1, '2014-11-03 10:58:53', 1),
(23, 'tarifas', 15, 1, '2014-11-03 10:59:15', 1),
(24, 'tarifas', 16, 1, '2014-11-03 10:59:44', 1),
(25, 'tarifas', 17, 1, '2014-11-03 11:01:06', 1),
(26, 'tarifas', 18, 1, '2014-11-03 11:01:28', 1),
(27, 'tarifas', 14, 2, '2014-11-03 11:50:17', 1),
(28, 'tarifas', 15, 2, '2014-11-03 11:50:36', 1),
(29, 'tarifas', 16, 2, '2014-11-03 11:50:53', 1),
(30, 'tarifas', 17, 2, '2014-11-03 11:51:10', 1),
(31, 'tarifas', 18, 2, '2014-11-03 11:51:28', 1),
(32, 'habitaciones', 1, 1, '2014-11-03 12:07:02', 1),
(33, 'habitaciones', 1, 2, '2014-11-03 12:11:45', 1),
(34, 'servicios', 5, 2, '2014-11-03 12:22:20', 1),
(35, 'servicios', 14, 1, '2014-11-03 12:23:14', 1),
(36, 'servicios', 15, 1, '2014-11-03 12:23:41', 1),
(37, 'servicios', 16, 1, '2014-11-03 12:24:12', 1),
(38, 'habitaciones', 1, 2, '2014-11-03 12:31:14', 1),
(39, 'habitaciones', 1, 2, '2014-11-03 12:32:03', 1),
(40, 'habitaciones', 1, 2, '2014-11-03 12:32:48', 1),
(41, 'habitaciones', 1, 2, '2014-11-03 12:33:01', 1),
(42, 'habitaciones', 1, 2, '2014-11-03 12:33:30', 1),
(43, 'habitaciones', 1, 2, '2014-11-03 12:34:24', 1),
(44, 'habitaciones', 1, 2, '2014-11-03 19:04:13', 1),
(45, 'habitaciones', 2, 1, '2014-11-03 19:07:41', 1),
(46, 'habitaciones', 3, 1, '2014-11-03 19:09:35', 1),
(47, 'habitaciones', 4, 1, '2014-11-03 19:11:24', 1),
(48, 'habitaciones', 5, 3, '2014-11-05 09:45:37', 1),
(49, 'habitaciones', 13, 1, '2014-11-05 10:00:43', 1),
(50, 'servicios', 15, 2, '2014-11-05 10:01:12', 1),
(51, 'habitaciones', 14, 1, '2014-11-05 10:02:30', 1),
(52, 'habitaciones', 15, 1, '2014-11-05 10:03:51', 1),
(53, 'habitaciones', 16, 1, '2014-11-05 10:05:53', 1),
(54, 'habitaciones', 17, 1, '2014-11-05 10:07:38', 1),
(55, 'habitaciones', 18, 1, '2014-11-05 10:09:07', 1),
(56, 'habitaciones', 19, 1, '2014-11-05 10:10:15', 1),
(57, 'habitaciones', 20, 1, '2014-11-05 10:12:54', 1),
(58, 'habitaciones', 21, 1, '2014-11-05 10:14:01', 1),
(59, 'habitaciones', 22, 1, '2014-11-05 10:15:09', 1),
(60, 'habitaciones', 23, 1, '2014-11-05 10:17:05', 1),
(61, 'habitaciones', 6, 3, '2014-11-05 10:20:52', 1),
(62, 'habitaciones', 24, 1, '2014-11-05 10:26:28', 1),
(63, 'habitaciones', 25, 1, '2014-11-05 10:28:10', 1),
(64, 'habitaciones', 1, 2, '2014-11-05 10:29:30', 1),
(65, 'habitaciones', 2, 2, '2014-11-05 10:29:52', 1),
(66, 'habitaciones', 3, 2, '2014-11-05 10:30:12', 1),
(67, 'habitaciones', 4, 2, '2014-11-05 10:30:32', 1),
(68, 'habitaciones', 7, 2, '2014-11-05 10:31:08', 1),
(69, 'habitaciones', 13, 2, '2014-11-05 10:31:32', 1),
(70, 'habitaciones', 14, 2, '2014-11-05 10:31:52', 1),
(71, 'habitaciones', 15, 2, '2014-11-05 10:32:13', 1),
(72, 'habitaciones', 16, 2, '2014-11-05 10:32:39', 1),
(73, 'habitaciones', 17, 2, '2014-11-05 10:32:57', 1),
(74, 'habitaciones', 18, 2, '2014-11-05 10:33:14', 1),
(75, 'habitaciones', 19, 2, '2014-11-05 10:33:33', 1),
(76, 'habitaciones', 20, 2, '2014-11-05 10:33:55', 1),
(77, 'habitaciones', 21, 2, '2014-11-05 10:34:14', 1),
(78, 'habitaciones', 22, 2, '2014-11-05 10:34:33', 1),
(79, 'habitaciones', 23, 2, '2014-11-05 10:35:04', 1),
(80, 'habitaciones', 7, 3, '2014-11-06 12:59:04', 1),
(81, 'habitaciones', 7, 3, '2014-11-06 12:59:07', 1),
(82, 'habitaciones', 8, 3, '2014-11-06 12:59:10', 1),
(83, 'habitaciones', 8, 3, '2014-11-06 12:59:14', 1),
(84, 'habitaciones', 9, 3, '2014-11-06 12:59:21', 1),
(85, 'habitaciones', 9, 3, '2014-11-06 12:59:26', 1),
(86, 'habitaciones', 10, 3, '2014-11-06 12:59:30', 1),
(87, 'habitaciones', 11, 3, '2014-11-06 12:59:37', 1),
(88, 'habitaciones', 12, 3, '2014-11-06 12:59:43', 1),
(89, 'habitaciones', 26, 1, '2014-11-06 13:08:50', 1),
(90, 'habitaciones', 1, 2, '2014-11-18 14:39:28', 1),
(91, 'habitaciones', 2, 2, '2014-11-18 14:39:59', 1),
(92, 'habitaciones', 3, 2, '2014-11-18 14:40:22', 1),
(93, 'habitaciones', 4, 2, '2014-11-18 14:40:47', 1),
(94, 'servicios', 5, 2, '2014-11-18 14:41:19', 1),
(95, 'habitaciones', 5, 2, '2014-11-18 14:42:16', 1),
(96, 'habitaciones', 13, 2, '2014-11-18 14:43:05', 1),
(97, 'habitaciones', 14, 2, '2014-11-18 14:43:56', 1),
(98, 'habitaciones', 15, 2, '2014-11-18 14:44:31', 1),
(99, 'habitaciones', 16, 2, '2014-11-18 14:45:09', 1),
(100, 'habitaciones', 17, 2, '2014-11-18 14:45:57', 1),
(101, 'habitaciones', 18, 2, '2014-11-18 14:46:27', 1),
(102, 'habitaciones', 19, 2, '2014-11-18 14:46:59', 1),
(103, 'habitaciones', 20, 2, '2014-11-18 14:47:42', 1),
(104, 'habitaciones', 21, 2, '2014-11-18 14:48:12', 1),
(105, 'habitaciones', 21, 2, '2014-11-18 14:48:43', 1),
(106, 'habitaciones', 22, 2, '2014-11-18 14:49:15', 1),
(107, 'habitaciones', 23, 2, '2014-11-18 14:49:47', 1),
(108, 'habitaciones', 24, 2, '2014-11-18 14:50:20', 1),
(109, 'habitaciones', 25, 2, '2014-11-18 14:50:57', 1),
(110, 'tarifas_temporales', 1, 1, '2014-11-20 13:14:54', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_hoteles`
--

CREATE TABLE IF NOT EXISTS `logs_hoteles` (
  `id_log_hotel` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(32) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_hotel`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Volcado de datos para la tabla `logs_hoteles`
--

INSERT INTO `logs_hoteles` (`id_log_hotel`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'hoteles', 1, 2, '2014-10-29 08:56:05', 1),
(2, 'hoteles', 1, 2, '2014-10-31 10:28:36', 1),
(3, 'hoteles', 2, 2, '2014-10-31 10:29:26', 1),
(4, 'hoteles', 3, 2, '2014-10-31 10:30:20', 1),
(5, 'hoteles', 4, 2, '2014-10-31 10:31:01', 1),
(6, 'hoteles', 5, 2, '2014-10-31 10:31:31', 1),
(7, 'hoteles', 3, 2, '2014-11-03 12:26:25', 1),
(8, 'hoteles', 1, 2, '2014-11-03 12:27:26', 1),
(9, 'hoteles', 2, 2, '2014-11-03 12:30:06', 1),
(10, 'hoteles', 5, 2, '2014-11-03 12:31:48', 1),
(11, 'hoteles', 4, 2, '2014-11-03 12:33:49', 1),
(12, 'hoteles', 1, 2, '2014-11-03 12:58:03', 1),
(13, 'hoteles', 1, 2, '2014-11-03 19:13:37', 1),
(14, 'hoteles', 2, 2, '2014-11-03 19:14:14', 1),
(15, 'hoteles', 3, 2, '2014-11-03 19:14:41', 1),
(16, 'hoteles', 5, 2, '2014-11-03 19:15:06', 1),
(17, 'hoteles', 1, 2, '2014-11-04 11:45:33', 1),
(18, 'hoteles', 2, 2, '2014-11-04 11:45:59', 1),
(19, 'hoteles', 3, 2, '2014-11-04 11:46:31', 1),
(20, 'hoteles', 4, 2, '2014-11-04 11:46:58', 1),
(21, 'hoteles', 5, 2, '2014-11-04 11:47:19', 1),
(22, 'hoteles', 1, 2, '2014-11-19 11:50:05', 1),
(23, 'hoteles', 1, 2, '2014-11-19 12:28:32', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_huespedes`
--

CREATE TABLE IF NOT EXISTS `logs_huespedes` (
  `id_log_huesped` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_huesped`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_mensajes`
--

CREATE TABLE IF NOT EXISTS `logs_mensajes` (
  `id_log_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_mensaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `logs_mensajes`
--

INSERT INTO `logs_mensajes` (`id_log_mensaje`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'mensajes', 1, 2, '2014-11-04 11:58:05', 1),
(2, 'mensajes', 2, 2, '2014-11-04 11:58:05', 1),
(3, 'mensajes', 3, 2, '2014-11-04 11:58:05', 1),
(4, 'mensajes', 1, 3, '2014-11-04 11:58:41', 1),
(5, 'mensajes', 2, 3, '2014-11-04 11:58:49', 1),
(6, 'mensajes', 3, 3, '2014-11-04 11:58:57', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_otros`
--

CREATE TABLE IF NOT EXISTS `logs_otros` (
  `id_log_otro` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_otro`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_reservas`
--

CREATE TABLE IF NOT EXISTS `logs_reservas` (
  `id_log_reserva` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_reserva`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Volcado de datos para la tabla `logs_reservas`
--

INSERT INTO `logs_reservas` (`id_log_reserva`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'reservas', 1, 2, '2014-11-04 11:56:46', 1),
(2, 'reservas', 2, 2, '2014-11-04 11:56:46', 1),
(3, 'reservas', 3, 2, '2014-11-04 11:56:46', 1),
(4, 'reservas', 1, 3, '2014-11-04 11:57:17', 1),
(5, 'reservas', 2, 3, '2014-11-04 11:57:23', 1),
(6, 'reservas', 3, 3, '2014-11-04 13:42:12', 1),
(7, 'vuelos', 1, 3, '2014-11-04 13:42:32', 1),
(8, 'vuelos', 2, 3, '2014-11-04 13:42:40', 1),
(9, 'vuelos', 3, 3, '2014-11-04 13:42:44', 1),
(10, 'disponibilidades', 1, 1, '2014-11-20 13:13:19', 1),
(11, 'disponibilidades', 1, 3, '2014-11-20 13:14:28', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_usuarios`
--

CREATE TABLE IF NOT EXISTS `logs_usuarios` (
  `id_log_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE IF NOT EXISTS `mensajes` (
  `id_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(128) CHARACTER SET latin1 NOT NULL,
  `mensaje` text CHARACTER SET latin1 NOT NULL,
  `emisor` varchar(128) CHARACTER SET latin1 NOT NULL,
  `id_tipo_mensaje` int(11) NOT NULL,
  `fecha_envio` datetime NOT NULL,
  `nombre` varchar(64) COLLATE latin1_spanish_ci NOT NULL,
  `apellido` varchar(64) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(64) COLLATE latin1_spanish_ci NOT NULL,
  `id_estado_mensaje` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `comentario` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_mensaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=19 ;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id_mensaje`, `titulo`, `mensaje`, `emisor`, `id_tipo_mensaje`, `fecha_envio`, `nombre`, `apellido`, `telefono`, `id_estado_mensaje`, `id_hotel`, `comentario`, `delete`) VALUES
(1, 'Envió de habitacion ID: 6', 'HOLA', 'VANINAMURATTI@GMAIL.COM', 2, '2014-11-04 10:56:21', 'vanina', 'MURATTI', '', 2, 1, '', 1),
(2, 'Consulta web', 'prueba', 'VANINAMURATTI@GMAIL.COM', 1, '2014-11-04 11:08:13', 'vanina', 'MURATTI', '0261-4235666', 2, 1, '', 1),
(3, 'Consulta web', 'prueba', 'VANINAMURATTI@GMAIL.COM', 1, '2014-11-04 11:49:36', 'vanina', 'muratti', '2345656', 2, 1, '', 1),
(4, 'Consulta web', 'prueba', 'VANINAMURATTI@GMAIL.COM', 1, '2014-11-18 03:48:35', 'vanina', 'muratti', '123453', 1, 1, '', 0),
(5, 'Envió de habitacion ID: 16', 'prueba', 'VANINAMURATTI@GMAIL.COM', 2, '2014-11-18 03:50:36', 'vanina', 'muratti', '', 1, 1, '', 0),
(6, 'Envió de habitacion ID: 16', 'prueba', 'VANINAMURATTI@GMAIL.COM', 2, '2014-11-18 03:56:40', 'pepe', 'prpe', '', 1, 1, '', 0),
(7, 'Envió de habitacion ID: 5', 'prueba', 'VANINAMURATTI@GMAIL.COM', 2, '2014-11-18 03:59:59', 'pepe ', 'nnñk', '', 1, 1, '', 0),
(8, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-11-20 10:54:40', 'Nombre', 'Apellido', '', 1, 2, '', 0),
(9, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-11-20 10:55:10', 'Nombre', 'Apellido', '', 1, 2, '', 0),
(10, 'Envió de habitacion ID: 3', 'Test', 'diego_nieto_1@hotmail.com', 2, '2014-11-20 10:56:07', 'Diego', 'Nieto', '', 1, 2, '', 0),
(11, 'Envió de habitacion ID: 14', 'Test', 'diego_nieto_1@hotmail.com', 2, '2014-11-20 11:03:52', 'Diego', 'Nieto', '', 1, 2, '', 0),
(12, 'Consulta web', 'asdf', 'asdf@asdf.com', 1, '2014-11-20 11:04:21', 'asdf', 'asdfas', 'dfasd', 1, 2, '', 0),
(13, 'Consulta web', 'asdf', 'asdf@asdf.com', 1, '2014-11-20 11:04:27', 'asdf', 'asdfas', 'dfasd', 1, 2, '', 0),
(14, 'Consulta web', 'asdf', 'asdf@asdf.com', 1, '2014-11-20 11:09:03', 'asdf', 'asdfas', 'dfasd', 1, 2, '', 0),
(15, 'Consulta web', 'asdf', 'asdf@asdf.com', 1, '2014-11-20 11:09:09', 'asdf', 'asdfas', 'dfasd', 1, 2, '', 0),
(16, 'Consulta web', 'asdf', 'asdf@asdf.com', 1, '2014-11-20 11:11:25', 'asdf', 'asdfas', 'dfasd', 1, 2, '', 0),
(17, 'Consulta web', 'asdf', 'asdf@asdf.com', 1, '2014-11-20 11:12:53', 'asdf', 'asdfas', 'dfasd', 1, 2, '', 0),
(18, 'Envió de habitacion ID: 3', 'Neuvo', 'asdf@asdf.com', 2, '2014-11-20 01:05:49', 'asdf', 'asdf', '', 1, 2, '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulos`
--

CREATE TABLE IF NOT EXISTS `modulos` (
  `id_modulo` int(11) NOT NULL AUTO_INCREMENT,
  `modulo` varchar(32) NOT NULL,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` varchar(32) NOT NULL,
  `titulo` varchar(32) NOT NULL,
  `descripcion` varchar(32) NOT NULL,
  `usa_titulo` tinyint(4) NOT NULL,
  `usa_descripcion` tinyint(4) NOT NULL,
  `usa_hotel` int(11) NOT NULL,
  `delete` int(11) NOT NULL,
  PRIMARY KEY (`id_modulo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `modulos`
--

INSERT INTO `modulos` (`id_modulo`, `modulo`, `tabla`, `id_tabla`, `titulo`, `descripcion`, `usa_titulo`, `usa_descripcion`, `usa_hotel`, `delete`) VALUES
(1, 'Habitaciones', 'habitaciones', 'id_habitacion', 'habitacion', 'descripcion', 1, 1, 1, 0),
(2, 'Articulos', 'articulos', 'id_articulo', 'titulo', 'articulo', 1, 1, 1, 0),
(4, 'Categorias', 'categorias', 'id_categoria', 'categoria', '', 1, 0, 0, 0),
(5, 'Servicios', 'servicios', 'id_servicio', 'servicio', '', 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulos_idioma`
--

CREATE TABLE IF NOT EXISTS `modulos_idioma` (
  `id_modulo_idioma` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `descripcion` text NOT NULL,
  `id_modulo` int(11) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_idioma` int(11) NOT NULL,
  `id_estado_traduccion` int(11) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_modulo_idioma`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=147 ;

--
-- Volcado de datos para la tabla `modulos_idioma`
--

INSERT INTO `modulos_idioma` (`id_modulo_idioma`, `titulo`, `descripcion`, `id_modulo`, `id_tabla`, `id_idioma`, `id_estado_traduccion`, `delete`) VALUES
(1, '-', '', 1, 1, 2, 2, 0),
(2, '-', '-', 1, 2, 2, 1, 0),
(3, 'Room Single', '<div>\r\n	Our Rooms Singles are for one person in double or twin bed (subject to availability). They are fully equipped to offer maximum comfort during your stay includes:</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	TV</div>\r\n<div>\r\n	Security Box</div>\r\n<div>\r\n	Private bathroom</div>\r\n<div>\r\n	Hair dryer</div>\r\n<div>\r\n	amenities</div>\r\n<div>\r\n	phone</div>\r\n<div>\r\n	heating</div>\r\n<div>\r\n	refrigeration</div>\r\n', 1, 3, 2, 3, 0),
(4, '-', '-', 1, 4, 2, 1, 0),
(5, '-', '-', 1, 5, 2, 1, 0),
(6, '-', '-', 1, 13, 2, 1, 0),
(7, '-', '-', 1, 14, 2, 1, 0),
(8, '-', '-', 1, 15, 2, 1, 0),
(9, '-', '-', 1, 16, 2, 1, 0),
(10, '-', '-', 1, 17, 2, 1, 0),
(11, '-', '-', 1, 18, 2, 1, 0),
(12, '-', '-', 1, 19, 2, 1, 0),
(13, '-', '-', 1, 20, 2, 1, 0),
(14, '-', '-', 1, 21, 2, 1, 0),
(15, '-', '-', 1, 22, 2, 1, 0),
(16, '-', '-', 1, 23, 2, 1, 0),
(17, 'Habitación Suite', '<p>\r\n	Nuestras Habitaciones Suite &nbsp;tienen capacidad para dos personas en cama matrimonial tama&ntilde;o king. Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia, cuentan con:</p>\r\n<ul>\r\n	<li>\r\n		TV Led&nbsp;</li>\r\n	<li>\r\n		Cofre de Seguridad</li>\r\n	<li>\r\n		Ba&ntilde;o Privado</li>\r\n	<li>\r\n		Secador de pelo</li>\r\n	<li>\r\n		Amenities</li>\r\n	<li>\r\n		Tel&eacute;fono</li>\r\n	<li>\r\n		Calefacci&oacute;n</li>\r\n	<li>\r\n		Refrigeraci&oacute;n</li>\r\n</ul>\r\n', 1, 24, 2, 3, 0),
(18, '-', '', 1, 25, 2, 2, 0),
(19, 'Habitación Single ', '<p>\r\n	<font><font>Nuestras Habitaciones Singles tienen capacidad para una persona en cama matrimonial o twin (segun DISPONIBILIDAD).&nbsp;</font></font><span style="font-size: 11.8181819915771px;">Est&aacute;n totalmente equipadas para ofrecerles el m&aacute;ximo confort durante su estadia cuenta con:</span></p>\r\n<ul style="font-size: 11.8181819915771px;">\r\n	<li>\r\n		TV&nbsp;</li>\r\n	<li>\r\n		Cofre de Seguridad</li>\r\n	<li>\r\n		Ba&ntilde;o Privado</li>\r\n	<li>\r\n		Secador de pelo</li>\r\n	<li>\r\n		Amenities</li>\r\n	<li>\r\n		Tel&eacute;fono</li>\r\n	<li>\r\n		Calefacci&oacute;n</li>\r\n	<li>\r\n		Refrigeraci&oacute;n</li>\r\n</ul>\r\n', 1, 1, 3, 2, 0),
(20, '-', '-', 1, 2, 3, 1, 0),
(21, 'Chambre Simple', '<div>\r\n	Nos chambres sont c&eacute;libataires pour une personne dans le lit double ou lits jumeaux (sous r&eacute;serve de disponibilit&eacute;). Ils sont enti&egrave;rement &eacute;quip&eacute;s pour offrir un maximum de confort lors de votre s&eacute;jour comprend:</div>\r\n<ul>\r\n	<li>\r\n		TV</li>\r\n	<li>\r\n		Security Box</li>\r\n	<li>\r\n		Salle de bain priv&eacute;e</li>\r\n	<li>\r\n		S&egrave;che-cheveux</li>\r\n	<li>\r\n		&eacute;quipements</li>\r\n	<li>\r\n		t&eacute;l&eacute;phone</li>\r\n	<li>\r\n		chauffage</li>\r\n	<li>\r\n		r&eacute;frig&eacute;ration</li>\r\n</ul>\r\n', 1, 3, 3, 3, 0),
(22, '-', '-', 1, 4, 3, 1, 0),
(23, '-', '-', 1, 5, 3, 1, 0),
(24, '-', '-', 1, 13, 3, 1, 0),
(25, '-', '-', 1, 14, 3, 1, 0),
(26, '-', '-', 1, 15, 3, 1, 0),
(27, '-', '-', 1, 16, 3, 1, 0),
(28, '-', '-', 1, 17, 3, 1, 0),
(29, '-', '-', 1, 18, 3, 1, 0),
(30, '-', '-', 1, 19, 3, 1, 0),
(31, '-', '-', 1, 20, 3, 1, 0),
(32, '-', '-', 1, 21, 3, 1, 0),
(33, '-', '-', 1, 22, 3, 1, 0),
(34, '-', '-', 1, 23, 3, 1, 0),
(35, '-', '-', 1, 24, 3, 1, 0),
(36, '-', '-', 1, 25, 3, 1, 0),
(37, '-', '-', 2, 1, 2, 1, 0),
(38, '-', '-', 2, 2, 2, 1, 0),
(39, '-', '-', 2, 3, 2, 1, 0),
(40, '-', '-', 2, 4, 2, 1, 0),
(41, '-', '-', 2, 5, 2, 1, 0),
(42, '-', '-', 2, 6, 2, 1, 0),
(43, '-', '-', 2, 7, 2, 1, 0),
(44, '-', '-', 2, 8, 2, 1, 0),
(45, '-', '-', 2, 9, 2, 1, 0),
(46, 'PROMO 4X3', '<p style="font-size: 11.8181819915771px; text-align: center;">\r\n	<u>PROMO 4X3!!</u></p>\r\n<p style="font-size: 11.8181819915771px;">\r\n	En ingles</p>\r\n', 2, 10, 2, 3, 0),
(47, '-', '-', 2, 11, 2, 1, 0),
(48, '-', '-', 2, 12, 2, 1, 0),
(49, '-', '-', 2, 13, 2, 1, 0),
(50, '-', '-', 2, 14, 2, 1, 0),
(51, '-', '-', 2, 15, 2, 1, 0),
(52, '-', '-', 2, 16, 2, 1, 0),
(53, '-', '-', 2, 17, 2, 1, 0),
(54, 'FALL SPECIAL PROMO', '<div>\r\n	FALL SPECIAL !!</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	In Autumn San Luis come here to enjoy a 30% discount if your stay is over three days !! For April, May and June months.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	To book send us an inquiry and we will respond promptly.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	Not applicable at Easter and Long Weekends, or combined with other offers.</div>\r\n', 2, 18, 2, 3, 0),
(55, '-', '-', 2, 19, 2, 1, 0),
(56, '-', '-', 2, 20, 2, 1, 0),
(57, '-', '-', 2, 21, 2, 1, 0),
(58, '-', '-', 2, 22, 2, 1, 0),
(59, '-', '-', 2, 23, 2, 1, 0),
(60, '-', '-', 2, 24, 2, 1, 0),
(61, 'Promotion 2', '0', 4, 3, 2, 3, 0),
(62, '-', '-', 4, 5, 2, 1, 0),
(63, '-', '-', 4, 6, 2, 1, 0),
(64, '-', '-', 4, 12, 2, 1, 0),
(65, 'Companies and Institutions', '0', 4, 13, 2, 3, 0),
(66, '-', '-', 5, 1, 2, 1, 0),
(67, '-', '-', 5, 2, 2, 1, 0),
(68, 'Emergencies', '0', 5, 4, 2, 3, 0),
(69, '-', '-', 5, 5, 2, 1, 0),
(70, '-', '-', 5, 6, 2, 1, 0),
(71, '-', '-', 5, 7, 2, 1, 0),
(72, '-', '-', 5, 9, 2, 1, 0),
(73, '-', '-', 5, 10, 2, 1, 0),
(74, '-', '-', 5, 11, 2, 1, 0),
(75, '-', '-', 5, 12, 2, 1, 0),
(76, '-', '-', 5, 13, 2, 1, 0),
(77, '-', '-', 5, 14, 2, 1, 0),
(78, '-', '-', 5, 15, 2, 1, 0),
(79, 'Additional cot free of charge', '0', 5, 16, 2, 3, 0),
(80, 'Promotions', '0', 4, 3, 3, 3, 0),
(81, '-', '-', 4, 5, 3, 1, 0),
(82, '-', '-', 4, 6, 3, 1, 0),
(83, '-', '-', 4, 12, 3, 1, 0),
(84, '-', '-', 4, 13, 3, 1, 0),
(85, '-', '-', 5, 1, 3, 1, 0),
(86, '-', '-', 5, 2, 3, 1, 0),
(87, '-', '-', 5, 4, 3, 1, 0),
(88, '-', '-', 5, 5, 3, 1, 0),
(89, '-', '-', 5, 6, 3, 1, 0),
(90, '-', '-', 5, 7, 3, 1, 0),
(91, '-', '-', 5, 9, 3, 1, 0),
(92, '-', '-', 5, 10, 3, 1, 0),
(93, '-', '-', 5, 11, 3, 1, 0),
(94, '-', '-', 5, 12, 3, 1, 0),
(95, '-', '-', 5, 13, 3, 1, 0),
(96, '-', '-', 5, 14, 3, 1, 0),
(97, '-', '-', 5, 15, 3, 1, 0),
(98, 'Aucun frais supplémentaire Lit', '0', 5, 16, 3, 3, 0),
(99, '-', '-', 2, 1, 1, 1, 0),
(100, '-', '-', 2, 2, 1, 1, 0),
(101, '-', '-', 2, 3, 1, 1, 0),
(102, '-', '-', 2, 4, 1, 1, 0),
(103, '-', '-', 2, 5, 1, 1, 0),
(104, '-', '-', 2, 6, 1, 1, 0),
(105, '-', '-', 2, 7, 1, 1, 0),
(106, '-', '-', 2, 8, 1, 1, 0),
(107, '-', '-', 2, 9, 1, 1, 0),
(108, '-', '-', 2, 10, 1, 1, 0),
(109, '-', '-', 2, 11, 1, 1, 0),
(110, '-', '-', 2, 12, 1, 1, 0),
(111, '-', '-', 2, 13, 1, 1, 0),
(112, '-', '-', 2, 14, 1, 1, 0),
(113, '-', '-', 2, 15, 1, 1, 0),
(114, '-', '-', 2, 16, 1, 1, 0),
(115, '-', '-', 2, 17, 1, 1, 0),
(116, '-', '-', 2, 18, 1, 1, 0),
(117, '-', '-', 2, 19, 1, 1, 0),
(118, '-', '-', 2, 20, 1, 1, 0),
(119, '-', '-', 2, 21, 1, 1, 0),
(120, '-', '-', 2, 22, 1, 1, 0),
(121, '-', '-', 2, 23, 1, 1, 0),
(122, '-', '-', 2, 24, 1, 1, 0),
(123, '-', '-', 2, 1, 3, 1, 0),
(124, '-', '-', 2, 2, 3, 1, 0),
(125, '-', '-', 2, 3, 3, 1, 0),
(126, '-', '-', 2, 4, 3, 1, 0),
(127, '-', '-', 2, 5, 3, 1, 0),
(128, '-', '-', 2, 6, 3, 1, 0),
(129, '-', '-', 2, 7, 3, 1, 0),
(130, '-', '-', 2, 8, 3, 1, 0),
(131, '-', '-', 2, 9, 3, 1, 0),
(132, 'Alimentation 4X3', '<div style="text-align: center;">\r\n	<u>PROMO 4X3 !!</u></div>\r\n<div>\r\n	&nbsp;</div>\r\n<h1>\r\n	<span style="font-size:12px;"><span style="font-family:tahoma,geneva,sans-serif;">Nous vous attendons &agrave; profiter de nos services s&eacute;journant 4 nuits et de payer seulement 3 nuits !!!</span></span></h1>\r\n<h1>\r\n	&nbsp;</h1>\r\n<h1>\r\n	<span style="font-size:12px;"><span style="font-family:tahoma,geneva,sans-serif;">Pour r&eacute;server nous envoyer une demande et nous vous r&eacute;pondrons rapidement.</span></span></h1>\r\n<h1>\r\n	&nbsp;</h1>\r\n<h1>\r\n	<span style="font-size:12px;"><span style="font-family:tahoma,geneva,sans-serif;">Exclut haute saison ou longs week-ends.</span></span></h1>\r\n<div>\r\n	&nbsp;</div>\r\n', 2, 10, 3, 3, 0),
(133, '-', '-', 2, 11, 3, 1, 0),
(134, '-', '-', 2, 12, 3, 1, 0),
(135, '-', '-', 2, 13, 3, 1, 0),
(136, '-', '-', 2, 14, 3, 1, 0),
(137, '-', '-', 2, 15, 3, 1, 0),
(138, '-', '-', 2, 16, 3, 1, 0),
(139, '-', '-', 2, 17, 3, 1, 0),
(140, '-', '-', 2, 18, 3, 1, 0),
(141, '-', '-', 2, 19, 3, 1, 0),
(142, '-', '-', 2, 20, 3, 1, 0),
(143, '-', '-', 2, 21, 3, 1, 0),
(144, '-', '-', 2, 22, 3, 1, 0),
(145, '-', '-', 2, 23, 3, 1, 0),
(146, '-', '-', 2, 24, 3, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `monedas`
--

CREATE TABLE IF NOT EXISTS `monedas` (
  `id_moneda` int(11) NOT NULL AUTO_INCREMENT,
  `moneda` varchar(64) CHARACTER SET latin1 NOT NULL,
  `abreviatura` varchar(8) COLLATE latin1_spanish_ci NOT NULL,
  `simbolo` char(3) COLLATE latin1_spanish_ci NOT NULL,
  `valor` float NOT NULL,
  `imagen` varchar(64) COLLATE latin1_spanish_ci NOT NULL,
  `id_pais` int(11) NOT NULL,
  `delete` int(11) NOT NULL,
  PRIMARY KEY (`id_moneda`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `monedas`
--

INSERT INTO `monedas` (`id_moneda`, `moneda`, `abreviatura`, `simbolo`, `valor`, `imagen`, `id_pais`, `delete`) VALUES
(1, 'Peso', 'ar', '$', 1, '9d48a-argentina-icono-8268-48.png', 32, 0),
(2, 'Dollar', 'usd', '$', 8.28, '09c26-bandera-icono-5097-48.png', 840, 0),
(3, 'Euro', 'EUR', '€', 8.2, 'e343a-bandera-de-la-union-europea-icono-5854-48.png', 724, 0),
(4, 'Peso', 'cl', '$', 69.5, 'f0833-chile-icono-5681-48.png', 152, 0),
(5, 'Real', 'br', 'R$', 3.9, '4319e-brasil-icono-8028-48.png', 76, 0),
(7, 'pepe', '123', '123', 123, '', 4, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notas`
--

CREATE TABLE IF NOT EXISTS `notas` (
  `id_nota` int(11) NOT NULL AUTO_INCREMENT,
  `nota` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_nota`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `notas`
--

INSERT INTO `notas` (`id_nota`, `nota`) VALUES
(1, 'prueba'),
(2, 'prueba'),
(3, 'prueba'),
(4, 'prueba');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paises`
--

CREATE TABLE IF NOT EXISTS `paises` (
  `id_pais` int(3) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `pais` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_pais`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=895 ;

--
-- Volcado de datos para la tabla `paises`
--

INSERT INTO `paises` (`id_pais`, `pais`) VALUES
(004, 'Afganistán'),
(008, 'Albania'),
(010, 'Antártida'),
(012, 'Argelia'),
(016, 'Samoa Americana'),
(020, 'Andorra'),
(024, 'Angola'),
(028, 'Antigua y Barbuda'),
(031, 'Azerbaiyán'),
(032, 'Argentina'),
(036, 'Australia'),
(040, 'Austria'),
(044, 'Bahamas'),
(048, 'Bahréin'),
(050, 'Bangladesh'),
(051, 'Armenia'),
(052, 'Barbados'),
(056, 'Bélgica'),
(060, 'Bermudas'),
(064, 'Bhután'),
(068, 'Bolivia'),
(070, 'Bosnia y Herzegovina'),
(072, 'Botsuana'),
(074, 'Isla Bouvet'),
(076, 'Brasil'),
(084, 'Belice'),
(086, 'Territorio Británico del Océano Índico'),
(090, 'Islas Salomón'),
(092, 'Islas Vírgenes Británicas'),
(096, 'Brunéi'),
(100, 'Bulgaria'),
(104, 'Myanmar'),
(108, 'Burundi'),
(112, 'Bielorrusia'),
(116, 'Camboya'),
(120, 'Camerún'),
(124, 'Canadá'),
(132, 'Cabo Verde'),
(136, 'Islas Caimán'),
(140, 'República Centroafricana'),
(144, 'Sri Lanka'),
(148, 'Chad'),
(152, 'Chile'),
(156, 'China'),
(158, 'Taiwán'),
(162, 'Isla de Navidad'),
(166, 'Islas Cocos'),
(170, 'Colombia'),
(174, 'Comoras'),
(175, 'Mayotte'),
(178, 'Congo'),
(180, 'República Democrática del Congo'),
(184, 'Islas Cook'),
(188, 'Costa Rica'),
(191, 'Croacia'),
(192, 'Cuba'),
(196, 'Chipre'),
(203, 'República Checa'),
(204, 'Benín'),
(208, 'Dinamarca'),
(212, 'Dominica'),
(214, 'República Dominicana'),
(218, 'Ecuador'),
(222, 'El Salvador'),
(226, 'Guinea Ecuatorial'),
(231, 'Etiopía'),
(232, 'Eritrea'),
(233, 'Estonia'),
(234, 'Islas Feroe'),
(238, 'Islas Malvinas'),
(239, 'Islas Georgias del Sur y Sandwich del Sur'),
(242, 'Fiyi'),
(246, 'Finlandia'),
(248, 'Islas Gland'),
(250, 'Francia'),
(254, 'Guayana Francesa'),
(258, 'Polinesia Francesa'),
(260, 'Territorios Australes Franceses'),
(262, 'Yibuti'),
(266, 'Gabón'),
(268, 'Georgia'),
(270, 'Gambia'),
(275, 'Palestina'),
(276, 'Alemania'),
(288, 'Ghana'),
(292, 'Gibraltar'),
(296, 'Kiribati'),
(300, 'Grecia'),
(304, 'Groenlandia'),
(308, 'Granada'),
(312, 'Guadalupe'),
(316, 'Guam'),
(320, 'Guatemala'),
(324, 'Guinea'),
(328, 'Guyana'),
(332, 'Haití'),
(334, 'Islas Heard y McDonald'),
(336, 'Ciudad del Vaticano'),
(340, 'Honduras'),
(344, 'Hong Kong'),
(348, 'Hungría'),
(352, 'Islandia'),
(356, 'India'),
(360, 'Indonesia'),
(364, 'Irán'),
(368, 'Iraq'),
(372, 'Irlanda'),
(376, 'Israel'),
(380, 'Italia'),
(384, 'Costa de Marfil'),
(388, 'Jamaica'),
(392, 'Japón'),
(398, 'Kazajstán'),
(400, 'Jordania'),
(404, 'Kenia'),
(408, 'Corea del Norte'),
(410, 'Corea del Sur'),
(414, 'Kuwait'),
(417, 'Kirguistán'),
(418, 'Laos'),
(422, 'Líbano'),
(426, 'Lesotho'),
(428, 'Letonia'),
(430, 'Liberia'),
(434, 'Libia'),
(438, 'Liechtenstein'),
(440, 'Lituania'),
(442, 'Luxemburgo'),
(446, 'Macao'),
(450, 'Madagascar'),
(454, 'Malaui'),
(458, 'Malasia'),
(462, 'Maldivas'),
(466, 'Malí'),
(470, 'Malta'),
(474, 'Martinica'),
(478, 'Mauritania'),
(480, 'Mauricio'),
(484, 'México'),
(492, 'Mónaco'),
(496, 'Mongolia'),
(498, 'Moldavia'),
(499, 'Montenegro'),
(500, 'Montserrat'),
(504, 'Marruecos'),
(508, 'Mozambique'),
(512, 'Omán'),
(516, 'Namibia'),
(520, 'Nauru'),
(524, 'Nepal'),
(528, 'Países Bajos'),
(530, 'Antillas Holandesas'),
(533, 'Aruba'),
(540, 'Nueva Caledonia'),
(548, 'Vanuatu'),
(554, 'Nueva Zelanda'),
(558, 'Nicaragua'),
(562, 'Níger'),
(566, 'Nigeria'),
(570, 'Niue'),
(574, 'Isla Norfolk'),
(578, 'Noruega'),
(580, 'Islas Marianas del Norte'),
(581, 'Islas Ultramarinas de Estados Unidos'),
(583, 'Micronesia'),
(584, 'Islas Marshall'),
(585, 'Palaos'),
(586, 'Pakistán'),
(591, 'Panamá'),
(598, 'Papúa Nueva Guinea'),
(600, 'Paraguay'),
(604, 'Perú'),
(608, 'Filipinas'),
(612, 'Islas Pitcairn'),
(616, 'Polonia'),
(620, 'Portugal'),
(624, 'Guinea-Bissau'),
(626, 'Timor Oriental'),
(630, 'Puerto Rico'),
(634, 'Qatar'),
(638, 'Reunión'),
(642, 'Rumania'),
(643, 'Rusia'),
(646, 'Ruanda'),
(654, 'Santa Helena'),
(659, 'San Cristóbal y Nieves'),
(660, 'Anguila'),
(662, 'Santa Lucía'),
(666, 'San Pedro y Miquelón'),
(670, 'San Vicente y las Granadinas'),
(674, 'San Marino'),
(678, 'Santo Tomé y Príncipe'),
(682, 'Arabia Saudí'),
(686, 'Senegal'),
(688, 'Serbia'),
(690, 'Seychelles'),
(694, 'Sierra Leona'),
(702, 'Singapur'),
(703, 'Eslovaquia'),
(704, 'Vietnam'),
(705, 'Eslovenia'),
(706, 'Somalia'),
(710, 'Sudáfrica'),
(716, 'Zimbabue'),
(724, 'España'),
(732, 'Sahara Occidental'),
(736, 'Sudán'),
(740, 'Surinam'),
(744, 'Svalbard y Jan Mayen'),
(748, 'Suazilandia'),
(752, 'Suecia'),
(756, 'Suiza'),
(760, 'Siria'),
(762, 'Tayikistán'),
(764, 'Tailandia'),
(768, 'Togo'),
(772, 'Tokelau'),
(776, 'Tonga'),
(780, 'Trinidad y Tobago'),
(784, 'Emiratos Árabes Unidos'),
(788, 'Túnez'),
(792, 'Turquía'),
(795, 'Turkmenistán'),
(796, 'Islas Turcas y Caicos'),
(798, 'Tuvalu'),
(800, 'Uganda'),
(804, 'Ucrania'),
(807, 'Macedonia'),
(818, 'Egipto'),
(826, 'Reino Unido'),
(834, 'Tanzania'),
(840, 'Estados Unidos'),
(850, 'Islas Vírgenes de los Estados Unidos'),
(854, 'Burkina Faso'),
(858, 'Uruguay'),
(860, 'Uzbekistán'),
(862, 'Venezuela'),
(876, 'Wallis y Futuna'),
(882, 'Samoa'),
(887, 'Yemen'),
(894, 'Zambia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincias`
--

CREATE TABLE IF NOT EXISTS `provincias` (
  `id_provincia` int(4) NOT NULL AUTO_INCREMENT,
  `provincia` varchar(64) NOT NULL,
  `id_pais` int(11) NOT NULL,
  PRIMARY KEY (`id_provincia`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Volcado de datos para la tabla `provincias`
--

INSERT INTO `provincias` (`id_provincia`, `provincia`, `id_pais`) VALUES
(1, 'Buenos Aires y Cap.', 32),
(2, 'Catamarca', 32),
(3, 'Chaco', 32),
(4, 'Chubut', 32),
(5, 'Cordoba', 32),
(6, 'Corrientes', 32),
(7, 'Entre Rios', 32),
(8, 'Formosa', 32),
(9, 'Jujuy', 32),
(10, 'La Pampa', 32),
(11, 'La Rioja', 32),
(12, 'Mendoza', 32),
(13, 'Misiones', 32),
(14, 'Neuquen', 32),
(15, 'Rio Negro', 32),
(16, 'Salta', 32),
(17, 'San Juan', 32),
(18, 'San Luis', 32),
(19, 'Santa Cruz', 32),
(20, 'Santa Fe', 32),
(21, 'Santiago Del Estero', 32),
(22, 'Tierra Del Fuego', 32),
(23, 'Tucuman', 32);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE IF NOT EXISTS `reservas` (
  `id_reserva` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `entrada` date NOT NULL,
  `salida` date NOT NULL,
  `adultos` int(11) NOT NULL,
  `menores` int(11) NOT NULL,
  `total` float NOT NULL,
  `id_nota` int(11) NOT NULL,
  `id_estado_reserva` int(11) NOT NULL,
  `fecha_alta` datetime NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_reserva`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=12 ;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id_reserva`, `id_huesped`, `entrada`, `salida`, `adultos`, `menores`, `total`, `id_nota`, `id_estado_reserva`, `fecha_alta`, `delete`) VALUES
(1, 1, '2014-11-05', '2014-11-06', 1, 0, 700, 1, 2, '2014-11-04 11:13:00', 1),
(2, 1, '2014-11-05', '2014-11-07', 1, 0, 1400, 2, 2, '2014-11-04 11:39:45', 1),
(3, 1, '2014-11-05', '2014-11-08', 1, 0, 1400, 3, 2, '2014-11-04 11:51:44', 1),
(4, 1, '2014-11-20', '2014-11-21', 2, 3, 2165, 4, 1, '2014-11-18 15:42:16', 0),
(5, 2, '2014-11-19', '2014-11-20', 2, 3, 2165, 0, 1, '2014-11-19 09:43:10', 0),
(6, 2, '2014-11-19', '2014-11-20', 2, 3, 2165, 0, 1, '2014-11-19 09:46:55', 0),
(7, 2, '2014-11-20', '2014-11-21', 2, 0, 12240, 0, 1, '2014-11-20 10:35:56', 0),
(8, 2, '2014-11-20', '2014-11-21', 2, 0, 12240, 0, 1, '2014-11-20 10:36:39', 0),
(9, 2, '2014-11-20', '2014-11-21', 2, 0, 3695, 0, 1, '2014-11-20 15:22:33', 0),
(10, 3, '2014-11-20', '2014-11-21', 2, 0, 4330, 0, 1, '2014-11-20 15:25:26', 0),
(11, 2, '2014-11-20', '2014-11-21', 5, 0, 9695, 0, 1, '2014-11-20 15:30:01', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reserva_habitacion`
--

CREATE TABLE IF NOT EXISTS `reserva_habitacion` (
  `id_reserva_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_reserva` int(11) NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_reserva_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Volcado de datos para la tabla `reserva_habitacion`
--

INSERT INTO `reserva_habitacion` (`id_reserva_habitacion`, `id_reserva`, `id_habitacion`, `cantidad`, `prioridad`) VALUES
(1, 6, 1, 2, 0),
(2, 6, 5, 1, 0),
(3, 7, 14, 16, 0),
(4, 8, 14, 16, 0),
(5, 9, 1, 2, 0),
(6, 9, 5, 3, 0),
(7, 10, 1, 4, 0),
(8, 10, 5, 2, 0),
(9, 11, 1, 5, 0),
(10, 11, 5, 4, 0),
(11, 11, 16, 3, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicios`
--

CREATE TABLE IF NOT EXISTS `servicios` (
  `id_servicio` int(11) NOT NULL AUTO_INCREMENT,
  `servicio` varchar(64) NOT NULL,
  `icono` varchar(64) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_servicio`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Volcado de datos para la tabla `servicios`
--

INSERT INTO `servicios` (`id_servicio`, `servicio`, `icono`, `delete`) VALUES
(1, 'Bar confiteria', '3aab9-bar-confiteria.png', 0),
(2, 'Desayuno Buffet Americano', '1383d-desayuno.png', 0),
(4, 'Emergencias', '3babf-emergencias.png', 0),
(5, 'Estacionamiento cerrado sin cargo', '0bf33-estacionamiento.png', 0),
(6, 'Piscina jardines', 'dc556-piscina-jardines.png', 0),
(7, 'Room service', '2f579-room-service.png', 0),
(8, 'Tele', '', 1),
(9, 'Sala reunión', '1d28a-sala-reunion.png', 0),
(10, 'Tintoreria', 'b47ad-tintoreria.png', 0),
(11, 'Transfer desde y hacia  el aeropuerto', '5e676-transfer.png', 0),
(12, 'Turismo aventura', 'a0d6e-turismo-aventura.png', 0),
(13, 'WIFI sin cargo', '4bcc0-wifi.png', 0),
(14, 'Late check-out 06 pm (sujeto a disponibilidad)', '', 0),
(15, 'Early check-in 08 am', '', 0),
(16, 'Cuna Adicional Sin Cargo', '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifas`
--

CREATE TABLE IF NOT EXISTS `tarifas` (
  `id_tarifa` int(11) NOT NULL AUTO_INCREMENT,
  `tarifa` varchar(64) CHARACTER SET latin1 NOT NULL,
  `precio` float NOT NULL,
  `id_moneda` int(11) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tarifa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=19 ;

--
-- Volcado de datos para la tabla `tarifas`
--

INSERT INTO `tarifas` (`id_tarifa`, `tarifa`, `precio`, `id_moneda`, `delete`) VALUES
(1, 'single carollo', 700, 1, 0),
(2, 'doble carollo', 765, 1, 0),
(3, 'triple carollo', 1045, 1, 0),
(4, 'single princess', 765, 1, 0),
(5, 'doble princess', 870, 1, 0),
(6, 'triple princess', 1125, 1, 0),
(7, 'cuadruple princess', 1275, 1, 0),
(8, 'suite princess', 1590, 1, 0),
(9, 'single san luis', 700, 1, 0),
(10, 'doble san luis', 765, 1, 0),
(11, 'triple san luis', 1045, 1, 0),
(12, 'cuadruple san luis', 1190, 1, 0),
(13, 'suite san luis', 1345, 1, 0),
(14, 'single cristal', 665, 1, 0),
(15, 'doble cristal', 875, 1, 0),
(16, 'triple cristal', 1075, 1, 0),
(17, 'cuadruple cristal', 1275, 1, 0),
(18, 'quintuple crsital', 1500, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifas_temporales`
--

CREATE TABLE IF NOT EXISTS `tarifas_temporales` (
  `id_tarifa_temporal` int(11) NOT NULL AUTO_INCREMENT,
  `tarifa_temporal` varchar(128) NOT NULL,
  `entrada` date NOT NULL,
  `salida` date NOT NULL,
  `id_tipo_tarifa` tinyint(4) NOT NULL,
  `valor` float NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tarifa_temporal`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `tarifas_temporales`
--

INSERT INTO `tarifas_temporales` (`id_tarifa_temporal`, `tarifa_temporal`, `entrada`, `salida`, `id_tipo_tarifa`, `valor`, `delete`) VALUES
(1, 'Test', '2014-11-20', '2014-11-27', 1, 10, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifa_habitacion`
--

CREATE TABLE IF NOT EXISTS `tarifa_habitacion` (
  `id_tarifa_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_tarifa_temporal` int(11) NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_tarifa_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `tarifa_habitacion`
--

INSERT INTO `tarifa_habitacion` (`id_tarifa_habitacion`, `id_tarifa_temporal`, `id_habitacion`, `prioridad`) VALUES
(1, 1, 3, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarjetas`
--

CREATE TABLE IF NOT EXISTS `tarjetas` (
  `id_tarjeta` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `tarjeta` int(11) NOT NULL,
  `pin` int(11) NOT NULL,
  `vencimiento` date NOT NULL,
  `id_tipo_tarjeta` int(11) NOT NULL,
  PRIMARY KEY (`id_tarjeta`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `tarjetas`
--

INSERT INTO `tarjetas` (`id_tarjeta`, `id_huesped`, `tarjeta`, `pin`, `vencimiento`, `id_tipo_tarjeta`) VALUES
(4, 1, 2147483647, 222, '2014-11-19', 1),
(5, 2, 1234, 1231, '2014-11-13', 1),
(6, 2, 2147483647, 1212, '2014-11-05', 1),
(7, 2, 2147483647, 1212, '2014-11-05', 1),
(8, 2, 2147483647, 1515, '2014-11-20', 2),
(9, 3, 2147483647, 1321, '2014-11-06', 1),
(10, 2, 2147483647, 123, '2014-11-07', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefonos_hotel`
--

CREATE TABLE IF NOT EXISTS `telefonos_hotel` (
  `id_telefono` int(11) NOT NULL AUTO_INCREMENT,
  `id_hotel` int(11) NOT NULL,
  `telefono` varchar(64) CHARACTER SET latin1 NOT NULL,
  `id_tipo` int(11) NOT NULL,
  PRIMARY KEY (`id_telefono`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `telefonos_hotel`
--

INSERT INTO `telefonos_hotel` (`id_telefono`, `id_hotel`, `telefono`, `id_tipo`) VALUES
(1, 1, '+54 261 4235666', 0),
(2, 3, '+54 261 4235669', 0),
(3, 2, '+54 2664 425049', 0),
(4, 5, '+54 351 4245000', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefonos_huesped`
--

CREATE TABLE IF NOT EXISTS `telefonos_huesped` (
  `id_telefono` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `telefono` varchar(64) CHARACTER SET latin1 NOT NULL,
  `id_tipo` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_telefono`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `telefonos_huesped`
--

INSERT INTO `telefonos_huesped` (`id_telefono`, `id_huesped`, `telefono`, `id_tipo`) VALUES
(1, 1, '4325435664', 1),
(2, 2, '2615132824', 1),
(3, 3, '2165165', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefonos_usuario`
--

CREATE TABLE IF NOT EXISTS `telefonos_usuario` (
  `id_telefono` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `telefono` varchar(64) CHARACTER SET latin1 NOT NULL,
  `id_tipo` int(11) NOT NULL,
  PRIMARY KEY (`id_telefono`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `terminos`
--

CREATE TABLE IF NOT EXISTS `terminos` (
  `id_termino` int(11) NOT NULL AUTO_INCREMENT,
  `termino` text NOT NULL,
  PRIMARY KEY (`id_termino`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `terminos`
--

INSERT INTO `terminos` (`id_termino`, `termino`) VALUES
(1, '<div style="color: rgb(51, 51, 51); font-family: ''Lucida Grande'', Verdana, Arial, Helvetica, sans-serif; font-size: 11px;">\n	<span style="font-size:14px;"><strong style="font-family: arial, sans-serif; font-size: 13.3333339691162px;"><u>Condiciones del servicio</u></strong></span></div>\n<div style="color: rgb(51, 51, 51); font-family: ''Lucida Grande'', Verdana, Arial, Helvetica, sans-serif; font-size: 11px;">\n	<span style="font-size:14px;"><strong style="font-size: 13.3333339691162px; font-family: arial, sans-serif;">Anulaci&oacute;n &nbsp;gratuita 48 hs antes del ingreso</strong></span><br style="font-family: arial, sans-serif; font-size: 13.3333339691162px;" />\n	<span style="font-size:14px;"><font face="arial, sans-serif">La pol&iacute;tica de&nbsp;anulaci&oacute;n&nbsp; y sanci&oacute;n aplicada a esta reserva no tendr&aacute; excepci&oacute;n alguna. Los&nbsp;datos de la tarjeta de cr&eacute;dito asignados deber&aacute;n ser v&aacute;lidos para confirmar su reserva, caso contrario la misma podr&aacute; ser dada de baja sin previo aviso. Los pedidos de anulaci&oacute;n, modificaci&oacute;n de reserva , asi tambi&eacute;n como las peticiones especiales deber&aacute;n ser realizados v&iacute;a e-mail, para validar la misma deber&aacute; recibir respuesta afirmativa de nuestra central de reservas. Hoteles Gold &nbsp;considera infantes a los menores de 1 a&ntilde;os de edad y provee solo bajo solicitud el servicio de cuna sin cargo. Los menores de 1 a 3 a&ntilde;os no tienen cargo compartiendo cama con sus padres. Se aceptan como forma de pago efectivo</font><span style="font-family: arial, sans-serif;">&nbsp;y</span><font face="arial, sans-serif">&nbsp;tarjetas de&nbsp;cr&eacute;dito&nbsp;(visa, mastercard y&nbsp;american express, master, diners, cabal). El horario de ingreso es a las 08.00 hs y el horario de salida 18:00 hs (sujeto a disponibilidad), pasado este horario se cargar&aacute; una noche en su cuenta. En caso de conflicto entre pol&iacute;ticas se aplicar&aacute; la m&aacute;s restrictiva.&nbsp;</font></span></div>\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE IF NOT EXISTS `tipos` (
  `id_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(64) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`id_tipo`, `tipo`) VALUES
(1, 'Personal'),
(2, 'Trabajo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_articulo`
--

CREATE TABLE IF NOT EXISTS `tipos_articulo` (
  `id_tipo_articulo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_articulo` varchar(32) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_articulo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `tipos_articulo`
--

INSERT INTO `tipos_articulo` (`id_tipo_articulo`, `tipo_articulo`, `delete`) VALUES
(1, 'Artículo', 0),
(2, 'Banner: Hoteles habitaciones', 0),
(3, 'Banner: Hoteles galería', 0),
(4, 'Banner: Como llegar', 0),
(5, 'Banner: Categoría artículo', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_correo`
--

CREATE TABLE IF NOT EXISTS `tipos_correo` (
  `id_tipo_correo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_correo` varchar(64) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_correo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `tipos_correo`
--

INSERT INTO `tipos_correo` (`id_tipo_correo`, `tipo_correo`, `delete`) VALUES
(1, 'Administración', 0),
(2, 'Huesped', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_habitacion`
--

CREATE TABLE IF NOT EXISTS `tipos_habitacion` (
  `id_tipo_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_habitacion` varchar(64) CHARACTER SET latin1 NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=9 ;

--
-- Volcado de datos para la tabla `tipos_habitacion`
--

INSERT INTO `tipos_habitacion` (`id_tipo_habitacion`, `tipo_habitacion`, `delete`) VALUES
(1, 'Single', 0),
(2, 'Doble', 0),
(3, 'Triple', 0),
(4, 'Test', 1),
(5, 'test', 1),
(6, 'Cuádruple', 0),
(7, 'Quíntuple', 0),
(8, 'Suite', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_huesped`
--

CREATE TABLE IF NOT EXISTS `tipos_huesped` (
  `id_tipo_huesped` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_huesped` varchar(64) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_huesped`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `tipos_huesped`
--

INSERT INTO `tipos_huesped` (`id_tipo_huesped`, `tipo_huesped`, `delete`) VALUES
(1, '<span class="label label-success">Nuevo</span>', 0),
(2, '<span class="label label-default">Normal</span>', 0),
(3, '<span class="label label-danger">No aceptados</span>', 0),
(4, '<span class="label label-info">Especial</span>', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_mensaje`
--

CREATE TABLE IF NOT EXISTS `tipos_mensaje` (
  `id_tipo_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_mensaje` varchar(64) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_tipo_mensaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `tipos_mensaje`
--

INSERT INTO `tipos_mensaje` (`id_tipo_mensaje`, `tipo_mensaje`) VALUES
(1, 'Web'),
(2, 'Envió de habitación ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_tarifa`
--

CREATE TABLE IF NOT EXISTS `tipos_tarifa` (
  `id_tipo_tarifa` tinyint(4) NOT NULL AUTO_INCREMENT,
  `tipo_tarifa` varchar(64) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_tarifa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `tipos_tarifa`
--

INSERT INTO `tipos_tarifa` (`id_tipo_tarifa`, `tipo_tarifa`, `delete`) VALUES
(1, '<span class="label label-success">% aumento</label>', 0),
(2, '<span class="label label-warning">% descuento</label>', 0),
(3, '<span class="label label-default">valor</label>', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_tarjeta`
--

CREATE TABLE IF NOT EXISTS `tipos_tarjeta` (
  `id_tipo_tarjeta` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_tarjeta` varchar(64) CHARACTER SET latin1 NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_tarjeta`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `tipos_tarjeta`
--

INSERT INTO `tipos_tarjeta` (`id_tipo_tarjeta`, `tipo_tarjeta`, `delete`) VALUES
(1, 'Visa', 0),
(2, 'Mastercard', 0),
(3, 'American Express', 0),
(4, 'Maestro', 0),
(5, 'Cabal', 0),
(6, 'Diners', 0),
(7, 'Nativa', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(64) CHARACTER SET latin1 NOT NULL,
  `pass` varchar(128) CHARACTER SET latin1 NOT NULL,
  `pass2` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `id_acceso` int(11) NOT NULL,
  `id_estado_usuario` int(11) NOT NULL DEFAULT '1',
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `pass`, `pass2`, `id_acceso`, `id_estado_usuario`, `delete`) VALUES
(1, 'admin', '405e28906322882c5be9b4b27f4c35fd', '1978', 1, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vuelos`
--

CREATE TABLE IF NOT EXISTS `vuelos` (
  `id_vuelo` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `id_aerolinea` int(11) NOT NULL,
  `id_reserva` int(11) NOT NULL,
  `nro_vuelo` int(11) NOT NULL,
  `horario_llegada` time NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_vuelo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `vuelos`
--

INSERT INTO `vuelos` (`id_vuelo`, `id_huesped`, `id_aerolinea`, `id_reserva`, `nro_vuelo`, `horario_llegada`, `delete`) VALUES
(1, 1, 2, 1, 930, '09:05:00', 1),
(2, 1, 2, 2, 930, '10:20:00', 1),
(3, 1, 2, 3, 930, '10:15:00', 1),
(4, 1, 1, 4, 2324, '08:40:00', 0),
(5, 2, 1, 5, 2147483647, '16:00:00', 0),
(6, 2, 1, 6, 2147483647, '16:00:00', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
