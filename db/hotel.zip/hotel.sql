-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-09-2014 a las 17:12:01
-- Versión del servidor: 5.6.16
-- Versión de PHP: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `hotel`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accesos`
--

CREATE TABLE IF NOT EXISTS `accesos` (
  `id_acceso` int(11) NOT NULL AUTO_INCREMENT,
  `acceso` varchar(64) CHARACTER SET latin1 NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_acceso`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `accesos`
--

INSERT INTO `accesos` (`id_acceso`, `acceso`, `delete`) VALUES
(1, 'Normal', 0),
(2, 'a ver', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accion`
--

CREATE TABLE IF NOT EXISTS `accion` (
  `id_accion` int(11) NOT NULL AUTO_INCREMENT,
  `accion` varchar(64) NOT NULL,
  PRIMARY KEY (`id_accion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `accion`
--

INSERT INTO `accion` (`id_accion`, `accion`) VALUES
(1, '<span class="label label-success">nuevo</span>'),
(2, '<span class="label label-primary">modificar</span>'),
(3, '<span class="label label-danger">borrar</span>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aerolineas`
--

CREATE TABLE IF NOT EXISTS `aerolineas` (
  `id_aerolinea` int(11) NOT NULL AUTO_INCREMENT,
  `aerolinea` varchar(64) NOT NULL,
  `delete` int(11) NOT NULL,
  PRIMARY KEY (`id_aerolinea`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `aerolineas`
--

INSERT INTO `aerolineas` (`id_aerolinea`, `aerolinea`, `delete`) VALUES
(1, 'Argentinas', 0),
(2, 'LAN Chile', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulos`
--

CREATE TABLE IF NOT EXISTS `articulos` (
  `id_articulo` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) CHARACTER SET latin1 NOT NULL,
  `articulo` text CHARACTER SET latin1 NOT NULL,
  `fecha_publicacion` date NOT NULL,
  `fecha_despublicacion` date NOT NULL,
  `archivo_url` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `pagina_principal` tinyint(4) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `id_autor` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `id_estado_articulo` int(11) NOT NULL,
  `id_idioma` int(11) NOT NULL,
  `id_tarifa_temporal` int(11) NOT NULL,
  `delete` tinytext COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id_articulo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=26 ;

--
-- Volcado de datos para la tabla `articulos`
--

INSERT INTO `articulos` (`id_articulo`, `titulo`, `articulo`, `fecha_publicacion`, `fecha_despublicacion`, `archivo_url`, `pagina_principal`, `id_hotel`, `id_autor`, `id_categoria`, `id_estado_articulo`, `id_idioma`, `id_tarifa_temporal`, `delete`) VALUES
(18, 'Tenemos una filosofía: tú', '<p style="margin: 1.4em 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; color: rgb(102, 102, 102); line-height: 18px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	Toda esta dedicaci&oacute;n ha sido reconocida por el sector tur&iacute;stico, por lo que hemos recibido, a lo largo de nuestra trayectoria, varios premios y menciones por nuestra labor. Aunque, sin duda, la mayor recompensa es la cara de satisfacci&oacute;n con la que nuestros clientes nos agradecen su estancia.</p>\r\n<p style="margin: 1.4em 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; color: rgb(102, 102, 102); line-height: 18px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	Nuestro grupo hotelero est&aacute; al frente de diferentes y singulares complejos tur&iacute;sticos como el Hotel Ciutadella, Villas Sagitario, Apartamentos Vista Playa, el Hotel Princesa Playa Calan Bosch o el mismo Hotel Sagitario Playa. As&iacute;, podemos ofrecerte exactamente las vacaciones que est&aacute;s deseando.</p>\r\n', '2014-08-14', '0000-00-00', '962ff-03.jpg', 0, 2, 2, 5, 1, 0, 0, ''),
(19, 'Diego', '<p>\r\n	d</p>\r\n', '2014-08-14', '0000-00-00', '', 0, 2, 0, 7, 1, 0, 0, '1'),
(20, 'En primera línea de tus sueños', '<p style="margin: 1.4em 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; color: rgb(102, 102, 102); line-height: 18px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	Nuestras cuatro estrellas, hablan de nuestro compromiso por la calidad. Nuestros visitantes lo hacen sobre la comodidad, las atenciones recibidas y, con una gran sonrisa, de unas vacaciones inolvidables.</p>\r\n<p style="margin: 1.4em 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; color: rgb(102, 102, 102); line-height: 18px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	Renovado por completo en 2010, nuestras instalaciones destacan por su nueva zona de Spa y wellness: con piscina climatizada, jacuzzi, sauna, ba&ntilde;o turco, gimnasio-fitness, cabinas para masajes con tratamientos de belleza y salud corporal.</p>\r\n', '2014-08-15', '0000-00-00', '', 1, 2, 1, 5, 1, 0, 0, ''),
(21, 'Disfrute nuestro magnífico Spa', '<p style="margin: 1.4em 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; color: rgb(102, 102, 102); line-height: 18px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	Un completo Circuito de Hidroterapia SPA donde se pueden tratar todo tipo de dolencias mediante la aplicaci&oacute;n del agua, a trav&eacute;s de sus contrastes de m&aacute;s o menos fuerza, calor e intensidad.</p>\r\n<p style="margin: 1.4em 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; color: rgb(102, 102, 102); line-height: 18px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	En nuestras salas ofrecemos tratamientos de salud, belleza y relajamiento. Todo lo necesario para la salud y el cuidado de nuestro cuerpo. Para dar a nuestros sentidos el m&aacute;ximo placer.</p>\r\n<p style="margin: 1.4em 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; color: rgb(102, 102, 102); line-height: 18px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	Nuestro centro garantiza una experiencia integral de relajamiento, salud y belleza. Nuestro compromiso es que usted quede completamente satisfecho.</p>\r\n<p style="margin: 1.4em 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; color: rgb(102, 102, 102); line-height: 18px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	Un concepto comprometido con el cuidado del medio ambiente bajo el cual se han dise&ntilde;ado todas sus instalaciones</p>\r\n', '2014-08-20', '0000-00-00', '34711-02.jpg', 1, 2, 1, 5, 1, 0, 1, ''),
(22, 'a', '<p>\r\n	a</p>\r\n', '2014-08-14', '0000-00-00', '', 0, 2, 0, 7, 2, 0, 0, '1'),
(23, 'a', '<p>\r\n	a</p>\r\n', '2014-08-14', '0000-00-00', '', 0, 2, 0, 7, 0, 0, 0, '1'),
(24, '123', '<p>\r\n	123</p>\r\n', '2014-08-15', '0000-00-00', '', 0, 2, 0, 7, 0, 0, 0, '1'),
(25, 'Perro loco', '<p>\r\n	123</p>\r\n', '2014-08-21', '0000-00-00', '', 0, 2, 0, 9, 1, 0, 0, '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ayudas`
--

CREATE TABLE IF NOT EXISTS `ayudas` (
  `id_ayuda` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(128) NOT NULL,
  `ayuda` text NOT NULL,
  `id_idioma` int(11) NOT NULL,
  `sector` varchar(32) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_ayuda`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `ayudas`
--

INSERT INTO `ayudas` (`id_ayuda`, `titulo`, `ayuda`, `id_idioma`, `sector`, `delete`) VALUES
(1, 'Reserva online', 'Por favor, rellena el formulario con tus datos de contacto. Introduce un email válido ya que lo vamos a utilizar para enviarte el bono de la reserva.', 0, 'datos', 0),
(2, 'Reserva online', '<p>\r\n	&nbsp;&nbsp;&nbsp;Realizar el pago</p>\r\n', 0, 'pagos', 0),
(3, 'Book now', '<p>\r\n	Please fill in the form with your contact details. Enter a valid email address as we will use it to send you the booking voucher.</p>\r\n', 2, 'datos', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(64) CHARACTER SET latin1 NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=12 ;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `categoria`, `delete`) VALUES
(1, 'Ofertas', 0),
(2, 'Paquetes', 0),
(3, 'Promociones', 0),
(4, 'Eventos', 0),
(5, 'Actividades', 0),
(6, 'Servicios', 0),
(7, 'Comidas', 0),
(8, 'Tragos', 0),
(9, 'Noticias', 0),
(10, 'Turismo', 0),
(11, '123', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `id_config` int(11) NOT NULL AUTO_INCREMENT,
  `id_hotel` int(11) NOT NULL,
  `css` varchar(128) CHARACTER SET latin1 NOT NULL,
  `mostrar_tarifa` tinyint(4) NOT NULL,
  `max_adultos` int(11) NOT NULL,
  `max_menores` int(11) NOT NULL,
  `limite_menores` int(11) NOT NULL,
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `config`
--

INSERT INTO `config` (`id_config`, `id_hotel`, `css`, `mostrar_tarifa`, `max_adultos`, `max_menores`, `limite_menores`) VALUES
(1, 2, 'CSS', 10, 5, 5, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_email_habitacion`
--

CREATE TABLE IF NOT EXISTS `config_email_habitacion` (
  `id_config_email_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_correo` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `correo` text NOT NULL,
  `mensaje` tinyint(4) NOT NULL,
  `hotel` tinyint(4) NOT NULL,
  `habitacion` tinyint(4) NOT NULL,
  `nombre` tinyint(4) NOT NULL,
  `apellido` tinyint(4) NOT NULL,
  `email` tinyint(4) NOT NULL,
  `telefono` tinyint(4) NOT NULL,
  `fecha` tinyint(4) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_config_email_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `config_email_habitacion`
--

INSERT INTO `config_email_habitacion` (`id_config_email_habitacion`, `id_tipo_correo`, `id_hotel`, `correo`, `mensaje`, `hotel`, `habitacion`, `nombre`, `apellido`, `email`, `telefono`, `fecha`, `delete`) VALUES
(1, 1, 9, '', 0, 1, 0, 1, 1, 1, 1, 1, 1),
(2, 2, 9, '', 0, 1, 0, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_email_mensaje`
--

CREATE TABLE IF NOT EXISTS `config_email_mensaje` (
  `id_config_email_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_correo` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `correo` text NOT NULL,
  `mensaje` tinyint(4) NOT NULL,
  `hotel` tinyint(4) NOT NULL,
  `nombre` tinyint(4) NOT NULL,
  `apellido` tinyint(4) NOT NULL,
  `email` tinyint(4) NOT NULL,
  `telefono` tinyint(4) NOT NULL,
  `fecha` tinyint(4) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_config_email_mensaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `config_email_mensaje`
--

INSERT INTO `config_email_mensaje` (`id_config_email_mensaje`, `id_tipo_correo`, `id_hotel`, `correo`, `mensaje`, `hotel`, `nombre`, `apellido`, `email`, `telefono`, `fecha`, `delete`) VALUES
(1, 1, 9, '', 0, 1, 1, 1, 1, 1, 1, 1),
(2, 2, 9, '', 0, 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_email_reserva`
--

CREATE TABLE IF NOT EXISTS `config_email_reserva` (
  `id_config_email_reserva` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_correo` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `correo` text NOT NULL,
  `hotel` tinyint(4) NOT NULL,
  `entrada` tinyint(4) NOT NULL,
  `salida` tinyint(4) NOT NULL,
  `adultos` tinyint(4) NOT NULL,
  `menores` tinyint(4) NOT NULL,
  `cantidad` tinyint(4) NOT NULL,
  `habitacion` tinyint(4) NOT NULL,
  `nombre` tinyint(4) NOT NULL,
  `apellido` tinyint(4) NOT NULL,
  `email` tinyint(4) NOT NULL,
  `telefono` tinyint(4) NOT NULL,
  `tipo_tarjeta` tinyint(4) NOT NULL,
  `tarjeta` tinyint(4) NOT NULL,
  `pin` tinyint(4) NOT NULL,
  `vencimiento` tinyint(4) NOT NULL,
  `nro_de_vuelo` tinyint(4) NOT NULL,
  `horario_llegada` tinyint(4) NOT NULL,
  `aerolinea` tinyint(4) NOT NULL,
  `id_nota` tinyint(4) NOT NULL,
  `id_reserva` tinyint(4) NOT NULL,
  `precio` tinyint(4) NOT NULL,
  `fecha` tinyint(4) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_config_email_reserva`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `config_email_reserva`
--

INSERT INTO `config_email_reserva` (`id_config_email_reserva`, `id_tipo_correo`, `id_hotel`, `correo`, `hotel`, `entrada`, `salida`, `adultos`, `menores`, `cantidad`, `habitacion`, `nombre`, `apellido`, `email`, `telefono`, `tipo_tarjeta`, `tarjeta`, `pin`, `vencimiento`, `nro_de_vuelo`, `horario_llegada`, `aerolinea`, `id_nota`, `id_reserva`, `precio`, `fecha`, `delete`) VALUES
(1, 1, 9, '', 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(2, 2, 9, '', 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamentos`
--

CREATE TABLE IF NOT EXISTS `departamentos` (
  `id_departamento` int(5) NOT NULL AUTO_INCREMENT,
  `id_provincia` int(2) NOT NULL,
  `departamento` varchar(128) NOT NULL,
  PRIMARY KEY (`id_departamento`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=575 ;

--
-- Volcado de datos para la tabla `departamentos`
--

INSERT INTO `departamentos` (`id_departamento`, `id_provincia`, `departamento`) VALUES
(1, 1, 'Azul'),
(2, 1, 'Puan'),
(3, 1, 'La Matanza'),
(4, 1, 'Tigre'),
(5, 1, '25 De Mayo'),
(6, 1, 'Trenque Lauquen'),
(7, 1, '9 De Julio'),
(8, 1, 'Lanus'),
(9, 1, 'La Plata'),
(10, 1, 'Monte'),
(11, 1, 'Pehuajo'),
(12, 1, 'San Isidro'),
(13, 1, 'Pergamino'),
(14, 1, 'Alberti'),
(15, 1, 'Chascomus'),
(16, 1, 'Esteban Echeverria'),
(17, 1, 'Mercedes'),
(18, 1, 'Bahia Blanca'),
(19, 1, 'Merlo'),
(20, 1, 'Junin'),
(21, 1, 'Guamini'),
(22, 1, 'Lujan'),
(23, 1, 'Leandro N.alem'),
(24, 1, 'Matanza'),
(25, 1, 'General Paz'),
(26, 1, 'San Vicente'),
(27, 1, 'Cañuelas'),
(28, 1, 'Almirante Brown'),
(29, 1, 'Cnl.de Marina  L.rosales'),
(30, 1, 'Baradero'),
(31, 1, 'Saavedra'),
(32, 1, 'Brandsen'),
(33, 1, 'General Sarmiento'),
(34, 1, 'Tapalque'),
(35, 1, 'Saladillo'),
(36, 1, 'Magdalena'),
(37, 1, 'Gonzales Chaves'),
(38, 1, 'General Pinto'),
(39, 1, 'Navarro'),
(40, 1, 'Daireaux'),
(41, 1, 'Lobos'),
(42, 1, 'Coronel Dorrego'),
(43, 1, 'Adolfo Alsina'),
(44, 1, 'Colon'),
(45, 1, 'General Arenales'),
(46, 1, 'Lincoln'),
(47, 1, 'Villarino'),
(48, 1, 'Vicente Lopez'),
(49, 1, 'Bartolome Mitre'),
(50, 1, 'Exaltacion De La Cruz'),
(51, 1, 'Salto'),
(52, 1, 'Bragado'),
(53, 1, 'Zarate'),
(54, 1, 'Avellaneda'),
(55, 1, 'Ayacucho'),
(56, 1, 'San Andres De Giles'),
(57, 1, 'Tandil'),
(58, 1, 'Rivadavia'),
(59, 1, 'Patagones'),
(60, 1, 'Grl.viamonte'),
(61, 1, 'Cnl.de Marina Leonardo Rosales'),
(62, 1, 'Balcarce'),
(63, 1, 'Tres Arroyos'),
(64, 1, 'General Villegas'),
(65, 1, 'Lomas De Zamora'),
(66, 1, 'Berisso'),
(67, 1, 'Juarez'),
(68, 1, 'Grl.pueyrredon'),
(69, 1, 'Coronel Suarez'),
(70, 1, 'Escobar'),
(71, 1, 'Carlos Casares'),
(72, 1, 'Chivilcoy'),
(73, 1, 'Berazategui'),
(74, 1, 'Quilmes'),
(75, 1, 'Torquinst'),
(76, 1, '3 De Febrero'),
(77, 1, 'Olavarria'),
(78, 1, 'Pellegrini'),
(79, 1, 'General Belgano'),
(80, 1, 'Florencio Varela'),
(81, 1, 'Salliquelo'),
(82, 1, 'Cnl.de Marina L.rosales'),
(83, 1, 'Mar Chiquita'),
(84, 1, 'General Pueyrredon'),
(85, 1, 'Campana'),
(86, 1, 'Grl.sarmiento'),
(87, 1, 'Rojas'),
(88, 1, 'Sarmiento'),
(89, 1, 'Carmen De Areco'),
(90, 1, 'Pila'),
(91, 1, 'Tres De Febrero'),
(92, 1, 'Moron'),
(93, 1, 'Castelli'),
(94, 1, 'Chacabuco'),
(95, 1, 'General Viamonte'),
(96, 1, 'Rauch'),
(97, 1, 'General Belgrano'),
(98, 1, 'Tornquist'),
(99, 1, 'Necochea'),
(100, 1, 'Marcos Paz'),
(101, 1, 'Carlos Tejedor'),
(102, 1, 'San Pedro'),
(103, 1, 'General Alvarado'),
(104, 1, 'San Nicolas'),
(105, 1, 'Hipolito Yrigoyen'),
(106, 1, 'Las Flores'),
(107, 1, 'Coronel Pringles'),
(108, 1, 'General San Martin'),
(109, 1, 'Benito Juarez'),
(110, 1, 'San Cayetano'),
(111, 1, 'Adolfo Gonzales Chaves'),
(112, 1, 'Dolores'),
(113, 1, 'San Antonio'),
(114, 1, 'Loberia'),
(115, 1, 'Ramallo'),
(116, 1, 'General Alvear'),
(117, 1, 'Ensenada'),
(118, 1, 'Tordillo'),
(119, 1, 'General Guido'),
(120, 1, 'General Las Heras'),
(121, 1, 'General Juan Madariaga'),
(122, 1, 'General La Madrid'),
(123, 1, 'General Lavalle'),
(124, 1, 'General Rodriguez'),
(125, 1, 'General Vllegas'),
(126, 1, 'Adolfo Gonzalez Chaves'),
(127, 1, 'Coronel De Marina L.rosales'),
(128, 1, 'Bolivar'),
(129, 1, 'San Fernando'),
(130, 1, 'Capitan Sarmiento'),
(131, 1, 'Roque Perez'),
(132, 1, 'Moreno'),
(133, 1, 'Laprida'),
(134, 1, 'Maipu'),
(135, 1, 'Echeverria'),
(136, 1, 'Pilar'),
(137, 1, 'Coronel De Marina L. Rosales'),
(138, 1, 'Suipacha'),
(139, 1, 'San Antonio De Areco'),
(140, 1, 'Barazategui'),
(141, 1, 'Alsina'),
(142, 1, 'Leandro N. Elem'),
(143, 1, 'Grl.san Martin'),
(144, 1, 'Coronel'),
(145, 2, 'Capayan'),
(146, 2, 'Andalgala'),
(147, 2, 'El Alto'),
(148, 2, 'Santa Rosa'),
(149, 2, 'Ancasti'),
(150, 2, 'Paclin'),
(151, 2, 'Santa Maria'),
(152, 2, 'Tinogasta'),
(153, 2, 'La Paz'),
(154, 2, 'Valle Viejo'),
(155, 2, 'Antofagasta De La Sierra'),
(156, 2, 'Belen'),
(157, 2, 'Capital'),
(158, 2, 'Fray Mamerto Esquiu'),
(159, 2, 'Poman'),
(160, 2, 'Ambato'),
(161, 3, 'Independencia'),
(162, 3, 'San Fernando'),
(163, 3, 'Primero De Mayo'),
(164, 3, 'Fray Justo Santa Maria De Oro'),
(165, 3, 'Sargento Cabral'),
(166, 3, 'General Guemes'),
(167, 3, 'Tapenaga'),
(168, 3, 'Chacabuco'),
(169, 3, 'Libertador Grl.san Martin'),
(170, 3, '25 De Mayo'),
(171, 3, '12 De Octubre'),
(172, 3, 'Comandante Fernandez'),
(173, 3, 'Quitilipi'),
(174, 3, 'Mayor Luis J.fontana'),
(175, 3, 'Libertad'),
(176, 3, 'Bermejo'),
(177, 3, 'Almirante Brown'),
(178, 3, 'Meyor Luis J.fontana'),
(179, 3, 'General Belgrano'),
(180, 3, 'Libertador Grl. San Martin'),
(181, 3, 'General Donovan'),
(182, 3, 'San Lorenzo'),
(183, 3, 'Lebertador Grl.san Martin'),
(184, 3, 'Maipu'),
(185, 3, 'O''higgins'),
(186, 3, '9 De Julio'),
(187, 3, 'Libertador San Martin'),
(188, 4, 'Rio Senguerr'),
(189, 4, 'Martires'),
(190, 4, 'Escalante'),
(191, 4, 'Gaiman'),
(192, 4, 'Sarmiento'),
(193, 4, 'Cushamen'),
(194, 4, 'Florentino Ameghino'),
(195, 4, 'Paso De Indios'),
(196, 4, 'Telsen'),
(197, 4, 'Languiñeo'),
(198, 4, 'Gastre'),
(199, 4, 'Futaleufu'),
(200, 4, 'Tehuelches'),
(201, 4, 'Rawson'),
(202, 4, 'Biedma'),
(203, 5, 'Rio Cuarto'),
(204, 5, 'Totoral'),
(205, 5, 'Colon'),
(206, 5, 'Minas'),
(207, 5, 'Punilla'),
(208, 5, 'Juarez Celman'),
(209, 5, 'Marcos Juarez'),
(210, 5, 'San Justo'),
(211, 5, 'Tercero Arriba'),
(212, 5, 'Rio Seco'),
(213, 5, 'Capital'),
(214, 5, 'Santa Maria'),
(215, 5, 'San Alberto'),
(216, 5, 'Union'),
(217, 5, 'Pocho'),
(218, 5, 'Calamuchita'),
(219, 5, 'Ischilin'),
(220, 5, 'General San Martin'),
(221, 5, 'Rio Primero'),
(222, 5, 'Cruz Del Eje'),
(223, 5, 'Grl.roca'),
(224, 5, 'General Roca'),
(225, 5, 'Sobremonte'),
(226, 5, 'Rio Segundo'),
(227, 5, 'Tulumba'),
(228, 5, 'San Javier'),
(229, 5, 'Presidente Roque Saez Peña'),
(230, 5, 'Presidente Roque Saenz Peña'),
(232, 5, 'Cruz De Eje'),
(233, 5, 'Coronel Pringles'),
(234, 5, 'Rio Tercero'),
(235, 5, 'Cvalamuchita'),
(236, 6, 'San Roque'),
(237, 6, 'Monte Caseros'),
(238, 6, 'General Alvear'),
(239, 6, 'Curuzu Cuatia'),
(240, 6, 'San Martin'),
(241, 6, 'Mercedes'),
(242, 6, 'Saladas'),
(243, 6, 'Ituzaingo'),
(244, 6, 'Beron De Astrada'),
(245, 6, 'Bella Vista'),
(246, 6, 'San Luis Del Palmar'),
(247, 6, 'Capital'),
(248, 6, 'Lavalle'),
(249, 6, 'Paso De Los Libres'),
(250, 6, 'Goya'),
(251, 6, 'Empedrado'),
(252, 6, 'Sauce'),
(253, 6, 'General Paz'),
(254, 6, 'Santo Tome'),
(255, 6, 'San Miguel'),
(256, 6, 'Concepcion'),
(257, 6, 'Esquina'),
(258, 6, 'San Cosme'),
(259, 6, 'Itati'),
(260, 6, 'Mburucuya'),
(261, 7, 'Uruguay'),
(262, 7, 'Nogoya'),
(263, 7, 'Tala'),
(264, 7, 'Gualeguay'),
(265, 7, 'Diamante'),
(266, 7, 'Parana'),
(267, 7, 'Gualeguaychu'),
(268, 7, 'Colon'),
(269, 7, 'Victoria'),
(270, 7, 'Villaguay'),
(271, 7, 'Feliciano'),
(272, 7, 'Concordia'),
(273, 7, 'La Paz'),
(274, 7, 'Federacion'),
(275, 7, 'Federal'),
(276, 7, 'Castellanos'),
(277, 8, 'Pilagas'),
(278, 8, 'Patiño'),
(279, 8, 'Pilcomayo'),
(280, 8, 'Bermejo'),
(281, 8, 'Pirane'),
(282, 8, 'Formosa'),
(283, 8, 'Matacos'),
(284, 8, 'Ramon Lista'),
(285, 8, 'Pillagas'),
(286, 8, 'Laishi'),
(287, 9, 'Ledesma'),
(288, 9, 'Cochinoca'),
(289, 9, 'El Carmen'),
(290, 9, 'Tumbaya'),
(291, 9, 'Capital'),
(292, 9, 'Yavi'),
(293, 9, 'Humahuaca'),
(294, 9, 'Rinconada'),
(295, 9, 'Valle Grande'),
(296, 9, 'Susques'),
(297, 9, 'Santa Catalina'),
(298, 9, 'San Antonio'),
(299, 9, 'Santa Barbara'),
(300, 9, 'San Pedro'),
(301, 9, 'Tilcara'),
(302, 9, 'Ladesma'),
(303, 10, 'Hucal'),
(304, 10, 'Realico'),
(305, 10, 'Mara Co'),
(306, 10, 'Quemuquemu'),
(307, 10, 'Chical Co'),
(308, 10, 'Guatrache'),
(309, 10, 'Capital'),
(310, 10, 'Caleucaleu'),
(311, 10, 'Trenel'),
(312, 10, 'Utracan'),
(313, 10, 'Atreuco'),
(314, 10, 'Toay'),
(315, 10, 'Chapadleufu'),
(316, 10, 'Conelo'),
(317, 10, 'Puelen'),
(318, 10, 'Rancul'),
(319, 10, 'Quemu Quemu'),
(320, 10, 'Loventue'),
(321, 10, 'Conhelo'),
(322, 10, 'Catrilo'),
(323, 10, 'Chapaleufu'),
(324, 10, 'Ultracan'),
(325, 10, 'Chalileo'),
(326, 10, 'Lihuel Calel'),
(327, 10, 'Maraco'),
(328, 10, 'Caleu Caleu'),
(329, 10, 'Curaco'),
(330, 10, 'Limay Mahuida'),
(331, 11, 'Castro Barros'),
(332, 11, 'General San Martin'),
(333, 11, 'General Lavalle'),
(334, 11, 'Arauco'),
(335, 11, 'Gral.angel V.peñaloza'),
(336, 11, 'San Blas De Los Sauces'),
(337, 11, 'Independencia'),
(338, 11, 'General Ocampo'),
(339, 11, 'Chilecito'),
(340, 11, 'Famatina'),
(341, 11, 'Grl.juan Facundo Quiroga'),
(342, 11, 'Grl.angel V. Peñaloza'),
(343, 11, 'General Belgrano'),
(344, 11, 'General Sarmiento'),
(345, 11, 'Capital'),
(346, 11, 'Gdor. Gordillo'),
(347, 11, 'General Angel Vicente Peñaloza'),
(348, 11, 'Gobernador Gordillo'),
(349, 11, 'Rosario Vera Peñaloza'),
(350, 11, 'Grl.san Martin'),
(351, 11, 'General La Madrid'),
(352, 11, 'General Juan Facundo Quiroga'),
(353, 11, 'Generalocampo'),
(354, 11, 'Sanagasta'),
(355, 12, 'San Rafael'),
(356, 12, 'Lujan'),
(357, 12, 'Malargue'),
(358, 12, 'Guaymallen'),
(359, 12, 'Lavalle'),
(360, 12, 'Junin'),
(361, 12, 'Tupungato'),
(362, 12, 'Rivadavia'),
(363, 12, 'Maipu'),
(364, 12, 'Godoy Cruz'),
(365, 12, 'General Alvear'),
(366, 12, 'La Paz'),
(367, 12, 'Tunuyan'),
(368, 12, 'San Carlos'),
(369, 12, 'Las Heras'),
(370, 12, 'Lujan De Cuyo'),
(371, 12, 'San Martin'),
(372, 12, 'Santa Rosa'),
(373, 12, 'Capital'),
(374, 13, '25 De Mayo'),
(375, 13, 'Iguazu'),
(376, 13, 'El Dorado'),
(377, 13, 'Leandro N. Alem'),
(378, 13, 'Apostoles'),
(379, 13, 'Cainguas'),
(380, 13, 'Leandro N.alem'),
(381, 13, 'Concepcion'),
(382, 13, 'San Pedro'),
(383, 13, 'Candelaria'),
(384, 13, 'Grl.manuel Belgrano'),
(385, 13, 'Obera'),
(386, 13, 'Libertador Grl.san Martin'),
(387, 13, 'San Ignacio'),
(388, 13, 'Montecarlo'),
(389, 13, 'General Manuel Belgrano'),
(390, 13, 'Lebertador Grl.san Martin'),
(391, 13, 'El Guarani'),
(392, 13, 'Eldorado'),
(393, 13, 'Capital'),
(394, 13, 'Guarani'),
(395, 13, 'San Javier'),
(396, 13, 'Libertador Grl. San Martin'),
(397, 14, 'Collon Cura'),
(398, 14, 'Alumine'),
(399, 14, 'Minas'),
(400, 14, 'Añelo'),
(401, 14, 'Confluencia'),
(402, 14, 'Chos Malal'),
(403, 14, 'Picunches'),
(404, 14, 'Norquin'),
(405, 14, 'Pehuenches'),
(406, 14, 'Loncopue'),
(407, 14, 'Huiliches'),
(408, 14, 'Zapala'),
(409, 14, 'Catan Lil'),
(410, 14, 'Ñorquin'),
(411, 14, 'Los Lagos'),
(412, 14, 'Picun Leufu'),
(413, 14, 'Lacar'),
(414, 14, 'Ñoequin'),
(415, 15, 'Valcheta'),
(416, 15, '25 De Mayo'),
(417, 15, 'El Cuy'),
(418, 15, 'Ñorquinco'),
(419, 15, 'General Roca'),
(420, 15, 'Avellaneda'),
(421, 15, 'Conesa'),
(422, 15, 'Pichi Mahuida'),
(423, 15, 'San Antonio'),
(424, 15, 'Pilcaniyeu'),
(425, 15, '9 De Julio'),
(426, 15, 'Adolfo Alsina'),
(427, 15, 'Bariloche'),
(428, 15, 'Pihi Mahuida'),
(429, 16, 'La Viña'),
(430, 16, 'San Martin'),
(431, 16, 'Oran'),
(432, 16, 'Anta'),
(433, 16, 'Gral.jose De San Martin'),
(434, 16, 'Guachipas'),
(435, 16, 'Rosario De La Frontera'),
(436, 16, 'Rivadavia'),
(437, 16, 'Metan'),
(438, 16, 'San Carlos'),
(439, 16, 'Grl.guemes'),
(440, 16, 'Cachi'),
(441, 16, 'Rosario De Lerma'),
(442, 16, 'Cafayate'),
(443, 16, 'Los Andes'),
(444, 16, 'Grl.jose De San Martin'),
(445, 16, 'Capital'),
(446, 16, 'Grl.san Martin'),
(447, 16, 'General Guemes'),
(448, 16, 'Cerrillos'),
(449, 16, 'Chicoana'),
(450, 16, 'La Poma'),
(451, 16, 'La Capital'),
(452, 16, 'Candelaria'),
(453, 16, 'Rosario'),
(454, 16, 'Iruya'),
(455, 16, 'La Caldera'),
(456, 16, 'Loa Andes'),
(457, 16, 'Molinos'),
(458, 16, 'Santa Victoria'),
(459, 17, '9 De Julio'),
(460, 17, 'Jachal'),
(461, 17, 'Albardon'),
(462, 17, '25 De Mayo'),
(463, 17, 'Santa Lucia'),
(464, 17, 'Angaco'),
(465, 17, 'Iglesia'),
(466, 17, 'Valle Fertil'),
(467, 17, 'Calingasta'),
(468, 17, 'Rivadavia'),
(469, 17, 'Caucete'),
(470, 17, 'Sarmiento'),
(471, 17, 'Pocito'),
(472, 17, 'San Martin'),
(473, 17, 'Chimbas'),
(474, 17, 'Iglesias'),
(475, 17, 'Ullun'),
(476, 17, 'Rawson'),
(477, 17, 'Capital'),
(478, 17, 'Zonda'),
(479, 18, 'Belgrano'),
(480, 18, 'Chacabuco'),
(481, 18, 'La Capital'),
(482, 18, 'Gobernador Dupuy'),
(483, 18, 'Grl.pedernera'),
(484, 18, 'Ayacucho'),
(485, 18, 'Junin'),
(486, 18, 'Gonernador Dupuy'),
(487, 18, 'Coronel Pringles'),
(488, 18, 'General Pedernera'),
(489, 18, 'Gobernador Duval'),
(490, 18, 'Iglesia'),
(491, 18, 'Libertador Grl. San Martin'),
(492, 18, 'Libertador Grl.san Martin'),
(493, 18, 'Libertador Gr.san Martin'),
(494, 18, 'Caucete'),
(495, 19, 'Guer Aike'),
(496, 19, 'Deseado'),
(497, 19, 'Rio Chico'),
(498, 19, 'Magallanes'),
(499, 19, 'Lago Argentino'),
(500, 19, 'Corpen Aike'),
(501, 19, 'Lago Buenos Aires'),
(502, 20, 'General Lopez'),
(503, 20, 'Rosario'),
(504, 20, 'General Obligado'),
(505, 20, 'Constitucion'),
(506, 20, 'San Lorenzo'),
(507, 20, 'San Javier'),
(508, 20, 'La Capital'),
(509, 20, 'San Cristobal'),
(510, 20, 'Iriondo'),
(511, 20, 'Castellanos'),
(512, 20, 'Nueve De Julio'),
(513, 20, 'Caseros'),
(514, 20, 'San Jeronimo'),
(515, 20, 'Belgrano'),
(516, 20, 'Capital'),
(517, 20, 'San Justo'),
(518, 20, 'Grl.obligado'),
(519, 20, 'La Caputal'),
(520, 20, 'Grl.lopez'),
(521, 20, 'Vera'),
(522, 20, '9 De Julio'),
(523, 20, 'San Martin'),
(524, 20, 'Las Colonias'),
(525, 20, 'Garay'),
(526, 20, 'Castelanos'),
(527, 20, 'Las Colinas'),
(528, 21, 'Banda'),
(529, 21, 'Moreno'),
(530, 21, 'Alberdi'),
(531, 21, 'Pellegrini'),
(532, 21, 'Ojo De Agua'),
(533, 21, 'Rio Hondo'),
(534, 21, 'General Taboada'),
(535, 21, 'Choya'),
(536, 21, 'Capital'),
(537, 21, 'Aguirre'),
(538, 21, 'Silipica'),
(539, 21, 'Belgrano'),
(540, 21, 'Figueroa'),
(541, 21, 'Salavina'),
(542, 21, 'Quebrachos'),
(543, 21, 'Robles'),
(544, 21, 'Avellaneda'),
(545, 21, 'Jimenez'),
(546, 21, 'Atamisqui'),
(547, 21, 'San Martin'),
(548, 21, 'Matara'),
(549, 21, 'Salayina'),
(550, 21, 'Guasayan'),
(551, 21, 'Copo'),
(552, 21, 'Brigadier Juan Felipe Ibarra'),
(553, 21, 'Dobles'),
(554, 21, 'Sarmiento'),
(555, 21, 'Loreto'),
(556, 21, 'Mitre'),
(557, 21, 'Rivadavia'),
(558, 22, 'Ushuaia'),
(559, 22, 'Islas Del Atlantico Sur'),
(560, 22, 'Sector Antartico Argentino'),
(561, 22, 'Rio Grande'),
(562, 22, 'Is.del Atlantico Sur E Is.malvinas'),
(563, 22, 'Antartida Argentina'),
(564, 23, 'Burruyacu'),
(565, 23, 'Trancas'),
(566, 23, 'Monteros'),
(567, 23, 'Leales'),
(568, 23, 'Cruz Alta'),
(569, 23, 'Rio Chico'),
(570, 23, 'Chicligasta'),
(571, 23, 'Tafi'),
(572, 23, 'Graneros'),
(573, 23, 'Famailla'),
(574, 23, 'Capital');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_acceso`
--

CREATE TABLE IF NOT EXISTS `detalles_acceso` (
  `id_acceso_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `id_acceso` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `crear` tinyint(4) NOT NULL DEFAULT '1',
  `escribir` tinyint(4) NOT NULL DEFAULT '1',
  `modificar` tinyint(4) NOT NULL DEFAULT '1',
  `borrar` tinyint(4) NOT NULL DEFAULT '1',
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_acceso_detalle`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `detalles_acceso`
--

INSERT INTO `detalles_acceso` (`id_acceso_detalle`, `id_acceso`, `id_categoria`, `crear`, `escribir`, `modificar`, `borrar`, `delete`) VALUES
(1, 1, 7, 1, 0, 0, 1, 0),
(2, 1, 5, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_config`
--

CREATE TABLE IF NOT EXISTS `detalles_config` (
  `id_detalle_config` int(11) NOT NULL AUTO_INCREMENT,
  `id_config` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `usar` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_detalle_config`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direcciones_hotel`
--

CREATE TABLE IF NOT EXISTS `direcciones_hotel` (
  `id_direccion` int(11) NOT NULL AUTO_INCREMENT,
  `id_hotel` int(11) NOT NULL,
  `calle` varchar(64) CHARACTER SET latin1 NOT NULL,
  `nro` int(11) NOT NULL,
  `id_departamento` int(11) NOT NULL,
  `id_provincia` int(11) NOT NULL,
  `id_pais` int(11) NOT NULL,
  `coordenadas` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_direccion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `direcciones_hotel`
--

INSERT INTO `direcciones_hotel` (`id_direccion`, `id_hotel`, `calle`, `nro`, `id_departamento`, `id_provincia`, `id_pais`, `coordenadas`) VALUES
(1, 2, '25 de mayo', 1184, 0, 12, 32, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direcciones_huesped`
--

CREATE TABLE IF NOT EXISTS `direcciones_huesped` (
  `id_direccion` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `calle` varchar(64) CHARACTER SET latin1 NOT NULL,
  `nro` int(11) NOT NULL,
  `piso` int(11) NOT NULL DEFAULT '0',
  `id_departamento` int(11) NOT NULL,
  `id_provincia` int(11) NOT NULL,
  `id_pais` int(11) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  `coordenadas` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_direccion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `direcciones_huesped`
--

INSERT INTO `direcciones_huesped` (`id_direccion`, `id_huesped`, `calle`, `nro`, `piso`, `id_departamento`, `id_provincia`, `id_pais`, `id_tipo`, `coordenadas`) VALUES
(1, 1, 'Costanera', 1948, 1, 364, 12, 32, 1, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direcciones_usuario`
--

CREATE TABLE IF NOT EXISTS `direcciones_usuario` (
  `id_direccion` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `calle` varchar(64) CHARACTER SET latin1 NOT NULL,
  `nro` int(11) NOT NULL,
  `piso` int(11) NOT NULL DEFAULT '0',
  `id_departamento` int(11) NOT NULL,
  `id_provincia` int(11) NOT NULL,
  `id_pais` int(11) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  `coordenadas` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_direccion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `disponibilidades`
--

CREATE TABLE IF NOT EXISTS `disponibilidades` (
  `id_disponibilidad` int(11) NOT NULL AUTO_INCREMENT,
  `disponibilidad` varchar(128) NOT NULL,
  `entrada` date NOT NULL,
  `salida` date NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_disponibilidad`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `disponibilidades`
--

INSERT INTO `disponibilidades` (`id_disponibilidad`, `disponibilidad`, `entrada`, `salida`, `delete`) VALUES
(1, 'test', '2014-08-23', '2014-08-25', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `disponibilidad_habitacion`
--

CREATE TABLE IF NOT EXISTS `disponibilidad_habitacion` (
  `id_disponibilidad_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_disponibilidad` int(11) NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_disponibilidad_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `disponibilidad_habitacion`
--

INSERT INTO `disponibilidad_habitacion` (`id_disponibilidad_habitacion`, `id_disponibilidad`, `id_habitacion`, `prioridad`) VALUES
(1, 1, 2, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `emails_hotel`
--

CREATE TABLE IF NOT EXISTS `emails_hotel` (
  `id_email` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) CHARACTER SET latin1 NOT NULL,
  `mostrar` tinyint(4) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  PRIMARY KEY (`id_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `emails_hotel`
--

INSERT INTO `emails_hotel` (`id_email`, `email`, `mostrar`, `id_tipo`) VALUES
(1, 'hotelesgoldargentina@gmail.com', 1, 1),
(2, 'diego_nieto_1@hotmail.com', 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `emails_huesped`
--

CREATE TABLE IF NOT EXISTS `emails_huesped` (
  `id_email` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `email` varchar(128) CHARACTER SET latin1 NOT NULL,
  `id_tipo` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `emails_huesped`
--

INSERT INTO `emails_huesped` (`id_email`, `id_huesped`, `email`, `id_tipo`) VALUES
(1, 1, 'diego_nieto_1@hotmail.com', 1),
(2, 2, 'diego.nieto@tmsgroup.com.ar', 1),
(3, 3, 'perro@rodirguez.com', 1),
(4, 4, 'pedro@gimenez.com', 1),
(5, 5, 'diego_nieto_1@hotmail.comasd', 1),
(6, 6, 'diego.nieto@tmsgroup.com.arasd', 1),
(7, 7, '0', 1),
(8, 8, '0', 1),
(9, 9, '0', 1),
(10, 10, '0', 1),
(11, 11, '0', 1),
(12, 12, 'd@d.com', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `emails_usuario`
--

CREATE TABLE IF NOT EXISTS `emails_usuario` (
  `id_email` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `email` varchar(128) CHARACTER SET latin1 NOT NULL,
  `id_tipo` int(11) NOT NULL,
  PRIMARY KEY (`id_email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas`
--

CREATE TABLE IF NOT EXISTS `empresas` (
  `id_empresa` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` varchar(64) NOT NULL,
  `slogan` varchar(128) NOT NULL,
  PRIMARY KEY (`id_empresa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `empresas`
--

INSERT INTO `empresas` (`id_empresa`, `empresa`, `slogan`) VALUES
(1, 'Hoteles Gold', 'Mensaje de la empresa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_articulo`
--

CREATE TABLE IF NOT EXISTS `estados_articulo` (
  `id_estado_articulo` int(11) NOT NULL AUTO_INCREMENT,
  `estado_articulo` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_estado_articulo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `estados_articulo`
--

INSERT INTO `estados_articulo` (`id_estado_articulo`, `estado_articulo`) VALUES
(1, '<span class="label label-success">Publicado</span>'),
(2, '<span class="label label-danger">Sin Publicar</span>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_habitacion`
--

CREATE TABLE IF NOT EXISTS `estados_habitacion` (
  `id_estado_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `estado_habitacion` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_estado_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `estados_habitacion`
--

INSERT INTO `estados_habitacion` (`id_estado_habitacion`, `estado_habitacion`) VALUES
(1, '<span class="label label-danger">No disponible</label>'),
(2, '<span class="label label-success">Disponible</label>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_huesped`
--

CREATE TABLE IF NOT EXISTS `estados_huesped` (
  `id_estado_huesped` int(11) NOT NULL AUTO_INCREMENT,
  `estado_huesped` varchar(128) NOT NULL,
  PRIMARY KEY (`id_estado_huesped`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `estados_huesped`
--

INSERT INTO `estados_huesped` (`id_estado_huesped`, `estado_huesped`) VALUES
(1, '<span class="label label-primary">Alta</span>'),
(2, '<span class="label label-danger">Baja</span>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_mensaje`
--

CREATE TABLE IF NOT EXISTS `estados_mensaje` (
  `id_estado_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `estado_mensaje` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_estado_mensaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `estados_mensaje`
--

INSERT INTO `estados_mensaje` (`id_estado_mensaje`, `estado_mensaje`) VALUES
(1, '<span class="label label-success">Nuevo</span>'),
(2, '<span class="label label-default">Leído</span>'),
(3, '<span class="label label-info">Enviado</span>\r\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_reserva`
--

CREATE TABLE IF NOT EXISTS `estados_reserva` (
  `id_estado_reserva` int(11) NOT NULL AUTO_INCREMENT,
  `estado_reserva` varchar(128) CHARACTER SET latin1 NOT NULL,
  `reserva_lugar` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_estado_reserva`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `estados_reserva`
--

INSERT INTO `estados_reserva` (`id_estado_reserva`, `estado_reserva`, `reserva_lugar`) VALUES
(1, '<span class="label label-success">Nueva</span>', 0),
(2, '<span class="label label-warning">Falta de pago</span>', 1),
(3, '<span class="label label-primary">Aceptada</span>', 1),
(4, '<span class="label label-danger">Rechazada</span>', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_usuario`
--

CREATE TABLE IF NOT EXISTS `estados_usuario` (
  `id_estado_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `estado_usuario` varchar(128) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_estado_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `estados_usuario`
--

INSERT INTO `estados_usuario` (`id_estado_usuario`, `estado_usuario`) VALUES
(1, '<span class="label label-primary">Alta</span>'),
(2, '<span class="label label-danger">Baja</span>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `habitaciones`
--

CREATE TABLE IF NOT EXISTS `habitaciones` (
  `id_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `habitacion` varchar(32) CHARACTER SET latin1 NOT NULL,
  `descripcion` text COLLATE latin1_spanish_ci NOT NULL,
  `adultos` int(11) NOT NULL,
  `menores` int(11) NOT NULL,
  `entrada` time NOT NULL,
  `salida` time NOT NULL,
  `cantidad` int(11) NOT NULL,
  `id_tipo_habitacion` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `id_tarifa` int(11) NOT NULL,
  `id_estado_habitacion` int(11) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `habitaciones`
--

INSERT INTO `habitaciones` (`id_habitacion`, `habitacion`, `descripcion`, `adultos`, `menores`, `entrada`, `salida`, `cantidad`, `id_tipo_habitacion`, `id_hotel`, `id_tarifa`, `id_estado_habitacion`, `delete`) VALUES
(1, 'Habitación Doble Carollo', '<p style="margin: 15px 0px; padding: 0px; color: rgb(111, 111, 111); font-family: Lato, arial, sans-serif; font-size: 14px; text-align: justify;">\r\n	El Hotel Carollo, est&aacute; situado en pleno Valle del Taurito junto a la monta&ntilde;a desde la que se disfruta de impresionantes vistas sobre el atl&aacute;ntico, su especial situaci&oacute;n en plena playa del Taurito lo convierte en un punto privilegiado para los amantes de la naturaleza en estado puro. A tan solo 4 km de Puerto de Mog&aacute;n, un peque&ntilde;o, precioso y encantador puerto de mar, y a 10km del vecino Puerto Rico. Dotado de 405 habitaciones con preciosas vistas panor&aacute;micas sobre el mar, ofrecen la calma y tranquilidad necesarias para un descanso ideal.</p>\r\n', 2, 1, '10:00:00', '14:00:00', 10, 1, 2, 2, 2, 0),
(2, 'Habitación Simple Extra', '<p style="text-align: justify;">\r\n	<span style="color: rgb(111, 111, 111); font-family: Lato, arial, sans-serif; font-size: 14px; line-height: 20px;">El hotel pone asimismo a disposici&oacute;n de sus clientes salones ideales para conferencias o convenciones, un buen numero de actividades de animaci&oacute;n diurna y entretenimientos diversos seg&uacute;n la temporada, disfrutando de sus dos espaciosas piscinas de agua dulce (1 climatizada), saboreando una cuidada y elaborada gastronom&iacute;a en su restaurante, asistiendo a espect&aacute;culos nocturnos, diversos shows en directo semanales... Una completa oferta al servicio de una estancia inolvidable en el Hotel Taurito Princess.</span></p>\r\n', 1, 0, '00:00:00', '00:00:00', 10, 1, 2, 1, 2, 0),
(4, 'habitaciones2', '<p>\r\n	123</p>\r\n', 123, 123, '00:01:23', '00:01:32', 123, 1, 2, 1, 2, 1),
(5, 'test', '<p>\r\n	stst</p>\r\n', 120, 21230, '00:00:00', '00:00:00', 0, 1, 2, 1, 2, 1),
(6, 'test', '<p>\r\n	test</p>\r\n', 10, 10, '00:00:00', '00:00:00', 0, 1, 2, 1, 2, 1),
(7, 't', '<p>\r\n	t</p>\r\n', 10, 10, '00:00:09', '00:00:14', 10, 2, 2, 1, 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `habitacion_servicio`
--

CREATE TABLE IF NOT EXISTS `habitacion_servicio` (
  `id_habitacion_servicio` int(11) NOT NULL AUTO_INCREMENT,
  `id_servicio` int(11) NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_habitacion_servicio`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Volcado de datos para la tabla `habitacion_servicio`
--

INSERT INTO `habitacion_servicio` (`id_habitacion_servicio`, `id_servicio`, `id_habitacion`, `prioridad`) VALUES
(1, 7, 1, 2),
(2, 4, 1, 3),
(3, 6, 1, 4),
(4, 5, 1, 5),
(5, 2, 1, 0),
(6, 1, 1, 1),
(7, 7, 2, 0),
(8, 2, 2, 1),
(9, 6, 2, 2),
(10, 4, 2, 3),
(11, 5, 2, 4),
(12, 1, 2, 5),
(13, 7, 3, 0),
(14, 2, 3, 1),
(15, 6, 3, 2),
(16, 4, 3, 3),
(17, 5, 3, 4),
(18, 8, 3, 5),
(19, 1, 3, 6),
(20, 7, 4, 0),
(21, 2, 4, 1),
(22, 6, 4, 2),
(23, 4, 4, 3),
(24, 5, 4, 4),
(25, 8, 4, 5),
(26, 1, 4, 6),
(27, 7, 5, 0),
(28, 2, 5, 1),
(29, 6, 5, 2),
(30, 4, 5, 3),
(31, 5, 5, 4),
(32, 8, 5, 5),
(33, 1, 5, 6),
(34, 6, 6, 0),
(35, 2, 7, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoteles`
--

CREATE TABLE IF NOT EXISTS `hoteles` (
  `id_hotel` int(11) NOT NULL AUTO_INCREMENT,
  `hotel` varchar(64) CHARACTER SET latin1 NOT NULL,
  `descripcion` varchar(128) CHARACTER SET latin1 NOT NULL,
  `logo_url` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `fondo_intro` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `url` varchar(128) CHARACTER SET latin1 NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_hotel`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=10 ;

--
-- Volcado de datos para la tabla `hoteles`
--

INSERT INTO `hoteles` (`id_hotel`, `hotel`, `descripcion`, `logo_url`, `fondo_intro`, `url`, `delete`) VALUES
(2, 'Carollo', 'Descripcion del hotel', '4e495-logo.png', '35a3f-1.jpg', 'www.nuevo.com.ar', 0),
(3, 'Princess', 'Hotel descripcón', '890a3-4e495-logo.png', 'd5b77-12.jpg', 'www.carrollo.com', 0),
(9, 'Test', 'test', '', '800d6-02.jpg', 'test', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hotel_email_habitacion`
--

CREATE TABLE IF NOT EXISTS `hotel_email_habitacion` (
  `id_hotel_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_email` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_hotel_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `hotel_email_habitacion`
--

INSERT INTO `hotel_email_habitacion` (`id_hotel_habitacion`, `id_email`, `id_hotel`, `prioridad`) VALUES
(1, 2, 2, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hotel_email_mensaje`
--

CREATE TABLE IF NOT EXISTS `hotel_email_mensaje` (
  `id_hotel_email` int(11) NOT NULL AUTO_INCREMENT,
  `id_email` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_hotel_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `hotel_email_mensaje`
--

INSERT INTO `hotel_email_mensaje` (`id_hotel_email`, `id_email`, `id_hotel`, `prioridad`) VALUES
(1, 2, 2, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hotel_email_reserva`
--

CREATE TABLE IF NOT EXISTS `hotel_email_reserva` (
  `id_hotel_email` int(11) NOT NULL AUTO_INCREMENT,
  `id_email` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_hotel_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Volcado de datos para la tabla `hotel_email_reserva`
--

INSERT INTO `hotel_email_reserva` (`id_hotel_email`, `id_email`, `id_hotel`, `prioridad`) VALUES
(2, 1, 0, 0),
(37, 2, 2, 0),
(39, 1, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `huespedes`
--

CREATE TABLE IF NOT EXISTS `huespedes` (
  `id_huesped` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(128) CHARACTER SET latin1 NOT NULL,
  `apellido` varchar(64) CHARACTER SET latin1 NOT NULL,
  `dni` int(11) NOT NULL,
  `pass` varchar(64) CHARACTER SET latin1 NOT NULL,
  `id_tipo_huesped` int(11) NOT NULL,
  `id_estado_huesped` int(11) NOT NULL DEFAULT '1',
  `fecha_alta` datetime NOT NULL,
  `fecha_modificacion` datetime NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_huesped`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `huespedes`
--

INSERT INTO `huespedes` (`id_huesped`, `nombre`, `apellido`, `dni`, `pass`, `id_tipo_huesped`, `id_estado_huesped`, `fecha_alta`, `fecha_modificacion`, `delete`) VALUES
(1, 'Diego', 'Nieto', 0, '8131', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(2, 'Sergio', 'Gomez', 0, '1166', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(3, 'Pedro', 'Lopez', 0, '1667', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(4, 'Pedro', 'Gimenez', 0, '5200', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
(5, 'Oscar', 'Gimenez', 0, '8684', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(6, 'Diego', '-', 0, '3638', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
(7, '0', '0', 0, '4494', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
(8, '0', '0', 0, '5045', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
(9, '0', '0', 0, '6651', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
(10, '0', '0', 0, '4506', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
(11, '0', '0', 0, '5592', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
(12, 'd', 'd', 0, '2379', 1, 1, '2014-08-29 16:55:41', '2014-08-29 16:55:41', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `idiomas`
--

CREATE TABLE IF NOT EXISTS `idiomas` (
  `id_idioma` int(11) NOT NULL AUTO_INCREMENT,
  `idioma` varchar(64) NOT NULL,
  `imagen` varchar(128) NOT NULL,
  `archivo` varchar(64) NOT NULL,
  `delete` int(11) NOT NULL,
  PRIMARY KEY (`id_idioma`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `idiomas`
--

INSERT INTO `idiomas` (`id_idioma`, `idioma`, `imagen`, `archivo`, `delete`) VALUES
(0, 'Todos', '', 'spanish.php', 0),
(1, 'Español', '27b11-9d48a-argentina-icono-8268-48.png', 'spanish.php', 0),
(2, 'Ingles', '5277f-09c26-bandera-icono-5097-48.png', 'english.php', 0),
(3, 'Francés', '7bc3e-francia-icono-7845-48.png', 'french.php', 0),
(4, 'Portugués', 'dfeab-4319e-brasil-icono-8028-48.png', 'portuguese.php', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes_carrusel`
--

CREATE TABLE IF NOT EXISTS `imagenes_carrusel` (
  `id_imagen` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(128) CHARACTER SET latin1 NOT NULL,
  `tipo` varchar(32) CHARACTER SET latin1 NOT NULL,
  `size` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `titulo` text CHARACTER SET latin1 NOT NULL,
  `descripcion` text CHARACTER SET latin1 NOT NULL,
  `id_hotel` int(11) NOT NULL,
  PRIMARY KEY (`id_imagen`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=15 ;

--
-- Volcado de datos para la tabla `imagenes_carrusel`
--

INSERT INTO `imagenes_carrusel` (`id_imagen`, `imagen`, `tipo`, `size`, `orden`, `titulo`, `descripcion`, `id_hotel`) VALUES
(12, 'c51c1-07.jpg', '', 0, 0, '', '', 0),
(13, '12670-08.jpg', '', 0, 0, '', '', 0),
(14, '06aed-09.jpg', '', 0, 0, '', '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes_habitacion`
--

CREATE TABLE IF NOT EXISTS `imagenes_habitacion` (
  `id_imagen` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(128) CHARACTER SET latin1 NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `tipo` varchar(32) CHARACTER SET latin1 NOT NULL,
  `size` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `titulo` text CHARACTER SET latin1 NOT NULL,
  `descripcion` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_imagen`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=66 ;

--
-- Volcado de datos para la tabla `imagenes_habitacion`
--

INSERT INTO `imagenes_habitacion` (`id_imagen`, `imagen`, `id_habitacion`, `tipo`, `size`, `orden`, `titulo`, `descripcion`) VALUES
(1, 'b93a5-Hydrangeas.jpg', 0, '', 0, 0, '', ''),
(9, '8922c-Penguins.jpg', 0, '', 0, 0, '', ''),
(60, '37f7e-03.jpg', 1, '', 0, 0, '', 'Cama doble'),
(61, '30a4c-02.jpg', 1, '', 0, 0, '', 'Sala de espera'),
(62, '39306-01.jpg', 1, '', 0, 0, '', 'Cama simple'),
(63, 'b131d-04.jpg', 2, '', 0, 0, '', 'Habitación'),
(64, 'b8467-05.jpg', 2, '', 0, 0, '', 'Entrada'),
(65, 'cf784-06.jpg', 2, '', 0, 0, '', 'Habitación otoño');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_articulos`
--

CREATE TABLE IF NOT EXISTS `logs_articulos` (
  `id_log_articulo` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_articulo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Volcado de datos para la tabla `logs_articulos`
--

INSERT INTO `logs_articulos` (`id_log_articulo`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'articulos', 22, 2, '2014-08-20 16:33:22', 1),
(2, 'categorias', 1, 2, '2014-08-20 16:43:44', 1),
(3, 'estados_articulo', 2, 2, '2014-08-20 16:43:50', 1),
(4, 'articulos', 20, 2, '2014-08-21 09:04:36', 1),
(5, 'articulos', 20, 2, '2014-08-21 09:05:39', 1),
(6, 'articulos', 22, 2, '2014-08-21 09:27:33', 1),
(7, 'estados_articulo', 2, 2, '2014-08-21 09:28:32', 1),
(8, 'articulos', 25, 1, '2014-08-21 11:35:18', 1),
(9, 'articulos', 25, 2, '2014-08-21 11:35:28', 1),
(10, 'articulos', 20, 2, '2014-08-21 12:39:27', 1),
(11, 'articulos', 20, 2, '2014-08-21 14:01:55', 1),
(12, 'articulos', 21, 2, '2014-08-21 14:02:22', 1),
(13, 'articulos', 18, 2, '2014-08-21 14:02:41', 1),
(14, 'articulos', 22, 3, '2014-08-21 14:03:02', 1),
(15, 'articulos', 23, 3, '2014-08-21 14:03:05', 1),
(16, 'articulos', 25, 3, '2014-08-21 14:03:09', 1),
(17, 'articulos', 24, 3, '2014-08-21 14:03:12', 1),
(18, 'articulos', 21, 2, '2014-08-21 14:03:28', 1),
(19, 'articulos', 18, 2, '2014-08-21 14:03:36', 1),
(20, 'articulos', 20, 2, '2014-08-21 14:03:48', 1),
(21, 'articulos', 20, 2, '2014-08-21 14:05:39', 1),
(22, 'articulos', 21, 2, '2014-08-21 14:05:55', 1),
(23, 'articulos', 18, 2, '2014-08-21 14:06:10', 1),
(24, 'articulos', 21, 2, '2014-08-21 14:09:02', 1),
(25, 'articulos', 20, 2, '2014-08-21 14:10:05', 1),
(26, 'articulos', 21, 2, '2014-08-21 14:10:12', 1),
(27, 'articulos', 18, 2, '2014-08-21 14:10:18', 1),
(28, 'articulos', 20, 2, '2014-08-21 14:12:25', 1),
(29, 'articulos', 20, 2, '2014-08-21 14:13:23', 1),
(30, 'articulos', 21, 2, '2014-08-21 14:15:57', 1),
(31, 'articulos', 21, 2, '2014-08-21 14:16:49', 1),
(32, 'articulos', 21, 2, '2014-08-21 14:18:43', 1),
(33, 'articulos', 18, 2, '2014-08-21 14:18:57', 1),
(34, 'articulos', 18, 2, '2014-08-21 14:19:20', 1),
(35, 'articulos', 18, 2, '2014-08-21 15:16:58', 1),
(36, 'articulos', 18, 2, '2014-08-21 15:19:34', 1),
(37, 'articulos', 20, 2, '2014-08-21 15:20:23', 1),
(38, 'articulos', 20, 2, '2014-08-21 15:20:33', 1),
(39, 'articulos', 18, 2, '2014-08-22 09:25:02', 1),
(40, 'articulos', 21, 2, '2014-08-22 14:56:23', 1),
(41, 'articulos', 18, 2, '2014-08-26 12:33:07', 1),
(42, 'articulos', 18, 2, '2014-08-26 12:33:34', 1),
(43, 'articulos', 18, 2, '2014-08-29 16:37:49', 1),
(44, 'articulos', 21, 2, '2014-08-29 16:37:57', 1),
(45, 'articulos', 21, 2, '2014-09-01 11:45:11', 1),
(46, 'articulos', 20, 2, '2014-09-01 11:45:41', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_habitaciones`
--

CREATE TABLE IF NOT EXISTS `logs_habitaciones` (
  `id_log_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Volcado de datos para la tabla `logs_habitaciones`
--

INSERT INTO `logs_habitaciones` (`id_log_habitacion`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'habitaciones', 7, 1, '2014-08-20 15:54:42', 1),
(2, 'habitaciones', 7, 2, '2014-08-20 15:54:57', 1),
(3, 'habitaciones', 7, 3, '2014-08-20 15:55:07', 1),
(4, 'tarifas', 3, 2, '2014-08-20 16:29:56', 1),
(5, 'tarifas_temporales', 5, 3, '2014-08-22 08:55:54', 1),
(6, 'tarifas_temporales', 6, 3, '2014-08-22 08:55:57', 1),
(7, 'tarifas_temporales', 1, 1, '2014-08-22 08:57:05', 1),
(8, 'tarifas_temporales', 1, 2, '2014-08-22 08:58:07', 1),
(9, 'tarifas_temporales', 2, 1, '2014-08-22 08:58:26', 1),
(10, 'tarifas_temporales', 2, 2, '2014-08-22 09:04:40', 1),
(11, 'tarifas_temporales', 2, 3, '2014-08-22 09:05:29', 1),
(12, 'tarifas_temporales', 1, 2, '2014-08-22 09:06:05', 1),
(13, 'tarifas_temporales', 1, 2, '2014-08-22 09:06:24', 1),
(14, 'tarifas_temporales', 1, 2, '2014-08-22 11:32:19', 1),
(15, 'tarifas_temporales', 1, 2, '2014-08-22 15:18:26', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_hoteles`
--

CREATE TABLE IF NOT EXISTS `logs_hoteles` (
  `id_log_hotel` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(32) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_hotel`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Volcado de datos para la tabla `logs_hoteles`
--

INSERT INTO `logs_hoteles` (`id_log_hotel`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'hoteles', 2, 2, '2014-08-20 16:31:41', 1),
(2, 'hoteles', 2, 2, '2014-08-27 10:00:21', 1),
(3, 'hoteles', 2, 2, '2014-08-27 10:01:16', 1),
(4, 'hoteles', 2, 2, '2014-08-27 10:02:02', 1),
(5, 'hoteles', 2, 2, '2014-08-27 10:03:42', 1),
(6, 'hoteles', 2, 2, '2014-08-27 10:08:08', 1),
(7, 'hoteles', 2, 2, '2014-08-27 12:03:12', 1),
(8, 'hoteles', 2, 2, '2014-08-27 12:06:02', 1),
(9, 'hoteles', 2, 2, '2014-08-27 12:37:03', 1),
(10, 'hoteles', 2, 2, '2014-08-28 10:32:54', 1),
(11, 'hoteles', 2, 2, '2014-08-28 10:34:35', 1),
(12, 'hoteles', 3, 1, '2014-08-29 08:45:25', 1),
(13, 'hoteles', 2, 2, '2014-08-29 08:49:56', 1),
(14, 'hoteles', 3, 2, '2014-08-29 08:51:52', 1),
(15, 'hoteles', 3, 3, '2014-08-29 08:58:00', 1),
(16, 'hoteles', 2, 2, '2014-09-01 11:57:02', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_huespedes`
--

CREATE TABLE IF NOT EXISTS `logs_huespedes` (
  `id_log_huesped` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_huesped`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Volcado de datos para la tabla `logs_huespedes`
--

INSERT INTO `logs_huespedes` (`id_log_huesped`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'huespedes', 1, 2, '2014-08-20 16:32:59', 1),
(2, 'huespedes', 7, 3, '2014-08-22 09:23:42', 1),
(3, 'huespedes', 8, 3, '2014-08-22 09:23:44', 1),
(4, 'huespedes', 9, 3, '2014-08-22 09:23:45', 1),
(5, 'huespedes', 10, 3, '2014-08-22 09:23:46', 1),
(6, 'huespedes', 11, 3, '2014-08-22 09:23:47', 1),
(7, 'huespedes', 2, 2, '2014-08-22 09:24:03', 1),
(8, 'huespedes', 3, 2, '2014-08-22 09:24:11', 1),
(9, 'huespedes', 5, 2, '2014-08-22 09:24:26', 1),
(10, 'huespedes', 6, 3, '2014-08-22 09:24:30', 1),
(11, 'hoteles', 8, 3, '2014-09-04 11:54:15', 1),
(12, 'hoteles', 7, 3, '2014-09-04 11:54:18', 1),
(13, 'hoteles', 5, 3, '2014-09-04 11:54:20', 1),
(14, 'hoteles', 5, 3, '2014-09-04 11:57:40', 1),
(15, 'hoteles', 7, 3, '2014-09-04 11:57:43', 1),
(16, 'hoteles', 8, 3, '2014-09-04 11:57:45', 1),
(17, 'hoteles', 8, 3, '2014-09-04 11:59:29', 1),
(18, 'hoteles', 8, 3, '2014-09-04 12:00:16', 1),
(19, 'hoteles', 8, 3, '2014-09-04 12:00:52', 1),
(20, 'hoteles', 8, 3, '2014-09-04 12:03:48', 1),
(21, 'hoteles', 9, 3, '2014-09-04 12:09:22', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_mensajes`
--

CREATE TABLE IF NOT EXISTS `logs_mensajes` (
  `id_log_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_mensaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `logs_mensajes`
--

INSERT INTO `logs_mensajes` (`id_log_mensaje`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'mensajes', 3, 2, '2014-08-20 16:39:03', 1),
(2, 'mensajes', 3, 3, '2014-08-22 09:24:47', 1),
(3, 'mensajes', 7, 2, '2014-08-28 11:17:22', 1),
(4, 'mensajes', 1, 2, '2014-08-28 11:17:45', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_otros`
--

CREATE TABLE IF NOT EXISTS `logs_otros` (
  `id_log_otro` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_otro`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Volcado de datos para la tabla `logs_otros`
--

INSERT INTO `logs_otros` (`id_log_otro`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'terminos', 1, 2, '2014-08-20 16:40:14', 1),
(2, 'idiomas', 1, 2, '2014-08-26 12:22:54', 1),
(3, 'idiomas', 3, 2, '2014-08-26 12:23:56', 1),
(4, 'idiomas', 4, 2, '2014-08-26 12:24:03', 1),
(5, 'idiomas', 2, 2, '2014-08-26 12:24:44', 1),
(6, 'idiomas', 1, 2, '2014-08-26 12:29:45', 1),
(7, 'idiomas', 2, 2, '2014-08-26 12:30:00', 1),
(8, 'idiomas', 3, 2, '2014-08-26 12:30:14', 1),
(9, 'idiomas', 4, 2, '2014-08-26 12:30:29', 1),
(10, 'ayudas', 3, 1, '2014-08-26 13:51:56', 1),
(11, 'ayudas', 2, 2, '2014-08-27 13:43:42', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_reservas`
--

CREATE TABLE IF NOT EXISTS `logs_reservas` (
  `id_log_reserva` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_reserva`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Volcado de datos para la tabla `logs_reservas`
--

INSERT INTO `logs_reservas` (`id_log_reserva`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'reservas', 2, 2, '2014-08-20 15:51:24', 1),
(2, 'reservas', 6, 2, '2014-08-21 12:47:38', 1),
(3, 'reservas', 2, 2, '2014-08-22 09:22:07', 1),
(4, 'reservas', 6, 2, '2014-08-22 09:22:18', 1),
(5, 'estados_reserva', 1, 2, '2014-08-22 09:39:52', 1),
(6, 'estados_reserva', 1, 2, '2014-08-22 09:40:06', 1),
(7, 'estados_reserva', 1, 2, '2014-08-22 09:40:23', 1),
(8, 'disponibilidades', 1, 1, '2014-08-22 11:09:36', 1),
(9, 'vuelos', 4, 1, '2014-09-01 16:35:46', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_usuarios`
--

CREATE TABLE IF NOT EXISTS `logs_usuarios` (
  `id_log_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(32) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `id_accion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_log_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `logs_usuarios`
--

INSERT INTO `logs_usuarios` (`id_log_usuario`, `tabla`, `id_tabla`, `id_accion`, `fecha`, `id_usuario`) VALUES
(1, 'usuarios', 2, 2, '2014-08-20 16:42:30', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE IF NOT EXISTS `mensajes` (
  `id_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(128) CHARACTER SET latin1 NOT NULL,
  `mensaje` text CHARACTER SET latin1 NOT NULL,
  `emisor` varchar(128) CHARACTER SET latin1 NOT NULL,
  `id_tipo_mensaje` int(11) NOT NULL,
  `fecha_envio` datetime NOT NULL,
  `nombre` varchar(64) COLLATE latin1_spanish_ci NOT NULL,
  `apellido` varchar(64) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(64) COLLATE latin1_spanish_ci NOT NULL,
  `id_estado_mensaje` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `comentario` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_mensaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=50 ;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id_mensaje`, `titulo`, `mensaje`, `emisor`, `id_tipo_mensaje`, `fecha_envio`, `nombre`, `apellido`, `telefono`, `id_estado_mensaje`, `id_hotel`, `comentario`, `delete`) VALUES
(1, 'Consulta web', '¿Puedo llevar mascotas?', 'diego.nieto@tmsgroup.com.ar', 1, '2014-07-28 08:56:01', '', '', '', 2, 0, 'Respuesta enviada', 0),
(2, 'Consulta web', 'x', 'diego_nieto_1@hotmail.com', 1, '2014-07-28 11:23:08', '', '', '', 2, 0, '', 1),
(3, 'Consulta web', '0', '0', 1, '2014-08-08 01:52:59', '', '', '', 2, 0, '', 1),
(4, 'Consulta web', '0', '0', 1, '2014-08-26 02:11:42', '', '', '', 1, 0, '', 0),
(5, 'Consulta web', '', '', 1, '2014-08-27 12:21:52', '', '', '', 1, 0, '', 0),
(6, 'Consulta web', '', '', 1, '2014-08-27 12:22:32', '', '', '', 1, 0, '', 0),
(7, 'Consulta web', '', '', 1, '2014-08-27 12:26:34', '', '', '', 2, 2, 'No se comunicar con el destinatario', 0),
(8, 'Consulta web', '', '', 1, '2014-08-27 12:26:42', '', '', '', 1, 2, '', 0),
(9, 'Consulta web', '', '', 1, '2014-08-27 12:37:08', '', '', '', 1, 2, '', 0),
(10, 'Consulta web', '', '', 1, '2014-08-27 12:37:41', '', '', '', 1, 2, '', 0),
(11, 'Consulta web', '', '', 1, '2014-08-27 12:37:59', '', '', '', 1, 2, '', 0),
(12, 'Consulta web', '', '', 1, '2014-08-27 12:38:30', '', '', '', 1, 2, '', 0),
(13, 'Consulta web', '', '', 1, '2014-08-27 12:38:59', '', '', '', 1, 2, '', 0),
(14, 'Consulta web', '', '', 1, '2014-08-27 12:39:16', '', '', '', 1, 2, '', 0),
(15, 'Consulta web', '', '', 1, '2014-08-27 12:39:45', '', '', '', 1, 2, '', 0),
(16, 'Consulta web', '', '', 1, '2014-08-27 12:47:06', '', '', '', 1, 2, '', 0),
(17, 'Consulta web', '', '', 1, '2014-08-27 01:10:07', '', '', '', 1, 2, '', 0),
(18, 'Consulta web', '', '', 1, '2014-08-27 01:11:03', '', '', '', 1, 2, '', 0),
(19, 'Consulta web', '', '', 1, '2014-08-27 01:11:14', '', '', '', 1, 2, '', 0),
(20, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:12:09', '', '', '', 1, 2, '', 0),
(21, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:12:46', '', '', '', 1, 2, '', 0),
(22, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:13:04', '', '', '', 1, 2, '', 0),
(23, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:14:31', '', '', '', 1, 2, '', 0),
(24, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:16:43', '', '', '', 1, 2, '', 0),
(25, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:16:53', '', '', '', 1, 2, '', 0),
(26, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:19:36', '', '', '', 1, 2, '', 0),
(27, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:20:18', '', '', '', 1, 2, '', 0),
(28, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:21:19', '', '', '', 1, 2, '', 0),
(29, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:21:37', '', '', '', 1, 2, '', 0),
(30, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:21:58', '', '', '', 1, 2, '', 0),
(31, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:22:26', '', '', '', 1, 2, '', 0),
(32, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:23:53', '', '', '', 1, 2, '', 0),
(33, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:24:32', '', '', '', 1, 2, '', 0),
(34, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:25:12', '', '', '', 1, 2, '', 0),
(35, 'Consulta web', 'Test', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:25:31', '', '', '', 1, 2, '', 0),
(36, 'Consulta web', 'Diego', 'diego_nieto_1@hotmail.com', 1, '2014-08-27 01:25:57', '', '', '', 1, 2, '', 0),
(37, 'Consulta web', 'Diego', 'diego_nieto_1@hotmail.com', 1, '2014-08-28 11:07:34', 'Nieto', '26165', '0', 1, 2, '', 0),
(38, 'Consulta web', 'perro', 'diego_nieto_1@hotmail.com', 1, '2014-08-28 11:08:24', 'Diego', 'Nieto', '4396721', 1, 2, '', 0),
(39, 'Consulta web', 'perro', 'diego_nieto_1@hotmail.com', 1, '2014-08-28 11:09:51', 'Diego', 'Nieto', '4396721', 1, 2, '', 0),
(40, 'Consulta web', 'perro', 'diego_nieto_1@hotmail.com', 1, '2014-08-28 11:21:28', 'Diego', 'Nieto', '4396721', 1, 2, '', 0),
(41, 'Consulta web', 'perro', 'diego_nieto_1@hotmail.com', 1, '2014-08-28 11:22:28', 'Diego', 'Nieto', '4396721', 1, 2, '', 0),
(42, 'Consulta web', 'perro', 'diego_nieto_1@hotmail.com', 1, '2014-08-28 11:24:11', 'Diego', 'Nieto', '4396721', 1, 2, '', 0),
(43, 'Consulta web', 'perro', 'diego_nieto_1@hotmail.com', 1, '2014-08-28 11:24:19', 'Diego', 'Nieto', '4396721', 1, 2, '', 0),
(44, 'Consulta web', 'perro', 'diego_nieto_1@hotmail.com', 1, '2014-08-28 11:24:28', 'Diego', 'Nieto', '4396721', 1, 2, '', 0),
(45, 'Envió de habitacion ID: 1', '', '', 2, '2014-08-28 12:03:31', '', '', '', 1, 2, '', 0),
(46, 'Envió de habitacion ID: 1', 'Mira esta habitación', 'diego_nieto_1@hotmail.com', 2, '2014-08-28 12:03:56', 'Diego', 'Nieto', '', 1, 2, '', 0),
(47, 'Envió de habitacion ID: 1', 'Mira esta habitación', 'diego_nieto_1@hotmail.com', 2, '2014-08-28 12:07:13', 'Diego', 'Nieto', '', 1, 2, '', 0),
(48, 'Envió de habitacion ID: 2', 'd', 'diego.nieto@tmsgroup.com.ar', 2, '2014-08-28 12:07:33', 'Diego', 'Nieto', '', 1, 2, '', 0),
(49, 'Consulta web', '', '', 1, '2014-08-29 04:36:31', '', '', '', 1, 2, '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `monedas`
--

CREATE TABLE IF NOT EXISTS `monedas` (
  `id_moneda` int(11) NOT NULL AUTO_INCREMENT,
  `moneda` varchar(64) CHARACTER SET latin1 NOT NULL,
  `abreviatura` varchar(8) COLLATE latin1_spanish_ci NOT NULL,
  `simbolo` char(3) COLLATE latin1_spanish_ci NOT NULL,
  `valor` float NOT NULL,
  `imagen` varchar(64) COLLATE latin1_spanish_ci NOT NULL,
  `id_pais` int(11) NOT NULL,
  `delete` int(11) NOT NULL,
  PRIMARY KEY (`id_moneda`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `monedas`
--

INSERT INTO `monedas` (`id_moneda`, `moneda`, `abreviatura`, `simbolo`, `valor`, `imagen`, `id_pais`, `delete`) VALUES
(1, 'Peso', 'ar', '$', 1, '9d48a-argentina-icono-8268-48.png', 32, 0),
(2, 'Dollar', 'usd', '$', 8.28, '09c26-bandera-icono-5097-48.png', 840, 0),
(3, 'Euro', 'EUR', '€', 8.2, 'e343a-bandera-de-la-union-europea-icono-5854-48.png', 724, 0),
(4, 'Peso', 'cl', '$', 69.5, 'f0833-chile-icono-5681-48.png', 152, 0),
(5, 'Real', 'br', 'R$', 3.9, '4319e-brasil-icono-8028-48.png', 76, 0),
(7, 'pepe', '123', '123', 123, '', 4, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notas`
--

CREATE TABLE IF NOT EXISTS `notas` (
  `id_nota` int(11) NOT NULL AUTO_INCREMENT,
  `nota` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_nota`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `notas`
--

INSERT INTO `notas` (`id_nota`, `nota`) VALUES
(1, 'Quiero Guiso'),
(2, 'Quiero pollo'),
(3, 'Quiero pollo'),
(4, 'Quiero Pollo'),
(5, 'Quiero frazadas '),
(6, 'Quiero frazadas ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paises`
--

CREATE TABLE IF NOT EXISTS `paises` (
  `id_pais` int(3) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `pais` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_pais`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=895 ;

--
-- Volcado de datos para la tabla `paises`
--

INSERT INTO `paises` (`id_pais`, `pais`) VALUES
(004, 'Afganistán'),
(008, 'Albania'),
(010, 'Antártida'),
(012, 'Argelia'),
(016, 'Samoa Americana'),
(020, 'Andorra'),
(024, 'Angola'),
(028, 'Antigua y Barbuda'),
(031, 'Azerbaiyán'),
(032, 'Argentina'),
(036, 'Australia'),
(040, 'Austria'),
(044, 'Bahamas'),
(048, 'Bahréin'),
(050, 'Bangladesh'),
(051, 'Armenia'),
(052, 'Barbados'),
(056, 'Bélgica'),
(060, 'Bermudas'),
(064, 'Bhután'),
(068, 'Bolivia'),
(070, 'Bosnia y Herzegovina'),
(072, 'Botsuana'),
(074, 'Isla Bouvet'),
(076, 'Brasil'),
(084, 'Belice'),
(086, 'Territorio Británico del Océano Índico'),
(090, 'Islas Salomón'),
(092, 'Islas Vírgenes Británicas'),
(096, 'Brunéi'),
(100, 'Bulgaria'),
(104, 'Myanmar'),
(108, 'Burundi'),
(112, 'Bielorrusia'),
(116, 'Camboya'),
(120, 'Camerún'),
(124, 'Canadá'),
(132, 'Cabo Verde'),
(136, 'Islas Caimán'),
(140, 'República Centroafricana'),
(144, 'Sri Lanka'),
(148, 'Chad'),
(152, 'Chile'),
(156, 'China'),
(158, 'Taiwán'),
(162, 'Isla de Navidad'),
(166, 'Islas Cocos'),
(170, 'Colombia'),
(174, 'Comoras'),
(175, 'Mayotte'),
(178, 'Congo'),
(180, 'República Democrática del Congo'),
(184, 'Islas Cook'),
(188, 'Costa Rica'),
(191, 'Croacia'),
(192, 'Cuba'),
(196, 'Chipre'),
(203, 'República Checa'),
(204, 'Benín'),
(208, 'Dinamarca'),
(212, 'Dominica'),
(214, 'República Dominicana'),
(218, 'Ecuador'),
(222, 'El Salvador'),
(226, 'Guinea Ecuatorial'),
(231, 'Etiopía'),
(232, 'Eritrea'),
(233, 'Estonia'),
(234, 'Islas Feroe'),
(238, 'Islas Malvinas'),
(239, 'Islas Georgias del Sur y Sandwich del Sur'),
(242, 'Fiyi'),
(246, 'Finlandia'),
(248, 'Islas Gland'),
(250, 'Francia'),
(254, 'Guayana Francesa'),
(258, 'Polinesia Francesa'),
(260, 'Territorios Australes Franceses'),
(262, 'Yibuti'),
(266, 'Gabón'),
(268, 'Georgia'),
(270, 'Gambia'),
(275, 'Palestina'),
(276, 'Alemania'),
(288, 'Ghana'),
(292, 'Gibraltar'),
(296, 'Kiribati'),
(300, 'Grecia'),
(304, 'Groenlandia'),
(308, 'Granada'),
(312, 'Guadalupe'),
(316, 'Guam'),
(320, 'Guatemala'),
(324, 'Guinea'),
(328, 'Guyana'),
(332, 'Haití'),
(334, 'Islas Heard y McDonald'),
(336, 'Ciudad del Vaticano'),
(340, 'Honduras'),
(344, 'Hong Kong'),
(348, 'Hungría'),
(352, 'Islandia'),
(356, 'India'),
(360, 'Indonesia'),
(364, 'Irán'),
(368, 'Iraq'),
(372, 'Irlanda'),
(376, 'Israel'),
(380, 'Italia'),
(384, 'Costa de Marfil'),
(388, 'Jamaica'),
(392, 'Japón'),
(398, 'Kazajstán'),
(400, 'Jordania'),
(404, 'Kenia'),
(408, 'Corea del Norte'),
(410, 'Corea del Sur'),
(414, 'Kuwait'),
(417, 'Kirguistán'),
(418, 'Laos'),
(422, 'Líbano'),
(426, 'Lesotho'),
(428, 'Letonia'),
(430, 'Liberia'),
(434, 'Libia'),
(438, 'Liechtenstein'),
(440, 'Lituania'),
(442, 'Luxemburgo'),
(446, 'Macao'),
(450, 'Madagascar'),
(454, 'Malaui'),
(458, 'Malasia'),
(462, 'Maldivas'),
(466, 'Malí'),
(470, 'Malta'),
(474, 'Martinica'),
(478, 'Mauritania'),
(480, 'Mauricio'),
(484, 'México'),
(492, 'Mónaco'),
(496, 'Mongolia'),
(498, 'Moldavia'),
(499, 'Montenegro'),
(500, 'Montserrat'),
(504, 'Marruecos'),
(508, 'Mozambique'),
(512, 'Omán'),
(516, 'Namibia'),
(520, 'Nauru'),
(524, 'Nepal'),
(528, 'Países Bajos'),
(530, 'Antillas Holandesas'),
(533, 'Aruba'),
(540, 'Nueva Caledonia'),
(548, 'Vanuatu'),
(554, 'Nueva Zelanda'),
(558, 'Nicaragua'),
(562, 'Níger'),
(566, 'Nigeria'),
(570, 'Niue'),
(574, 'Isla Norfolk'),
(578, 'Noruega'),
(580, 'Islas Marianas del Norte'),
(581, 'Islas Ultramarinas de Estados Unidos'),
(583, 'Micronesia'),
(584, 'Islas Marshall'),
(585, 'Palaos'),
(586, 'Pakistán'),
(591, 'Panamá'),
(598, 'Papúa Nueva Guinea'),
(600, 'Paraguay'),
(604, 'Perú'),
(608, 'Filipinas'),
(612, 'Islas Pitcairn'),
(616, 'Polonia'),
(620, 'Portugal'),
(624, 'Guinea-Bissau'),
(626, 'Timor Oriental'),
(630, 'Puerto Rico'),
(634, 'Qatar'),
(638, 'Reunión'),
(642, 'Rumania'),
(643, 'Rusia'),
(646, 'Ruanda'),
(654, 'Santa Helena'),
(659, 'San Cristóbal y Nieves'),
(660, 'Anguila'),
(662, 'Santa Lucía'),
(666, 'San Pedro y Miquelón'),
(670, 'San Vicente y las Granadinas'),
(674, 'San Marino'),
(678, 'Santo Tomé y Príncipe'),
(682, 'Arabia Saudí'),
(686, 'Senegal'),
(688, 'Serbia'),
(690, 'Seychelles'),
(694, 'Sierra Leona'),
(702, 'Singapur'),
(703, 'Eslovaquia'),
(704, 'Vietnam'),
(705, 'Eslovenia'),
(706, 'Somalia'),
(710, 'Sudáfrica'),
(716, 'Zimbabue'),
(724, 'España'),
(732, 'Sahara Occidental'),
(736, 'Sudán'),
(740, 'Surinam'),
(744, 'Svalbard y Jan Mayen'),
(748, 'Suazilandia'),
(752, 'Suecia'),
(756, 'Suiza'),
(760, 'Siria'),
(762, 'Tayikistán'),
(764, 'Tailandia'),
(768, 'Togo'),
(772, 'Tokelau'),
(776, 'Tonga'),
(780, 'Trinidad y Tobago'),
(784, 'Emiratos Árabes Unidos'),
(788, 'Túnez'),
(792, 'Turquía'),
(795, 'Turkmenistán'),
(796, 'Islas Turcas y Caicos'),
(798, 'Tuvalu'),
(800, 'Uganda'),
(804, 'Ucrania'),
(807, 'Macedonia'),
(818, 'Egipto'),
(826, 'Reino Unido'),
(834, 'Tanzania'),
(840, 'Estados Unidos'),
(850, 'Islas Vírgenes de los Estados Unidos'),
(854, 'Burkina Faso'),
(858, 'Uruguay'),
(860, 'Uzbekistán'),
(862, 'Venezuela'),
(876, 'Wallis y Futuna'),
(882, 'Samoa'),
(887, 'Yemen'),
(894, 'Zambia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincias`
--

CREATE TABLE IF NOT EXISTS `provincias` (
  `id_provincia` int(4) NOT NULL AUTO_INCREMENT,
  `provincia` varchar(64) NOT NULL,
  `id_pais` int(11) NOT NULL,
  PRIMARY KEY (`id_provincia`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Volcado de datos para la tabla `provincias`
--

INSERT INTO `provincias` (`id_provincia`, `provincia`, `id_pais`) VALUES
(1, 'Buenos Aires y Cap.', 32),
(2, 'Catamarca', 32),
(3, 'Chaco', 32),
(4, 'Chubut', 32),
(5, 'Cordoba', 32),
(6, 'Corrientes', 32),
(7, 'Entre Rios', 32),
(8, 'Formosa', 32),
(9, 'Jujuy', 32),
(10, 'La Pampa', 32),
(11, 'La Rioja', 32),
(12, 'Mendoza', 32),
(13, 'Misiones', 32),
(14, 'Neuquen', 32),
(15, 'Rio Negro', 32),
(16, 'Salta', 32),
(17, 'San Juan', 32),
(18, 'San Luis', 32),
(19, 'Santa Cruz', 32),
(20, 'Santa Fe', 32),
(21, 'Santiago Del Estero', 32),
(22, 'Tierra Del Fuego', 32),
(23, 'Tucuman', 32);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE IF NOT EXISTS `reservas` (
  `id_reserva` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `entrada` date NOT NULL,
  `salida` date NOT NULL,
  `adultos` int(11) NOT NULL,
  `menores` int(11) NOT NULL,
  `id_nota` int(11) NOT NULL,
  `id_estado_reserva` int(11) NOT NULL,
  `fecha_alta` datetime NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_reserva`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=51 ;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id_reserva`, `id_huesped`, `entrada`, `salida`, `adultos`, `menores`, `id_nota`, `id_estado_reserva`, `fecha_alta`, `delete`) VALUES
(1, 1, '2014-08-23', '2014-08-24', 2, 0, 0, 1, '2014-08-22 09:39:26', 0),
(2, 1, '2014-08-23', '2014-08-24', 2, 0, 0, 1, '2014-08-22 11:01:17', 0),
(3, 1, '2014-08-23', '2014-08-24', 2, 0, 0, 1, '2014-08-22 13:53:09', 0),
(4, 1, '2014-08-23', '2014-08-24', 2, 0, 0, 1, '2014-08-22 13:53:49', 0),
(5, 1, '2014-08-23', '2014-08-24', 2, 0, 0, 1, '2014-08-22 13:54:16', 0),
(6, 1, '2014-08-23', '2014-08-24', 2, 0, 0, 1, '2014-08-22 13:57:49', 0),
(7, 1, '2014-08-26', '2014-08-27', 2, 0, 0, 1, '2014-08-25 10:11:15', 0),
(8, 1, '2014-08-26', '2014-08-27', 2, 0, 0, 1, '2014-08-25 10:13:04', 0),
(9, 1, '2014-08-28', '2014-08-29', 2, 0, 0, 1, '2014-08-27 13:41:28', 0),
(10, 1, '2014-08-28', '2014-08-29', 2, 0, 0, 1, '2014-08-27 13:43:47', 0),
(11, 1, '2014-08-28', '2014-08-29', 2, 0, 0, 1, '2014-08-27 13:44:32', 0),
(12, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:09:08', 0),
(13, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:09:43', 0),
(14, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:10:59', 0),
(15, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:11:08', 0),
(16, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:11:46', 0),
(17, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:12:23', 0),
(18, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:13:45', 0),
(19, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:13:52', 0),
(20, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:14:19', 0),
(21, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:14:45', 0),
(22, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:15:06', 0),
(23, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:15:39', 0),
(24, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:16:20', 0),
(25, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:16:28', 0),
(26, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:16:47', 0),
(27, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:17:07', 0),
(28, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:17:54', 0),
(29, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:18:39', 0),
(30, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:18:59', 0),
(31, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:19:10', 0),
(32, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:19:35', 0),
(33, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:19:51', 0),
(34, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:20:32', 0),
(35, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:20:41', 0),
(36, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:24:10', 0),
(37, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:26:41', 0),
(38, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:26:56', 0),
(39, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 09:32:03', 0),
(40, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 10:05:49', 0),
(41, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 10:08:29', 0),
(42, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 10:24:01', 0),
(43, 1, '2014-08-29', '2014-08-30', 2, 0, 0, 1, '2014-08-28 10:42:56', 0),
(44, 1, '2014-08-30', '2014-08-31', 2, 0, 0, 1, '2014-08-29 09:59:40', 0),
(45, 12, '2014-08-30', '2014-08-31', 2, 0, 0, 1, '2014-08-29 16:55:41', 0),
(46, 2, '2014-09-02', '2014-09-03', 2, 0, 0, 1, '2014-09-01 15:35:15', 0),
(47, 2, '2014-09-02', '2014-09-03', 2, 0, 0, 1, '2014-09-01 15:35:56', 0),
(48, 2, '2014-09-02', '2014-09-03', 2, 0, 0, 1, '2014-09-01 15:36:20', 0),
(49, 2, '2014-09-02', '2014-09-03', 2, 0, 0, 1, '2014-09-01 15:36:45', 0),
(50, 2, '2014-09-02', '2014-09-03', 2, 0, 0, 1, '2014-09-01 15:37:12', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reserva_habitacion`
--

CREATE TABLE IF NOT EXISTS `reserva_habitacion` (
  `id_reserva_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_reserva` int(11) NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_reserva_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Volcado de datos para la tabla `reserva_habitacion`
--

INSERT INTO `reserva_habitacion` (`id_reserva_habitacion`, `id_reserva`, `id_habitacion`, `cantidad`, `prioridad`) VALUES
(1, 1, 1, 1, 0),
(2, 2, 2, 2, 0),
(3, 3, 1, 3, 0),
(4, 4, 1, 3, 0),
(5, 5, 1, 3, 0),
(6, 6, 1, 2, 0),
(7, 7, 1, 1, 0),
(8, 8, 1, 1, 0),
(9, 9, 1, 1, 0),
(10, 10, 1, 1, 0),
(11, 11, 1, 1, 0),
(12, 12, 1, 2, 0),
(13, 13, 1, 2, 0),
(14, 14, 1, 2, 0),
(15, 15, 1, 2, 0),
(16, 16, 1, 2, 0),
(17, 17, 1, 2, 0),
(18, 18, 1, 2, 0),
(19, 19, 1, 2, 0),
(20, 20, 1, 2, 0),
(21, 21, 1, 2, 0),
(22, 22, 1, 2, 0),
(23, 23, 1, 2, 0),
(24, 24, 1, 2, 0),
(25, 25, 1, 2, 0),
(26, 26, 1, 2, 0),
(27, 27, 1, 2, 0),
(28, 28, 1, 2, 0),
(29, 29, 1, 2, 0),
(30, 30, 1, 2, 0),
(31, 31, 1, 2, 0),
(32, 32, 1, 2, 0),
(33, 33, 1, 2, 0),
(34, 34, 1, 2, 0),
(35, 35, 1, 2, 0),
(36, 36, 1, 2, 0),
(37, 37, 1, 2, 0),
(38, 38, 1, 2, 0),
(39, 39, 1, 2, 0),
(40, 40, 1, 2, 0),
(41, 41, 1, 2, 0),
(42, 42, 1, 2, 0),
(43, 43, 1, 2, 0),
(44, 44, 2, 2, 0),
(45, 45, 1, 2, 0),
(46, 48, 1, 3, 0),
(47, 49, 1, 3, 0),
(48, 50, 1, 3, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicios`
--

CREATE TABLE IF NOT EXISTS `servicios` (
  `id_servicio` int(11) NOT NULL AUTO_INCREMENT,
  `servicio` varchar(64) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_servicio`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Volcado de datos para la tabla `servicios`
--

INSERT INTO `servicios` (`id_servicio`, `servicio`, `delete`) VALUES
(1, 'WIFI', 0),
(2, 'Aire acondicionado', 0),
(4, 'Estacionamiento', 0),
(5, 'Minibar', 0),
(6, 'Desayuno', 0),
(7, 'Acceso con silla de ruedas', 0),
(8, 'Tele', 1),
(9, 'Tele', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifas`
--

CREATE TABLE IF NOT EXISTS `tarifas` (
  `id_tarifa` int(11) NOT NULL AUTO_INCREMENT,
  `tarifa` varchar(64) CHARACTER SET latin1 NOT NULL,
  `precio` float NOT NULL,
  `id_moneda` int(11) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tarifa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `tarifas`
--

INSERT INTO `tarifas` (`id_tarifa`, `tarifa`, `precio`, `id_moneda`, `delete`) VALUES
(1, 'Single', 350, 1, 0),
(2, 'Doble', 450, 1, 0),
(3, 'Triple', 500, 1, 0),
(4, 'test', 120, 3, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifas_temporales`
--

CREATE TABLE IF NOT EXISTS `tarifas_temporales` (
  `id_tarifa_temporal` int(11) NOT NULL AUTO_INCREMENT,
  `tarifa_temporal` varchar(128) NOT NULL,
  `entrada` date NOT NULL,
  `salida` date NOT NULL,
  `id_tipo_tarifa` tinyint(4) NOT NULL,
  `valor` float NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tarifa_temporal`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `tarifas_temporales`
--

INSERT INTO `tarifas_temporales` (`id_tarifa_temporal`, `tarifa_temporal`, `entrada`, `salida`, `id_tipo_tarifa`, `valor`, `delete`) VALUES
(1, 'Test', '2014-08-21', '2014-08-30', 2, 10, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifa_habitacion`
--

CREATE TABLE IF NOT EXISTS `tarifa_habitacion` (
  `id_tarifa_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_tarifa_temporal` int(11) NOT NULL,
  `id_habitacion` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL,
  PRIMARY KEY (`id_tarifa_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `tarifa_habitacion`
--

INSERT INTO `tarifa_habitacion` (`id_tarifa_habitacion`, `id_tarifa_temporal`, `id_habitacion`, `prioridad`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarjetas`
--

CREATE TABLE IF NOT EXISTS `tarjetas` (
  `id_tarjeta` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `tarjeta` int(11) NOT NULL,
  `pin` int(11) NOT NULL,
  `vencimiento` date NOT NULL,
  `id_tipo_tarjeta` int(11) NOT NULL,
  PRIMARY KEY (`id_tarjeta`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `tarjetas`
--

INSERT INTO `tarjetas` (`id_tarjeta`, `id_huesped`, `tarjeta`, `pin`, `vencimiento`, `id_tipo_tarjeta`) VALUES
(1, 1, 2147483647, 0, '0000-00-00', 1),
(2, 1, 0, 0, '0000-00-00', 2),
(3, 1, 0, 0, '0000-00-00', 2),
(4, 1, 2147483647, 0, '0000-00-00', 2),
(5, 12, 2147483647, 0, '0000-00-00', 1),
(6, 2, 2147483647, 1558584953, '0000-00-00', 1),
(7, 2, 2147483647, 1558584953, '0000-00-00', 1),
(8, 2, 2147483647, 1558584953, '0000-00-00', 1),
(9, 2, 2147483647, 1558584953, '0000-00-00', 1),
(10, 2, 2147483647, 1558584953, '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefonos_hotel`
--

CREATE TABLE IF NOT EXISTS `telefonos_hotel` (
  `id_telefono` int(11) NOT NULL AUTO_INCREMENT,
  `id_hotel` int(11) NOT NULL,
  `telefono` varchar(64) CHARACTER SET latin1 NOT NULL,
  `id_tipo` int(11) NOT NULL,
  PRIMARY KEY (`id_telefono`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `telefonos_hotel`
--

INSERT INTO `telefonos_hotel` (`id_telefono`, `id_hotel`, `telefono`, `id_tipo`) VALUES
(1, 2, '(0261) - 4235666', 1),
(2, 2, '4396721', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefonos_huesped`
--

CREATE TABLE IF NOT EXISTS `telefonos_huesped` (
  `id_telefono` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `telefono` varchar(64) CHARACTER SET latin1 NOT NULL,
  `id_tipo` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_telefono`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `telefonos_huesped`
--

INSERT INTO `telefonos_huesped` (`id_telefono`, `id_huesped`, `telefono`, `id_tipo`) VALUES
(1, 1, '261-5132824', 1),
(2, 2, '2615132824', 1),
(3, 3, '2615132824', 1),
(4, 4, '261-5132824', 1),
(5, 5, '261-5132824', 1),
(6, 6, '261-5132824', 1),
(7, 7, '0', 1),
(8, 8, '0', 1),
(9, 9, '0', 1),
(10, 10, '0', 1),
(11, 11, '0', 1),
(12, 12, '261-5132824', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefonos_usuario`
--

CREATE TABLE IF NOT EXISTS `telefonos_usuario` (
  `id_telefono` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `telefono` varchar(64) CHARACTER SET latin1 NOT NULL,
  `id_tipo` int(11) NOT NULL,
  PRIMARY KEY (`id_telefono`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `terminos`
--

CREATE TABLE IF NOT EXISTS `terminos` (
  `id_termino` int(11) NOT NULL AUTO_INCREMENT,
  `termino` text NOT NULL,
  PRIMARY KEY (`id_termino`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `terminos`
--

INSERT INTO `terminos` (`id_termino`, `termino`) VALUES
(1, '<p>\r\n	En forma previa a la utilizaci&oacute;n de cualquier servicio o contenido ofrecido en Carollo!, debe leerse completa y atentamente este documento. Las presentes Condiciones Generales constituyen las normas y reglas dispuestas por Carollo!, relativas a todos los servicios existentes actualmente o que resulten incluidos en el futuro dentro del sitio Carollo.net (el Sitio). Dichos servicios si bien pueden ser gratuitos, no son de libre utilizaci&oacute;n, sino que est&aacute;n sujetos a un conjunto de pautas que regulan su uso. El aprovechamiento que un individuo haga de los servicios incluidos en el Sitio, s&oacute;lo se considerar&aacute; l&iacute;cito y autorizado cuando lo sea en cumplimiento de las obligaciones impuestas, con los l&iacute;mites y alcances aqu&iacute; delineados, as&iacute; como los que surjan de disposiciones complementarias o accesorias, y/o de las diferentes normativas legales de orden nacional e internacional cuya aplicaci&oacute;n corresponda. Carollo! podr&aacute; en cualquier momento y sin necesidad de previo aviso modificar estas Condiciones Generales. Tales modificaciones ser&aacute;n operativas a partir de su fijaci&oacute;n en el sitio carolo. Los usuarios deber&aacute;n mantenerse actualizados en cuanto al los t&eacute;rminos aqu&iacute; incluidos ingresando en forma peri&oacute;dica al apartado de legales de Carollor!.</p>\r\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE IF NOT EXISTS `tipos` (
  `id_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(64) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`id_tipo`, `tipo`) VALUES
(1, 'Personal'),
(2, 'Trabajo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_correo`
--

CREATE TABLE IF NOT EXISTS `tipos_correo` (
  `id_tipo_correo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_correo` varchar(64) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_correo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `tipos_correo`
--

INSERT INTO `tipos_correo` (`id_tipo_correo`, `tipo_correo`, `delete`) VALUES
(1, 'Administración', 0),
(2, 'Huesped', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_habitacion`
--

CREATE TABLE IF NOT EXISTS `tipos_habitacion` (
  `id_tipo_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_habitacion` varchar(64) CHARACTER SET latin1 NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_habitacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `tipos_habitacion`
--

INSERT INTO `tipos_habitacion` (`id_tipo_habitacion`, `tipo_habitacion`, `delete`) VALUES
(1, 'Single', 0),
(2, 'Doble', 0),
(3, 'Triple', 0),
(4, 'Test', 1),
(5, 'test', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_huesped`
--

CREATE TABLE IF NOT EXISTS `tipos_huesped` (
  `id_tipo_huesped` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_huesped` varchar(64) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_huesped`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `tipos_huesped`
--

INSERT INTO `tipos_huesped` (`id_tipo_huesped`, `tipo_huesped`, `delete`) VALUES
(1, '<span class="label label-success">Nuevo</span>', 0),
(2, '<span class="label label-default">Normal</span>', 0),
(3, '<span class="label label-danger">No aceptados</span>', 0),
(4, '<span class="label label-info">Especial</span>', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_mensaje`
--

CREATE TABLE IF NOT EXISTS `tipos_mensaje` (
  `id_tipo_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_mensaje` varchar(64) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id_tipo_mensaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `tipos_mensaje`
--

INSERT INTO `tipos_mensaje` (`id_tipo_mensaje`, `tipo_mensaje`) VALUES
(1, 'Web'),
(2, 'Envió de habitación ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_tarifa`
--

CREATE TABLE IF NOT EXISTS `tipos_tarifa` (
  `id_tipo_tarifa` tinyint(4) NOT NULL AUTO_INCREMENT,
  `tipo_tarifa` varchar(64) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_tarifa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `tipos_tarifa`
--

INSERT INTO `tipos_tarifa` (`id_tipo_tarifa`, `tipo_tarifa`, `delete`) VALUES
(1, '<span class="label label-success">% aumento</label>', 0),
(2, '<span class="label label-warning">% descuento</label>', 0),
(3, '<span class="label label-default">valor</label>', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_tarjeta`
--

CREATE TABLE IF NOT EXISTS `tipos_tarjeta` (
  `id_tipo_tarjeta` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_tarjeta` varchar(64) CHARACTER SET latin1 NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tipo_tarjeta`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `tipos_tarjeta`
--

INSERT INTO `tipos_tarjeta` (`id_tipo_tarjeta`, `tipo_tarjeta`, `delete`) VALUES
(1, 'Visa', 0),
(2, 'Nevada', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(64) CHARACTER SET latin1 NOT NULL,
  `pass` varchar(128) CHARACTER SET latin1 NOT NULL,
  `pass2` varchar(128) COLLATE latin1_spanish_ci NOT NULL,
  `id_acceso` int(11) NOT NULL,
  `id_estado_usuario` int(11) NOT NULL DEFAULT '1',
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `pass`, `pass2`, `id_acceso`, `id_estado_usuario`, `delete`) VALUES
(1, 'admin', '405e28906322882c5be9b4b27f4c35fd', '1978', 1, 1, 0),
(2, 'test', '81dc9bdb52d04dc20036dbd8313ed055', '1234', 1, 1, 0),
(3, 'test2', '81dc9bdb52d04dc20036dbd8313ed055', '1234', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vuelos`
--

CREATE TABLE IF NOT EXISTS `vuelos` (
  `id_vuelo` int(11) NOT NULL AUTO_INCREMENT,
  `id_huesped` int(11) NOT NULL,
  `id_aerolinea` int(11) NOT NULL,
  `id_reserva` int(11) NOT NULL,
  `nro_vuelo` int(11) NOT NULL,
  `horario_llegada` time NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_vuelo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `vuelos`
--

INSERT INTO `vuelos` (`id_vuelo`, `id_huesped`, `id_aerolinea`, `id_reserva`, `nro_vuelo`, `horario_llegada`, `delete`) VALUES
(1, 2, 1, 48, 689, '00:00:00', 0),
(2, 2, 1, 49, 689, '00:00:00', 0),
(3, 2, 1, 50, 689, '15:05:00', 0),
(4, 3, 2, 2, 962, '10:00:00', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
